# ForgeCell Engine 0.15.0 — Test Results

Дата: 18 октября 2026. Среда: Linux, GCC, CMake/Ninja, Python3. Android SDK / NDK / Gradle отсутствуют.

| Проверка | Результат |
|---|---|
| CMake configure/build, Debug, C++20 | PASS |
| CTest, Debug | **15/15 PASS** |
| CMake configure/build, ASan + UBSan | PASS |
| CTest, ASan + UBSan (`ASAN_OPTIONS=detect_leaks=0`) | **15/15 PASS** |
| `navigation_ui_regressions_tests` | PASS |
| Host Android project structure test | PASS, **статический** |
| `gradle :app:assembleDebug` | **НЕ ПРОВЕРЯЛОСЬ** |
| Android ARM64 запуск, multitouch, GLES3 | **НЕ ПРОВЕРЯЛОСЬ** |
| Проверка 60 FPS на смартфоне | **НЕ ПРОВЕРЯЛОСЬ** |

Новый набор проверяет: выбор доступной точки старта прыжка под навесом, отклонение недостижимого подъёма, фактическое приземление NPC и read-only предпросмотр перетаскивания (без преждевременного изменения инвентаря). Проверено, что событие переноса генерируется однократно на pointer-up и сбрасывается при отмене ввода.

Рендерер тестировался **только статически** (корректность подключения новых символов через текстовый тест). Отсутствие ошибок ASan/UBSan не доказывает отсутствие дефектов Android-части.

**Сохранения:** FCSV v1/v2/v3; формат не изменён.
