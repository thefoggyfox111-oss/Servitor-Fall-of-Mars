# ForgeCell Engine 0.6.0 — результаты проверок

17 октября 2026. Среда: Linux x86_64, CMake, C++20; Android SDK/NDK не установлен.

| Группа тестов | Debug | Clang ASan+UBSan |
|---|---|---|
| core_tests | PASS | PASS |
| combat_animation_tests | PASS | PASS |
| ai_equipment_tests | PASS | PASS |
| navigation_loot_tests | PASS | PASS |
| save_content_tests | PASS | PASS |
| ecs_animation_vfx_tests | PASS | PASS |

Дополнительные проверки:

- 6 отдельных персонажей × 8 клипов × 16 визуально уникальных кадров — проверено на уровне пиксельных данных FCAT.
- Разные тайминги анимаций grunt/heavy, транзакционный отказ при повреждении FCAN.
- 1000 сущностей ECS: создание, удаление, swap-delete, повторное использование слотов и запрет устаревших ID.
- Пулы временных эффектов: TTL, ограничение 256, очистка, повторное использование сущностей без «оживления» старых ссылок.
- События урона → одноразовые визуальные эффекты → автоматическое удаление.
- Пять прежних наборов тестов на бой, навигацию, инвентарь и контрольные точки по-прежнему проходят.

Команды:

```sh
cmake -S . -B build-native -DCMAKE_BUILD_TYPE=Debug
cmake --build build-native -j
ctest --test-dir build-native --output-on-failure
cmake -S . -B build-asan -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-asan -j
ASAN_OPTIONS=detect_leaks=1 ctest --test-dir build-asan --output-on-failure
```

**Не проверено:** Android Gradle/NDK сборка, установка APK, стабильность 60 FPS, драйвер GLES3 и жизненный цикл Activity на физическом смартфоне.
