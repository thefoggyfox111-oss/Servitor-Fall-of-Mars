# ForgeCell Engine 0.8.0 — результаты тестирования

Дата: 17.10.2026

| Проверка | Результат |
|---|---|
| C++20, Linux, Debug, CMake/Ninja | сборка выполнена |
| Нативный CTest | **8/8 пройдены** |
| Clang++ Debug + AddressSanitizer + UndefinedBehaviorSanitizer | **8/8 пройдены** |
| Проверка утечек ASan (`detect_leaks=1`) | явных срабатываний в тестах нет |
| Поколения ECS-ID, пределы, отказ при переполнении | пройдено |
| Попадания в разрушаемые объекты и защита стенами | пройдено |
| Совместимость загрузки FCSV v1/v2 | пройдено |
| Android Gradle + NDK + GameActivity | **не запускалось** — SDK/NDK отсутствуют |
| Android APK, целевые 60 FPS | **не проверены** |

Команды локального запуска:

```bash
cmake -S . -B build-native -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON
cmake --build build-native --parallel
ctest --test-dir build-native --output-on-failure

cmake -S . -B build-sanitized -DCMAKE_CXX_COMPILER=clang++ \
  -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-sanitized --parallel
ASAN_OPTIONS='detect_leaks=1:halt_on_error=1' UBSAN_OPTIONS='halt_on_error=1' \
  ctest --test-dir build-sanitized --output-on-failure
```

Тесты запускаются на Linux и **не заменяют** проверки сборки, графики, ввода и производительности на Android.
