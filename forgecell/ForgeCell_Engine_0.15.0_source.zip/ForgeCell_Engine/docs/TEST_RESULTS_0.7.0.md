# ForgeCell Engine 0.7.0 — результаты тестирования

Дата: 17.10.2026.

| Режим | Результат |
|---|---|
| Linux g++ 14.2, C++20 Debug | 7/7 CTest успешно |
| Linux g++ 14.2, ASan + UBSan, Debug | 7/7 CTest успешно |
| Тесты обратной совместимости FCSV v1 | успешно |
| Повреждённые/дублированные FCOB | отклоняются, состояние сохраняется |
| Экипировка, drag-and-drop и обработка отпускания пальца | успешно |
| ECS объекты, повторные удары, активация checkpoint | успешно |
| Android Studio / GameActivity / GLES3 сборка | не запускалась: нет SDK и NDK |
| Производительность на ARM64 устройстве | не измерялась |

Проверки ASan/UBSan запущены с `ASAN_OPTIONS=detect_leaks=0`, поэтому отсутствие утечек памяти ими **не доказано**.

Команды проверки:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel
ctest --test-dir build --output-on-failure

cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer -O1' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-asan --parallel
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build-asan --output-on-failure
```
