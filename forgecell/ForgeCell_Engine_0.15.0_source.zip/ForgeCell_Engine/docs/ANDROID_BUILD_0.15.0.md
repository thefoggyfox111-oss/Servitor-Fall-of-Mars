# ForgeCell Engine 0.15.0 — Android Studio / CI сборка

Текущий архив — исходники, **не готовый APK**. Сборка Android не подтверждена.

## Требования

- Android Studio с JDK 17.
- Android SDK Platform 35 и Build Tools 35.0.0.
- Android NDK 27.2.12479018.
- CMake 3.22.1.
- Gradle 8.13 (Gradle Wrapper JAR в архив не включён).

## Процедура

1. Открыть подпроект `android/` как Gradle-проект Android Studio.
2. Проверить путь к SDK (автоматически через Android Studio или `local.properties` **вне** репозитория), установить запрошенные компоненты через SDK Manager.
3. Выполнить `gradle :app:assembleDebug` в каталоге `android/` (либо Android Studio: Build > Build APK(s)).
4. Выполнить `python3 tools/check_apk.py android/app/build/outputs/apk/debug/app-debug.apk` **из корневого каталога архива**. Скрипт проверяет статический состав APK, а не запуск.
5. На ARM64 устройстве с GLES3: проверить отрисовку, мультитач, загрузку FC* ресурсов, сохранения и Logcat с фильтром `ForgeCell`. Выполнить замеры FPS и времени CPU/GPU.

## Автоматизация

Workflow `.github/workflows/validate.yml` устанавливает SDK/NDK/CMake/Gradle, запускает сборку и загружает debug APK как GitHub Actions artifact. Для запуска требуется репозиторий GitHub с содержимым корня архива; workflow сам по себе ранее **не запускался**.

Путь `android/app/build/outputs/apk/debug/app-debug.apk` появляется только после успешной сборки. Не создавать или не переименовывать файл вручную вместо компиляции.
