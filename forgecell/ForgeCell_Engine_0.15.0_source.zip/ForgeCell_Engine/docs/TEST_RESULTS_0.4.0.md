# ForgeCell Engine 0.4.0 — native verification

Verified in this authoring environment: Linux, CMake + C++20 compiler. No Android SDK/NDK or real Android runtime was available for building/verifying the APK. Tests cover the host C++ engine only.

## Standard CTest build

```
1/4 core_tests              Passed
2/4 combat_animation_tests  Passed
3/4 ai_equipment_tests      Passed
4/4 navigation_loot_tests   Passed
100% tests passed (0 failed)
```

## Sanitizers

Compiled separate CMake/Ninja build with `-fsanitize=address,undefined -fno-omit-frame-pointer` and linked with `-fsanitize=address,undefined`.

```
1/4 core_tests              Passed
2/4 combat_animation_tests  Passed
3/4 ai_equipment_tests      Passed
4/4 navigation_loot_tests   Passed
100% tests passed (0 failed)
```

New automated checks: routes over a short gap, rejection of too-wide gaps, raised platform hopping from side/below, landing from jump, boss phase trigger/attack cycle, single loot drop, pickup exactly once, backpack full preserves world loot, dropping a backpack item, pausing during inventory, equipment switching from inventory cells, touch mapping.

No claims are made about Android compilation, GPU correctness, 60 FPS stability, frame timing or thermals on mobile hardware.
