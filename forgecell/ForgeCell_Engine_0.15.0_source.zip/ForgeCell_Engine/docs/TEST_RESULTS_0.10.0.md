# ForgeCell Engine 0.10.0 — результаты тестирования

Дата: 17.10.2026

| Проверка | Результат |
|---|---|
| Linux C++20, GCC, CMake/Ninja Debug | **Собрано** |
| CTest обычный Debug | **10/10 пройдено** |
| CTest с AddressSanitizer и UndefinedBehaviorSanitizer | **10/10 пройдено** |
| FCIT v2: новые поля, валидатор, негативные кейсы | пройдено |
| FCIT v1: обратная загрузка с безопасными значениями по умолчанию | пройдено |
| UI selection model: первый тап выбор, второй установка | нативная логика пройдена |
| Сравнение по типам слотов, read-only, бонусы при смене | пройдено |
| Скорость игрока реально изменяется бонусом предмета | пройдено |
| FCSV v2: восстановление экипировки из внешнего каталога | пройдено |
| Навигация: высокий барьер и преодолимый низкий барьер | пройдено |
| APK сборка/GameActivity/OpenGL ES | **не проверено** |
| Частота кадров на реальном Android | **не измерена** |

Проверка санитайзерами выполнялась с `ASAN_OPTIONS=detect_leaks=0:abort_on_error=1` и `UBSAN_OPTIONS=halt_on_error=1`. Отдельное обнаружение утечек не проводилось. Нативные unit-тесты не доказывают успешность сборки Android/работу GPU/отсутствие ошибок управления мультитачем на устройстве.

```bash
cmake -S . -B build-native -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build build-native -j4
ctest --test-dir build-native --output-on-failure

cmake -S . -B build-sanitized -G Ninja -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-sanitized -j4
ASAN_OPTIONS='detect_leaks=0:abort_on_error=1' UBSAN_OPTIONS='halt_on_error=1' \
  ctest --test-dir build-sanitized --output-on-failure
```
