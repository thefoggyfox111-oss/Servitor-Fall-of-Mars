# ForgeCell Engine 0.13.0 — результаты тестирования

Дата: 18.10.2026. Среда: Linux x86_64, GCC, Ninja, CMake, Python 3.

## Нативные проверки

Команды:

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

**Итог: 13/13 пройдены**, 0 отказов. 12 предыдущих наборов, включая FCSV v1/v2/v3, ECS и лут, остаются зелёными. Тринадцатая проверка `android_project_structure` валидирует только структуру Android-исходников и ассеты.

В `navigation_loot_tests` дополнительно проверены: возврат NPC через разрыв пола к исходной платформе и посадка на ближайшую сверху платформу независимо от порядка геометрии.

## AddressSanitizer / UndefinedBehaviorSanitizer

```bash
cmake -S . -B build-san -G Ninja -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-san -j4
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
  ctest --test-dir build-san --output-on-failure
```

**Итог: 13/13 пройдены**, 0 отказов. Отсутствие утечек памяти не подтверждается: LeakSanitizer отключён.

## Android: ограничение

Android SDK, NDK и Gradle CLI в среде не найдены. Android Kotlin/NDK проект не компилировался, CI-конфигурация не запускалась на удалённом runner, APK отсутствует. OpenGL ES, GameActivity, сенсорное управление, FPS и производительность GPU не проверены. Скрипт проверки Android в CTest **не заменяет** `assembleDebug`.
