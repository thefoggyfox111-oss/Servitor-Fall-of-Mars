# ForgeCell Engine — история изменений

## 0.15.0 (18 октября 2026)

- Уточнён граф маршрутов врагов: старт восходящего прыжка должен быть физически доступен с опорной платформы; недостижимые рёбра исключаются.
- В инвентаре появился предварительный просмотр перетаскивания и подсветка цели; само перемещение остаётся на отпускании пальца.
- Подписи сенсорных кнопок и пустых слотов экипировки.
- GLES VBO и uniform locations переиспользуются; буфер GPU увеличивается только при необходимости.
- Новые интеграционные C++-тесты. 15/15 CTest в Debug и с ASan/UBSan; Android APK не собран.

---

# ForgeCell Engine — история изменений

## 0.14.0 (18 октября 2026)

- Сортировка рюкзака по категориям, редкости и уровню, со стабильными физическими UID предметов.
- Сенсорная кнопка сортировки, клавиатурная команда `S`; выбор сбрасывается при сортировке.
- Защита от выбрасывания предметов без явного выбора ячейки.
- Восстановление врагов после падения с учётом собственного `spawnY` и сбросом интерполяции.
- Выбор ближайшего потолка при прыжке вне зависимости от порядка объектов уровня.
- Новый `inventory_sort_recovery_tests`; 14/14 наборов Linux+ASan/UBSan.
- Post-build CI проверка комплектации APK; Android APK в текущей среде не собран и не испытан.

---

# ForgeCell Engine — история изменений

## 0.13.0 (18 октября 2026)

- Возврат врагов на домашние платформы с прыжками через разрывы; исходная высота задаётся при загрузке FCEY.
- При падении всегда выбирается ближайшая сверху пересечённая поверхность, независимо от порядка коллайдеров.
- Пиксельные подписи выбранного предмета и характеристик в UI.
- Android системная тема вместо отсутствующей AppCompat; ресурсы без сжатия.
- GitHub Actions CI для попытки Android APK build и нативных тестов (CI удалённо не выполнялся).
- 13/13 наборов Linux тестов с ASan/UBSan. APK не собран.

---

# ForgeCell Engine — история изменений

## 0.12.0 (18 октября 2026)

- Добавлены настраиваемые таблицы добычи FCLT v1 и упаковщик JSON.
- Воспроизводимые уникальные аффиксы на ECS-предметах, сохранение FCSV v3.
- Исправлен конфликт владения уже собранной уникальной добычей при загрузке.
- Навигация NPC оценивает стоимость пути с подъёмами и разрывами.
- 12/12 наборов Linux/ASan/UBSan; Android APK не собран.

---

# ForgeCell Engine — история изменений

## 0.11.0 (17 октября 2026)

- Уникальные `ItemInstance` и аффиксы, бонусы в уроне, скоростях, защите, лечении и сравнении слотов.
- FCSV v3 с сериализацией записей физических экземпляров и чтением исторических v1/v2.
- Поддержка выбрасывания/подбора индивидуального предмета без потери UID и аффиксов.
- Кэш маршрутов врагов на 0,2 с с инвалидированием при смещении цели и приземлении.
- Android GUI: числовые различия и отметка индивидуальных копий. Два стартовых экземпляра в демо.
- 11/11 наборов тестов на Linux и 11/11 ASan/UBSan, тесты GUI на Android отсутствуют.
- APK не собран: нет SDK/NDK/Gradle в окружении.

# ForgeCell Engine — история изменений

## 0.10.0 (17 октября 2026)

- FCIT v2 и каталог из JSON: rarity/level/speed_bonus_pct; FCIT v1 по-прежнему читается.
- Read-only сравнение параметров по слотам; бонус скорости применяется к фактическому движению.
- Android UI: редкость, дельта-индикаторы и двухэтапное выделение/экипировка; drag-and-drop сохранён.
- Навигация не планирует прыжки сквозь высокие стены в разрывах пола.
- Формат FCSV v2 сохранён, добавлен 10-й набор нативных тестов.
- 10/10 в обычной сборке и 10/10 с ASan/UBSan (detect_leaks=0).
- APK не собран, Android производительность и UI визуально не проверялись.

# ForgeCell Engine — история изменений

## 0.9.0 (17 октября 2026)

- Переведено хранение противников на `EnemyActors` с `EntityRegistry` и `ComponentPool<Combatant>`. Сохранена проекционная итерация для существующих игровых систем.
- Стабильные ID контента отделены от runtime ECS-хендлов. Ограничение 128 врагов, проверка дубликатов и ошибочных конфигураций.
- Разработаны `FCVA` визуальный каталог и Python-пакер: до 32 графических archetype slots с проверкой UV и размеров.
- `FCEY v2` добавляет `visual_index`; сохранено чтение FCEY v1 и совместимость FCSV v2.
- Рендерер GLES использует внешний FCVA вместо жёстко заданной раскладки UV (Android-часть не проверена на устройстве).
- Добавлен 9-й набор unit-тестов. 9/9 обычных CTest и 9/9 с GCC ASan/UBSan.
- APK не собран: SDK/NDK/Gradle отсутствуют в доступной среде.


## 0.8.0 (17 октября 2026)

- Отдельная ECS-подсистема `TransientEntities` для снарядов и добычи: два плотных пула и общий реестр с поколениями ID.
- Ограничения 256 снарядов и 1024 подбираемых предмета; удаление и повторное использование сущностей без обращений по устаревшим ID.
- Рендерер, боевая логика и сериализатор используют ECS-данные. FCSV v2 остаётся без изменений; снаряды при загрузке не восстанавливаются.
- Выстрелы игрока наносят урон разрушаемым контейнерам с учётом первой точки столкновения с препятствиями.
- При переполнении пула снарядов попытка стрельбы не расходует патроны.
- Добавлен `transient_ecs_tests`: 8/8 нативных тестов и 8/8 с ASan/UBSan (включено обнаружение утечек).
- Android APK и работа на устройстве не подтверждены: SDK/NDK недоступны.

# ForgeCell Engine — история изменений

## 0.7.0 (17 октября 2026)

- ECS WorldObjectSystem с плотными компонентами и проверяемыми поколениями ID; объекты `crate` и `checkpoint`.
- Импорт объектов JSON → FCOB v1 с валидацией и атомарной заменой сцены.
- Игровые разрушения: ударный serial, один урон за одно применение атаки.
- Касание/перетаскивание инвентаря: 24 ячейки, 6 слотов экипировки, проверка совместимости, отклонение некорректных обменов.
- FCSV v2: сохраняет состояние ECS объектов, читает старые FCSV v1.
- Автосохранение на Android при активировании контрольной точки (пока без экрана возрождения).
- Добавлен седьмой набор регрессионных тестов. 7/7 на Linux и 7/7 с ASan/UBSan.
- APK не собран: Android SDK/NDK недоступны. Стабильность и 60 FPS на устройстве не проверены.

# ForgeCell Engine — история изменений

## 0.6.0 (17 октября 2026)

- Полноценный плотный `ComponentPool` с O(1) вставкой/удалением, проверкой поколений `EntityRegistry` и безопасным `clear`.
- Первый реально используемый ECS-модуль: временные боевые эффекты (до 256 одновременно), отслеживаемые независимо от кадров отрисовки.
- События попаданий, смерти и выстрелов отделены от симуляции урона и преобразуются в VFX.
- У каждого противника собственный Animator; состояние атаки/бега выбирает AI в фиксированном тике.
- Пять независимых ресурсных профилей FCAN для типов врагов, отклонение некорректных профилей без изменения работающих данных.
- Общий FCAT 1056×1200 с отдельными временными пиксельными силуэтами врагов; 6 персонажей × 8 треков × 16 уникальных кадров проверяются автоматическим тестом.
- Отсечение невидимых статических объектов и врагов при отрисовке; ограничение расчётов далёких неагрессивных врагов; предварительное резервирование динамических контейнеров.
- Новый `ecs_animation_vfx_tests` и повторная проверка всех шести наборов с AddressSanitizer/UndefinedBehaviorSanitizer.
- **Ограничение:** Android SDK/NDK и устройство недоступны, APK и 60 FPS на телефоне не проверены.

# ForgeCell Engine — история изменений

## 0.5.0 (17 октября 2026)

- Импорт противников FCEY v1 из внешнего JSON с проверкой профилей, спавнов, ID и существования добычи.
- Набор предметов FCIT v1: броня, два пассивных эффекта, лечащий расходник; бонусы здоровья, урона, снижения повреждений.
- Инвентарь отображает категории новых предметов и занятые дополнительные слоты; добавлена кнопка расходника.
- FCSV v1 для контрольных точек: проверки длины, CRC32 и каталожных ссылок; атомарная замена файла.
- Android-код: начальная загрузка конфигураций, восстановление сохранения после загрузки ресурсов, периодическое сохранение и сохранение при паузе.
- Пятый нативный набор тестов: сохранение, повреждения, совместимость и конфигурации.

# ForgeCell Engine changelog

## 0.4.0 — navigation / boss / drops / prototype inventory

- Added graph-based platform hop planning with bounded jump height, ledge distance, ascent and fall constraints; basic enemy airborne physics and landing.
- Fixed solid-platform underside handling, timed horizontal motion during upward jumps, and edge approach when the enemy starts below an overhead solid.
- Added two-phase boss with different attack timing and an alternating three-projectile volley in phase 2; shared placeholder visuals.
- Added heavy/boss weapon pickups, backpack collection capacity checks, exactly-once death drops and backpack world drops.
- Added inventory/interact touch controls, a pausing 24-cell menu overlay and basic visual item/category indicators.
- Added host regression tests for platform gaps, solid raised platforms, boss state, loot duplication, full inventory, menu pause, weapon swapping, dropping and touch mapping.
- Verified all four CTest suites on native Linux, then with ASan/UBSan; Android build remains unverified.

## 0.3.0 — hostile AI / data-defined equipment

- Added enemy FSM and three hostile archetypes: grunt, heavy and ranged gunner.
- Added patrol/chase/stun/attack startup/active/recovery/return/death and world-space edge checks.
- Added enemy melee damage and swept hostile projectiles, roll/post-hit immunity.
- Mapped enemy states to 16-frame demo atlas rows and drew attack telegraphs.
- Added two equipped weapon slots with class checks and a 24-cell backpack.
- Added configurable damage, attack timing, projectile speed, magazine size, fire rate and reload.
- Added editable demo weapons JSON, FCWP packer and atomic format validator.
- Added touch and key/controller equipment cycling, ammo magazine indicator.
- Added AI/equipment/negative loader regression suite; 3/3 CTest suites pass.
- Re-ran all 3 tests under ASan + UBSan on the host.


## 0.2.0 — combat / authored animations

- Added native melee combat with dedicated gameplay windows and once-per-swing damage.
- Added ranged projectiles with continuous segment-vs-expanded-AABB collision.
- Added ammo, rate limiting, training dummy HP/hit feedback, basic renderer integration.
- Added shoot button, mouse-independent multitouch input edge, controller Y / keyboard K.
- Added 8×16 placeholder animation frames (new shooting row and existing state rows).
- Added clip/frame duration runtime, attachments, event masks and non-looping playback.
- Added authorable JSON animations -> little-endian FCAN binary packer/validator.
- Changed parallax draw to interpolate the same camera transform as the world.
- Added combat/animation/asset regression tests; both CTest targets pass on host.

## 0.1.0 — native/core and Android source foundation

- Initial simulation, camera, collision geometry, touch, basic ECS and native tests.
- GameActivity / GLES3 frontend (source only, unbuilt APK).
