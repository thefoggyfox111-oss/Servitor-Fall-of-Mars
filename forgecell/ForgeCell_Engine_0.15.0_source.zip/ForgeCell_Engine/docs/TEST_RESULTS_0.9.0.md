# ForgeCell Engine 0.9.0 — отчёт о проверках

Дата: 17.10.2026

| Проверка | Результат |
|---|---|
| C++20 Debug, Linux, CMake/Ninja, GCC | сборка выполнена |
| Все нативные тесты, обычная сборка | **9/9 пройдены** |
| Все нативные тесты, GCC ASan + UBSan | **9/9 пройдены** |
| Реестр противников: поколения ID, удаление, повторное выделение | пройдено |
| Ограничение 128 объектов, дубликаты, атомарная загрузка | пройдено |
| FCVA v1: UV, координаты, повреждённый файл, дубликаты | пройдено |
| FCEY v2 с visual_index и чтение FCEY v1 | пройдено |
| Сохранения FCSV v2 после миграции противников в ECS | пройдено |
| Gradle/NDK GameActivity + OpenGL ES frontend | **не собраны и не запущены** |
| FPS и производительность на Android | **не измерялись** |

Команды:

```bash
cmake -S . -B build-native -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build build-native -j4
ctest --test-dir build-native --output-on-failure

cmake -S . -B build-sanitized -G Ninja -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-sanitized -j4
ASAN_OPTIONS='detect_leaks=0:abort_on_error=1' UBSAN_OPTIONS='halt_on_error=1' \
  ctest --test-dir build-sanitized --output-on-failure
```

Sanitizer-проверки выполнялись с `detect_leaks=0`; отдельной проверкой утечек результаты 0.9.0 не подтверждены. Прохождение unit-тестов не гарантирует совместимость APK, работу GameActivity/GLES и стабильные 60 FPS.
