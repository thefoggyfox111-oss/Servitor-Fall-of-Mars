# ForgeCell: двоичные форматы ресурсов и сохранений (0.5.0)

Все целочисленные поля — **little-endian**. Строки — UTF-8, с префиксом `uint16` (длина в байтах), без нулевого терминатора. `float` — IEEE 754 binary32. Проверка целостности и ограничений выполняется перед заменой действующих данных.

## FCEY v1 — противники

Заголовок: ASCII `FCEY` (4 байта), `uint16 version=1`, `uint16 count` (1..128).

Запись: `uint32 id`, `uint16 role` (dummy/grunt/heavy/gunner/boss = 0..4), `uint32 health`, девять `float`: `x`, `y`, `chase_speed`, `patrol_speed`, `detection_range`, `attack_range`, `startup`, `active`, `recovery`; `uint32 damage`, `string loot_weapon_id` (может быть пустой).

Размер файла ограничен 64 КиБ. ID уникальные и положительные, не допускаются нечисловые и неограниченные коэффициенты. Спавн дополнительно проверяется относительно текущей геометрии. Профиль босса второй фазы пока использует установленные в C++ правила.

## FCIT v1 — предметы

Заголовок: ASCII `FCIT`, `uint16 version=1`, `uint16 count` (1..128).

Запись: `string id` (1..63 байта), `string name` (1..95), `uint16 kind` (`0=armor`, `1=passive`, `2=consumable`), `uint32 health_bonus`, `uint32 damage_bonus`, `uint32 damage_reduction`, `uint32 heal`.

Все бонусы ограничены 0..10000. Для расходников `heal > 0`. ID не могут пересекаться с каталогом оружия.

## FCSV v1 — сохранения

Заголовок: ASCII `FCSV`, `uint16 version=1`, `uint16 flags=0`, `uint32 payload_size`, `uint32 crc32(payload)`. Максимальный размер файла 256 КиБ.

Тело: `string level_id` (текущая реализация `demo`), `float player_x`, `float player_y`, `uint32 health`, `uint8 facing_right`, `uint32 ammo`, `uint32 magazine`; затем два `string equipped_weapon_id`, четыре `string accessory_id`, 24 `string backpack_item_id`. Далее `uint16 enemy_count`, каждая запись: `uint32 id`, `float x`, `float y`, `uint32 health`, `uint16 boss_phase`, `uint32 attacks_finished`, `uint8 loot_spawned`. Затем `uint16 pickup_count` и записи: `uint32 id`, `string weapon_id`, `float x`, `float y`, `uint8 collected`.

`CRC32` — стандартный CRC-32/ISO-HDLC (полином в отражённой форме `0xEDB88320`, `init=0xFFFFFFFF`, `xorout=0xFFFFFFFF`). CRC защищает от случайных повреждений, **не** от намеренной подделки. При несовпадении состава противников или неизвестных ID сохранение отклоняется целиком. При успешной загрузке восстанавливается игровая позиция, а кратковременные атаки, снаряды, ускорения и перекаты обнуляются. Такой тип сохранения является контрольной точкой, а не полным снимком каждого кадра.

Файловая запись: `*.tmp` -> последовательная запись -> `fsync` -> `rename` в том же каталоге -> попытка `fsync` каталога. Тестируется локально на Linux; поведение на Android требует проверки.

## FCWP, FCAN, FCL

Эти форматы введены до версии 0.5.0. Их контракт см. в конвертерах `tools/pack_weapons.py`, `tools/pack_animations.py`, `tools/import_ldtk.py` и соответствующих декодерах C++.
