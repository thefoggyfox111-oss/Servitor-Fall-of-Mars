# ForgeCell Engine 0.14.0 — результаты тестирования

Дата: 18 октября 2026. Хост: Linux x86_64; CMake, GCC, Python 3.

## Проверка C++20

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON
cmake --build build --parallel 4
ctest --test-dir build --output-on-failure
```

**Результат: 14/14 PASS.** Предыдущие 13 тестов и новый `inventory_sort_recovery_tests` проходят.
В сценариях проверены: устойчивость сортировки, границы слотов, сохранение UID с аффиксами,
повторная загрузка FCSV v3, сенсорный ввод SORT/DROP, сброс выделения, невозможность сброса без выбора,
восстановление NPC по `spawnY` после падения и приоритет ближайшей нижней грани потолка.

## Санитайзеры

```bash
cmake -S . -B build-san -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-san --parallel 4
ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 \
  ctest --test-dir build-san --output-on-failure
```

**Результат: 14/14 PASS, 0 падений.** LeakSanitizer отключён: отсутствие утечек отдельно не проверялось.

## Android

- Проверка `android_project_structure.py` проходит, но анализирует лишь AndroidManifest, конфигурацию Gradle,
  сигнатуры ассетов и присутствие скрипта упаковки в CI.
- Версия `androidx.games:games-activity:4.4.2` подтверждена документацией AndroidX; проект не собирался с Android SDK/NDK.
- APK, OpenGL ES и GameActivity не проверялись на устройстве, FPS не измерялся.
- Скрипт `tools/check_apk.py` проверяет **только существующий** APK; в этой среде файла APK нет.
- Нельзя считать CI конфигурацию или host-only тест доказательством Android-совместимости.
