# ForgeCell Engine 0.12.0 — результаты проверки

Дата: 18.10.2026. Linux x86_64, GCC, CMake/Ninja, CTest. Android SDK, NDK, Gradle не установлены; APK не создавался.

## Обычная сборка

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

**Итог: 12/12 наборов пройдены**, 0 провалов, тестовое время около 0,53 с. Проверены все прежние 11 наборов.

## Санитайзеры

```bash
cmake -S . -B build_san -G Ninja -DCMAKE_BUILD_TYPE=Debug -DFORGECELL_BUILD_TESTS=ON \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build_san -j4
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
  ctest --test-dir build_san --output-on-failure
```

**Итог: 12/12 наборов пройдены**, 0 провалов, тестовое время около 2,82 с. ASan/UBSan ошибок не выдали. Детектор утечек отключён; отсутствие утечек не подтверждено.

## Новый набор `loot_rules_pathfinding_tests`

- FCLT v1 распаковывается и совпадает с seed из JSON; неверная роль, дубликат, диапазон и усечённый файл отклоняются без изменения текущих таблиц.
- Выпадение с теми же входами возвращает одинаковые характеристики. Подтверждены точное число уникальных бонусов и границы значений.
- Убийство врага создаёт ECS-подбор с новым уникальным токеном и привязанными бонусами.
- Цикл FCSV v3: уникальная добыча на земле → загрузка → подбор → повторное сохранение → повторная загрузка сохраняет единственного владельца предмета и его бонусы.
- При заполненных 1024 слотах ECS не создаются потерянные записи `ItemInstance`.
- В сцене с двумя альтернативными путями алгоритм выбирает более простой маршрут, хотя поверхность с более сложным подъёмом перечислена раньше.

## Не проверено

GameActivity, OpenGL ES, работа управления, качество Android UI, реальные FPS, память GPU и производительность на смартфоне. Текущая версия — нативный прототип, не релиз движка 1.0.
