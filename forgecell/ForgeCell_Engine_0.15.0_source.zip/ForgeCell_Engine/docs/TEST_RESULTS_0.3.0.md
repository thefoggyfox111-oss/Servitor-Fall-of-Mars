# ForgeCell Engine 0.3.0 — host verification

Test environment: Linux, CMake 3.31.6, native GCC C++20 compiler. Tests compiled and executed against the actual source tree; they do **not** prove Android compatibility.

## Native tests

```
ctest --test-dir build-native --output-on-failure
1/3 core_tests              Passed
2/3 combat_animation_tests  Passed
3/3 ai_equipment_tests      Passed
100% tests passed (0 failed)
```

## Sanitizers

```
cmake -S . -B build-sanitized -G Ninja -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-sanitized --parallel
ASAN_OPTIONS=detect_leaks=1 ctest --test-dir build-sanitized --output-on-failure
```

Result: **3/3 passed** under AddressSanitizer and UndefinedBehaviorSanitizer.

Tested concerns include:
- melee startup/active/recovery and single-target damage gating;
- physically swept projectiles occluded by thin walls;
- enemy windup precedes hit, attack event is committed once;
- player i-frames prevent damage from telegraphed heavy attack;
- hostile bullets hit a player and are blocked by world collision;
- enemy pursuit does not continue off a platform edge;
- 24-slot inventory swap retains prior equipped item and class checks;
- external FCWP config correctly changes damage/timing and rifle magazine;
- corrupt/truncated/trailing FCWP input is rejected atomically;
- simultaneous movement and two equipment controls work with multiple pointers;
- FCAN animation frame metadata/events and invalid file protection.

## Not tested

Android native compilation, Kotlin/GameActivity integration, EGL/GLES rendering on hardware, device thermal behavior, touch safe areas and sustained 60 FPS. No APK was produced.
