# ForgeCell Engine 0.5.0 — отчёт о проверке

**Дата:** 17.10.2026. **Платформа:** Linux, нативный C++20.

- Debug CMake build: **успешно**.
- `ctest`: **5/5** наборов тестов пройдены (`core_tests`, `combat_animation_tests`, `ai_equipment_tests`, `navigation_loot_tests`, `save_content_tests`).
- ASan + UBSan Debug build: **5/5**, ошибок по выводу тестов нет (ASAN_OPTIONS=detect_leaks=0).
- Проверено: чтение FCEY, FCIT, повреждённые файлы, новые слоты экипировки, бонусы, лечение, FCSV round-trip, сброс транзиентных событий, CRC, обрезка данных, неподдерживаемая версия, несовместимые каталоги, атомарная файловая запись и восстановление.
- Повторный прогон после финальных изменений сохранения и UI: 5/5 обычных тестов и 5/5 тестов с ASan/UBSan.

**Не проверено:** Android Studio/Gradle сборка, Android APK, GameActivity/GLES, реальная производительность и UI на телефоне. На CPU-тестах значения 60 FPS измерять невозможно.
