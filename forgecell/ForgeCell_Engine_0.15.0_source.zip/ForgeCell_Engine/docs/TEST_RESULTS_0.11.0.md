# ForgeCell Engine 0.11.0 — проверка

Дата: 17.10.2026. Окружение: Linux x86_64, GCC/G++, CMake, CTest; Android SDK/NDK/Gradle недоступны.

## Нативная сборка

`cmake -S . -B build -DFORGECELL_BUILD_TESTS=ON`
`cmake --build build -j6`
`ctest --test-dir build --output-on-failure`

**Результат:** 11/11 тестовых наборов пройдены. Общая длительность запуска тестов ~0,5 с.

## ASan/UBSan

`cmake -S . -B build-sanitized -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_FLAGS="-fsanitize=address,undefined -fno-omit-frame-pointer -O1" -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address,undefined"`
`cmake --build build-sanitized -j3`
`ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir build-sanitized --output-on-failure`

**Результат:** 11/11 тестовых наборов пройдены. ASan/UBSan ошибок не выдали. LeakSanitizer был отключён (`detect_leaks=0`); отсутствие утечек памяти не доказано.

## Покрытие новой функциональности

`item_instances_save_v3_tests`: два экземпляра одного шаблона с разными бонусами, изменённые характеристики и сравнение слотов, физический UID при обмене, бонус урона меча, выброс и подбор уникальной вещи, сохранение/восстановление FCSV v3, отклонение изменённого поля с пересчитанной CRC, чтение FCSV v2, атомарность неуспешного восстановления, сокращение числа запросов навигации.

Обновлён `world_objects_inventory_tests` для FCSV v3 и регрессионной миграции FCSV v1. Остальные 9 наборов продолжают проходить.

## Не проверено

APK не собран. OpenGL ES 3.0, UI, touch, GameActivity, FPS 30/60 и производительность на смартфоне не подтверждены. Автоматические тесты не доказывают готовность движка к релизу 1.0.
