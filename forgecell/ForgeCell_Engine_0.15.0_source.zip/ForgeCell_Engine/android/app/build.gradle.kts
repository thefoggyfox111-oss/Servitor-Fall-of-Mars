plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.forgecell.engine"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.forgecell.engine"
        minSdk = 26
        targetSdk = 35
        versionCode = 15
        versionName = "0.15.0"
        ndk { abiFilters += "arm64-v8a" }
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++20", "-Wall", "-Wextra")
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { prefab = true }
    // AAsset_getBuffer is used for binary FC* tables and the RGBA sprite atlas.
    // Keep these resources uncompressed in the APK for predictable load cost.
    androidResources {
        noCompress += listOf("rgba", "fcan", "fcva", "fcey", "fcl", "fcit", "fcwp", "fclt", "fcob")
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
}
dependencies {
    implementation("androidx.games:games-activity:4.4.2")
    implementation("androidx.appcompat:appcompat:1.7.1")
}
