#include <utility>
#include <array>
#include "GlRenderer.hpp"
#include "forge/Simulation.hpp"
#include "forge/TouchControls.hpp"
#include "forge/WorldFormat.hpp"
#include "forge/AnimationFormat.hpp"
#include "forge/SaveSystem.hpp"
#include <game-activity/native_app_glue/android_native_app_glue.h>
#include <android/log.h>
#include <android/input.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <chrono>
#include <algorithm>
#include <memory>
#include <span>
#include <string>

namespace {
using clock_type = std::chrono::steady_clock;
struct NativeApp {
    android_app* app = nullptr;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    forge::Simulation game;
    forge::FixedStepper stepper;
    forge::TouchControls touch;
    forge::GlRenderer renderer;
    bool resumed = true;
    bool ready = false;
    bool keyLeft = false, keyRight = false, keyJump = false;
    bool jumpEdge = false, rollEdge = false, attackEdge = false, shootEdge = false;
    bool swapMeleeEdge = false, swapRangedEdge = false;
    bool inventoryEdge = false, interactEdge = false, consumableEdge = false, sortEdge = false;
    double autosaveElapsed=0;
    uint32_t savedCheckpointId=0;
    clock_type::time_point lastFrame = clock_type::now();
    void destroySurface() {
        ready = false;
        if(display != EGL_NO_DISPLAY) {
            if(context != EGL_NO_CONTEXT) {
                eglMakeCurrent(display,surface,surface,context);
                renderer.release();
                eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
            }
            if(surface != EGL_NO_SURFACE) eglDestroySurface(display,surface);
            if(context != EGL_NO_CONTEXT) eglDestroyContext(display,context);
            eglTerminate(display);
        }
        display = EGL_NO_DISPLAY; surface = EGL_NO_SURFACE; context = EGL_NO_CONTEXT;
        touch.clear(); stepper.reset();
    }
    std::string saveFile() const {
        const char* directory=app && app->activity?app->activity->internalDataPath:nullptr;
        if(!directory || !*directory)return {};
        return std::string(directory)+"/forgecell_demo.fcsv";
    }
    void saveProgress() {
        const auto path=saveFile();if(path.empty())return;
        std::string error;
        if(!forge::saveCheckpoint(path,game,error))
            __android_log_print(ANDROID_LOG_WARN,"ForgeCell","Save failed: %s",error.c_str());
    }
    void loadProgress() {
        const auto path=saveFile();if(path.empty())return;
        std::string error;
        if(!forge::loadCheckpoint(path,game,error))
            __android_log_print(ANDROID_LOG_INFO,"ForgeCell","No compatible checkpoint: %s",error.c_str());
        else {
            savedCheckpointId=game.objects.lastCheckpoint();
            __android_log_print(ANDROID_LOG_INFO,"ForgeCell","Checkpoint restored");
        }
    }
    void loadGeometry() {
        AAsset* asset=AAssetManager_open(app->activity->assetManager,"demo.fcl",AASSET_MODE_BUFFER);
        if(!asset) return;
        const auto len=AAsset_getLength(asset);
        const auto* bytes=static_cast<const std::byte*>(AAsset_getBuffer(asset));
        if(bytes && len>0) {
            std::string error;
            if(!forge::loadWorldBinary(std::span<const std::byte>(bytes,static_cast<size_t>(len)),
                                       game.world,error)) {
                __android_log_print(ANDROID_LOG_WARN,"ForgeCell","Level rejected: %s",error.c_str());
            }
        }
        AAsset_close(asset);
        AAsset* animationAsset=AAssetManager_open(app->activity->assetManager,"demo.fcan",AASSET_MODE_BUFFER);
        if(animationAsset) {
            const auto size=AAsset_getLength(animationAsset);
            const auto* ptr=static_cast<const std::byte*>(AAsset_getBuffer(animationAsset));
            if(ptr && size>0) {
                std::string error;
                if(!forge::loadAnimationBinary({ptr,static_cast<size_t>(size)},
                    game.player.animator,error))
                    __android_log_print(ANDROID_LOG_WARN,"ForgeCell","Animation rejected: %s",error.c_str());
            }
            AAsset_close(animationAsset);
        }
        AAsset* weapons=AAssetManager_open(app->activity->assetManager,"demo.fcwp",AASSET_MODE_BUFFER);
        if(weapons) {
            const auto size=AAsset_getLength(weapons);
            const auto* ptr=static_cast<const std::byte*>(AAsset_getBuffer(weapons));
            if(ptr && size>0) {
                std::string error;
                if(!game.combat.loadEquipment({ptr,static_cast<size_t>(size)},error))
                    __android_log_print(ANDROID_LOG_WARN,"ForgeCell","Weapons rejected: %s",error.c_str());
            }
            AAsset_close(weapons);
        }
        auto loadOptional=[&](const char* file,auto loader) {
            AAsset* asset=AAssetManager_open(app->activity->assetManager,file,AASSET_MODE_BUFFER);
            if(!asset)return;
            const auto size=AAsset_getLength(asset);
            const auto* ptr=static_cast<const std::byte*>(AAsset_getBuffer(asset));
            if(ptr && size>0) {
                std::string error;
                if(!loader(std::span<const std::byte>(ptr,static_cast<size_t>(size)),error))
                    __android_log_print(ANDROID_LOG_WARN,"ForgeCell","%s rejected: %s",file,error.c_str());
            }
            AAsset_close(asset);
        };
        loadOptional("demo.fcit",[&](auto data,std::string& error) {
            return game.combat.loadItems(data,error);
        });
        // Two deliberately different physical copies for manual inventory testing.
        // Saved FCSV v3 data overrides these starter samples upon checkpoint load.
        game.combat.equipment.addInstanceToBackpack("vitality_chip",{8,2,1,4,0});
        game.combat.equipment.addInstanceToBackpack("rusted_sword",{0,9,0,0,0});
        loadOptional("demo.fclt",[&](auto data,std::string& error) {
            return game.combat.loadLoot(data,error);
        });
        loadOptional("demo.fcey",[&](auto data,std::string& error) {
            return game.combat.loadEnemies(data,game.world,error);
        });
        // Each archetype has independent FCAN timing/anchor data (same validated format).
        for(const auto& entry : std::array<std::pair<const char*,forge::EnemyRole>,5>{{
                {"enemy_dummy.fcan",forge::EnemyRole::Dummy},
                {"enemy_grunt.fcan",forge::EnemyRole::Grunt},
                {"enemy_heavy.fcan",forge::EnemyRole::Heavy},
                {"enemy_gunner.fcan",forge::EnemyRole::Gunner},
                {"enemy_boss.fcan",forge::EnemyRole::Boss}}}) {
            loadOptional(entry.first,[&](auto data,std::string& error) {
                return game.combat.loadEnemyAnimation(entry.second,data,error);
            });
        }
        loadOptional("demo.fcob",[&](auto data,std::string& error) {
            return game.objects.load(data,game.world,error);
        });
        loadProgress(); // after catalogs + world: IDs in save must resolve
    }
    void initSurface() {
        destroySurface();
        if (!app->window) return;
        display=eglGetDisplay(EGL_DEFAULT_DISPLAY);
        if(display == EGL_NO_DISPLAY || !eglInitialize(display,nullptr,nullptr)) return;
        const EGLint attributes[] = {
            EGL_SURFACE_TYPE,EGL_WINDOW_BIT,
            EGL_RENDERABLE_TYPE,EGL_OPENGL_ES3_BIT_KHR,
            EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,
            EGL_NONE
        };
        EGLConfig config = nullptr;
        EGLint count = 0;
        if(!eglChooseConfig(display,attributes,&config,1,&count) || count < 1) return;
        EGLint nativeFormat=0;
        eglGetConfigAttrib(display,config,EGL_NATIVE_VISUAL_ID,&nativeFormat);
        ANativeWindow_setBuffersGeometry(app->window,0,0,nativeFormat);
        surface=eglCreateWindowSurface(display,config,app->window,nullptr);
        const EGLint contextAttributes[] = {EGL_CONTEXT_CLIENT_VERSION,3,EGL_NONE};
        context=eglCreateContext(display,config,EGL_NO_CONTEXT,contextAttributes);
        if(surface==EGL_NO_SURFACE || context==EGL_NO_CONTEXT ||
           !eglMakeCurrent(display,surface,surface,context)) {destroySurface(); return;}
        eglSwapInterval(display,1);
        if (!renderer.init(app->activity->assetManager)) {destroySurface();return;}
        onResize();
        ready = true;
        lastFrame = clock_type::now();
        stepper.reset();
        __android_log_print(ANDROID_LOG_INFO,"ForgeCell","GLES3 renderer initialized");
    }
    void onResize() {
        if(display==EGL_NO_DISPLAY || surface==EGL_NO_SURFACE) return;
        EGLint w=0,h=0;
        eglQuerySurface(display,surface,EGL_WIDTH,&w);
        eglQuerySurface(display,surface,EGL_HEIGHT,&h);
        renderer.resize(w,h);
        touch.resize(renderer.viewWidth(),360);
        game.camera.viewWidth=renderer.viewWidth();
    }
    void onPointer(int32_t id, float pixelX,float pixelY, int action) {
        if(!ready) return;
        EGLint screenH=1;
        eglQuerySurface(display,surface,EGL_HEIGHT,&screenH);
        const float scaledX=pixelX*360.0f / std::max(1,screenH);
        const float scaledY=pixelY*360.0f / std::max(1,screenH);
        if(action==0) touch.pointerDown(id,scaledX,scaledY);
        if(action==1) touch.pointerMove(id,scaledX,scaledY);
        if(action==2) touch.pointerUp(id,scaledX,scaledY);
    }
    void handleInputs() {
        android_input_buffer* buffer=android_app_swap_input_buffers(app);
        if(!buffer) return;
        for(uint64_t i=0;i<buffer->motionEventsCount;++i) {
            const auto& event=buffer->motionEvents[i];
            if(!event.pointerCount) continue;
            const int masked=event.action & AMOTION_EVENT_ACTION_MASK;
            const uint32_t index=(event.action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK)
                >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
            if(masked==AMOTION_EVENT_ACTION_CANCEL) { touch.clear(); continue; }
            if(masked==AMOTION_EVENT_ACTION_MOVE) {
                for(uint32_t p=0;p<event.pointerCount;++p) {
                    const auto& point=event.pointers[p];
                    onPointer(point.id,GameActivityPointerAxes_getX(&point),
                              GameActivityPointerAxes_getY(&point),1);
                }
            } else if(index<event.pointerCount) {
                const auto& point=event.pointers[index];
                const bool down=masked==AMOTION_EVENT_ACTION_DOWN || masked==AMOTION_EVENT_ACTION_POINTER_DOWN;
                const bool up=masked==AMOTION_EVENT_ACTION_UP || masked==AMOTION_EVENT_ACTION_POINTER_UP;
                if(down || up) onPointer(point.id,GameActivityPointerAxes_getX(&point),
                    GameActivityPointerAxes_getY(&point),down?0:2);
            }
        }
        android_app_clear_motion_events(buffer);
        for(uint64_t i=0;i<buffer->keyEventsCount;++i) {
            const auto& key=buffer->keyEvents[i];
            const bool pressed=key.action==AKEY_EVENT_ACTION_DOWN;
            switch(key.keyCode) {
                case AKEYCODE_DPAD_LEFT: case AKEYCODE_A: keyLeft=pressed;break;
                case AKEYCODE_DPAD_RIGHT: case AKEYCODE_D: keyRight=pressed;break;
                case AKEYCODE_BUTTON_A: case AKEYCODE_SPACE:
                    if(pressed && !keyJump) jumpEdge=true;
                    keyJump=pressed;break;
                case AKEYCODE_BUTTON_B: if(pressed) rollEdge=true;break;
                case AKEYCODE_BUTTON_X: case AKEYCODE_J: if(pressed) attackEdge=true;break;
                case AKEYCODE_BUTTON_Y: case AKEYCODE_K: if(pressed) shootEdge=true;break;
                case AKEYCODE_Q: case AKEYCODE_BUTTON_L1:
                    if(pressed)swapMeleeEdge=true;break;
                case AKEYCODE_E: case AKEYCODE_BUTTON_R1:
                    if(pressed)swapRangedEdge=true;break;
                case AKEYCODE_I: case AKEYCODE_BUTTON_START:
                    if(pressed)inventoryEdge=true;break;
                case AKEYCODE_F: case AKEYCODE_BUTTON_SELECT:
                    if(pressed)interactEdge=true;break;
                case AKEYCODE_C: if(pressed)consumableEdge=true;break;
                case AKEYCODE_S: if(pressed)sortEdge=true;break;
                case AKEYCODE_F5: if(pressed)saveProgress();break;
                case AKEYCODE_F9: if(pressed)loadProgress();break;
                default:break;
            }
        }
        android_app_clear_key_events(buffer);
    }
    void frame() {
        if (!ready || !resumed) return;
        const auto now=clock_type::now();
        const double elapsed=std::chrono::duration<double>(now-lastFrame).count();
        lastFrame=now;
        const float interpolation=stepper.advance(elapsed,[&](float dt) {
            touch.setInventoryOpen(game.inventoryOpen);
            forge::Input input=touch.sample();
            const float keyboardMove=keyRight?1.0f:(keyLeft?-1.0f:0.0f);
            if(keyLeft || keyRight) input.move=keyboardMove;
            input.jumpPressed|=jumpEdge;
            input.jumpHeld|=keyJump;
            input.rollPressed|=rollEdge;
            input.attackPressed|=attackEdge;
            input.shootPressed|=shootEdge;
            input.swapMeleePressed|=swapMeleeEdge;
            input.swapRangedPressed|=swapRangedEdge;
            input.inventoryPressed|=inventoryEdge;
            input.interactPressed|=interactEdge;
            input.useConsumablePressed|=consumableEdge;
            input.sortInventoryPressed|=sortEdge;
            jumpEdge=rollEdge=attackEdge=shootEdge=swapMeleeEdge=swapRangedEdge=false;
            inventoryEdge=interactEdge=consumableEdge=sortEdge=false;
            game.tick(dt,input);
            touch.setInventoryOpen(game.inventoryOpen);
        });
        autosaveElapsed+=std::clamp(elapsed,0.0,0.25);
        if(game.objects.lastCheckpoint()!=0 && game.objects.lastCheckpoint()!=savedCheckpointId) {
            saveProgress();savedCheckpointId=game.objects.lastCheckpoint();
        }
        if(autosaveElapsed>=30.0) {autosaveElapsed=0;saveProgress();}
        renderer.render(game,interpolation,&touch);
        if(!eglSwapBuffers(display,surface)) {
            __android_log_print(ANDROID_LOG_WARN,"ForgeCell","EGL surface lost");
            initSurface();
        }
    }
    static void command(android_app* app,int32_t cmd) {
        auto& native=*static_cast<NativeApp*>(app->userData);
        switch(cmd) {
            case APP_CMD_INIT_WINDOW: native.initSurface(); break;
            case APP_CMD_TERM_WINDOW: native.destroySurface(); break;
            case APP_CMD_WINDOW_RESIZED: native.onResize(); break;
            case APP_CMD_PAUSE: native.saveProgress();native.resumed=false; native.touch.clear(); native.stepper.reset();break;
            case APP_CMD_STOP: native.saveProgress();break;
            case APP_CMD_RESUME: native.resumed=true;native.lastFrame=clock_type::now();native.stepper.reset();break;
            default:break;
        }
    }
};
}
extern "C" void android_main(struct android_app* app) {
    NativeApp native;
    native.app=app;
    native.loadGeometry();
    app->userData=&native;
    app->onAppCmd=&NativeApp::command;
    android_app_set_motion_event_filter(app,nullptr);
    android_app_set_key_event_filter(app,nullptr);
    while (!app->destroyRequested) {
        int fd=0;
        android_poll_source* source=nullptr;
        const int timeout=(native.ready && native.resumed) ? 0 : -1;
        while (ALooper_pollOnce(timeout,nullptr,&fd,reinterpret_cast<void**>(&source))>=0) {
            if(source) source->process(app,source);
            if(app->destroyRequested) break;
        }
        if(app->destroyRequested) break;
        native.handleInputs();
        native.frame();
    }
    native.saveProgress();
    native.destroySurface();
}
