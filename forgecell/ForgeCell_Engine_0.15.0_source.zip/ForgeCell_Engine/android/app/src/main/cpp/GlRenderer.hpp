#pragma once
#include "forge/Simulation.hpp"
#include "forge/TouchControls.hpp"
#include "forge/VisualFormat.hpp"
#include <android/asset_manager.h>
#include <GLES3/gl3.h>
#include <vector>
#include <string>
namespace forge {
class GlRenderer {
public:
    bool init(AAssetManager* assets);
    void release();
    void resize(int width, int height);
    float viewWidth() const {return viewWidth_;}
    void render(const Simulation& simulation, float interpolation, const TouchControls* touch=nullptr);
private:
    struct Vertex {float x, y, u, v, r, g, b, a;};
    std::vector<Vertex> vertices_;
    GLuint program_ = 0, texture_ = 0, vbo_ = 0, vao_ = 0;
    GLint resolutionUniform_ = -1, atlasUniform_ = -1;
    size_t vertexGpuCapacity_ = 0;
    int pixelWidth_ = 640, pixelHeight_ = 360;
    float viewWidth_ = 640;
    Vec2 camera_ {};
    VisualCatalog visuals_ {};
    void quad(float x, float y, float w, float h, float u0, float v0, float u1, float v1,
              float r, float g, float b, float alpha);
    void rect(float x, float y, float w, float h, float r, float g, float b, float alpha = 1);
    void worldRect(float x, float y, float w, float h, float r, float g, float b, float alpha = 1);
    void sprite(float x, float y, int frame, Animation animation, bool flip,
                float red=1.0f,float green=1.0f,float blue=1.0f,float alpha=1.0f,
                int actorIndex=0);
    void drawParallax(const Simulation& simulation);
    void drawWorld(const Simulation& simulation, float interpolation);
    void drawUi(const Simulation& simulation,const TouchControls* touch);
    void drawStatValue(float x,float y,int value);
    void drawLabel(float x,float y,const std::string& label,float scale=1.f);
    void flush();
};
}
