#include "GlRenderer.hpp"
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstring>
#include <string>

namespace forge {
namespace {
constexpr int ATLAS_W = 1056, ATLAS_H = 1200;
constexpr float U_WHITE = 1040.5f / ATLAS_W, V_WHITE = 1180.5f / ATLAS_H;
const char* kVertexShader = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUv;
layout(location=2) in vec4 aColor;
uniform vec2 uResolution;
out vec2 vUv;
out vec4 vColor;
void main() {
    vec2 p = (aPos / uResolution) * 2.0 - 1.0;
    gl_Position = vec4(p.x, -p.y, 0.0, 1.0);
    vUv = aUv;
    vColor = aColor;
})";
const char* kFragmentShader = R"(#version 300 es
precision mediump float;
in vec2 vUv;
in vec4 vColor;
uniform sampler2D uAtlas;
out vec4 fragColor;
void main() {fragColor = texture(uAtlas, vUv) * vColor;}
)";
GLuint compile(GLenum kind, const char* source) {
    GLuint id = glCreateShader(kind);
    glShaderSource(id, 1, &source, nullptr);
    glCompileShader(id);
    GLint ok = 0;
    glGetShaderiv(id, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char err[1024] = {};
        glGetShaderInfoLog(id, sizeof(err), nullptr, err);
        __android_log_print(ANDROID_LOG_ERROR, "ForgeCell", "GL shader: %s", err);
        glDeleteShader(id);
        return 0;
    }
    return id;
}
}
bool GlRenderer::init(AAssetManager* assets) {
    release();
    GLuint vs = compile(GL_VERTEX_SHADER, kVertexShader);
    GLuint fs = compile(GL_FRAGMENT_SHADER, kFragmentShader);
    if (!vs || !fs) {glDeleteShader(vs); glDeleteShader(fs); return false;}
    program_ = glCreateProgram();
    glAttachShader(program_,vs); glAttachShader(program_,fs);
    glLinkProgram(program_);
    glDeleteShader(vs); glDeleteShader(fs);
    GLint linked = 0; glGetProgramiv(program_,GL_LINK_STATUS,&linked);
    if (!linked) { release(); return false; }
    resolutionUniform_ = glGetUniformLocation(program_,"uResolution");
    atlasUniform_ = glGetUniformLocation(program_,"uAtlas");
    glGenTextures(1,&texture_);
    glBindTexture(GL_TEXTURE_2D,texture_);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    AAsset* asset = AAssetManager_open(assets,"atlas.rgba",AASSET_MODE_BUFFER);
    if (!asset || AAsset_getLength(asset) != 8 + ATLAS_W*ATLAS_H*4) {
        if(asset) AAsset_close(asset);
        release(); return false;
    }
    auto* bytes = static_cast<const unsigned char*>(AAsset_getBuffer(asset));
    if (!bytes || std::memcmp(bytes,"FCAT",4) != 0 ||
        (unsigned(bytes[4]) | (unsigned(bytes[5])<<8))!=ATLAS_W ||
        (unsigned(bytes[6]) | (unsigned(bytes[7])<<8))!=ATLAS_H) {
        AAsset_close(asset);release();return false;
    }
    AAsset* metadata = AAssetManager_open(assets,"demo.fcva",AASSET_MODE_BUFFER);
    if(!metadata){ AAsset_close(asset);release();return false; }
    const auto metadataSize=AAsset_getLength(metadata);
    const auto* metadataBytes=static_cast<const std::byte*>(AAsset_getBuffer(metadata));
    std::string metadataError;
    bool parsed=metadataSize>0 && metadataBytes &&
        decodeVisualBinary(std::span<const std::byte>(metadataBytes,
          static_cast<size_t>(metadataSize)),visuals_,metadataError) &&
        visuals_.atlasWidth==ATLAS_W && visuals_.atlasHeight==ATLAS_H;
    AAsset_close(metadata);
    if(!parsed){
        __android_log_print(ANDROID_LOG_ERROR,"ForgeCell","Visual metadata: %s",metadataError.c_str());
        AAsset_close(asset);release();return false;
    }
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,ATLAS_W,ATLAS_H,0,GL_RGBA,GL_UNSIGNED_BYTE,bytes+8);
    AAsset_close(asset);
    glGenBuffers(1,&vbo_);
    glGenVertexArrays(1,&vao_);
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER,vbo_);
    vertexGpuCapacity_ = 20000;
    glBufferData(GL_ARRAY_BUFFER,vertexGpuCapacity_ * sizeof(Vertex),nullptr,GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)(2*sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2,4,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)(4*sizeof(float)));
    glBindVertexArray(0);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    vertices_.reserve(20000);
    return glGetError() == GL_NO_ERROR;
}
void GlRenderer::release() {
    if(vbo_) glDeleteBuffers(1,&vbo_);
    if(vao_) glDeleteVertexArrays(1,&vao_);
    if(texture_) glDeleteTextures(1,&texture_);
    if(program_) glDeleteProgram(program_);
    vbo_=vao_=texture_=program_=0;
    vertexGpuCapacity_=0;resolutionUniform_=atlasUniform_=-1;
    vertices_.clear();
}
void GlRenderer::resize(int width, int height) {
    pixelWidth_ = std::max(1,width);
    pixelHeight_ = std::max(1,height);
    viewWidth_ = std::max(360.0f,360.0f*pixelWidth_/pixelHeight_);
    glViewport(0,0,pixelWidth_,pixelHeight_);
}
void GlRenderer::quad(float x,float y,float w,float h,float u0,float v0,float u1,float v1,
                      float r,float g,float b,float alpha) {
    Vertex tl{x,y,u0,v0,r,g,b,alpha}, tr{x+w,y,u1,v0,r,g,b,alpha};
    Vertex bl{x,y+h,u0,v1,r,g,b,alpha}, br{x+w,y+h,u1,v1,r,g,b,alpha};
    vertices_.insert(vertices_.end(),{tl,bl,tr,tr,bl,br});
}
void GlRenderer::rect(float x,float y,float w,float h,float r,float g,float b,float alpha) {
    quad(x,y,w,h,U_WHITE,V_WHITE,U_WHITE,V_WHITE,r,g,b,alpha);
}
void GlRenderer::worldRect(float x,float y,float w,float h,float r,float g,float b,float alpha) {
    rect(x-camera_.x+viewWidth_*0.5f,y-camera_.y+180.0f,w,h,r,g,b,alpha);
}
void GlRenderer::sprite(float x,float y,int frame,Animation animation,bool flip,
                         float red,float green,float blue,float alpha,int actorIndex) {
    const auto* style=visuals_.get(static_cast<unsigned>(std::max(actorIndex,0)));
    if(!style)style=visuals_.get(0);
    if(!style)return;
    const int n=std::clamp(frame,0,int(style->frames)-1);
    const int row=std::clamp(int(animation),0,int(style->animations)-1);
    const float u0=(style->x+float(n)*style->frameWidth)/ATLAS_W;
    const float u1=(style->x+float(n+1)*style->frameWidth)/ATLAS_W;
    const float v0=(style->y+float(row)*style->frameHeight)/ATLAS_H;
    const float v1=(style->y+float(row+1)*style->frameHeight)/ATLAS_H;
    quad(std::floor(x-camera_.x+viewWidth_*0.5f-style->footX),
         std::floor(y-camera_.y+180-style->footY),
         style->frameWidth,style->frameHeight,
         flip?u1:u0,v0,flip?u0:u1,v1,red,green,blue,alpha);
}
void GlRenderer::drawParallax(const Simulation& s) {
    const float camX=camera_.x;
    rect(0,0,viewWidth_,360,.040f,.059f,.089f);
    // Background architecture moves at 5%, 20% and 45% camera speed.
    for(int layer=0;layer<3;++layer) {
        const float factor = layer==0?0.05f:layer==1?0.20f:0.45f;
        const float baseY = layer==0?165:layer==1?235:270;
        const float tint = layer==0?0.13f:layer==1?0.22f:0.30f;
        const float start = std::floor((camX*factor-100)/110.0f)*110.0f;
        for(float worldX=start;worldX<camX*factor+viewWidth_+130;worldX+=110) {
            const float x=worldX-camX*factor;
            const int col=static_cast<int>(std::abs(worldX)/110.0f);
            const float h=55+static_cast<float>((col*41+layer*19)%80);
            rect(x,baseY-h,75,h,tint*.58f,tint*.80f,tint);
            rect(x+13,baseY-h-17,20,17,tint*.55f,tint*.75f,tint);
            for(int i=0;i<3;++i) rect(x+12+i*20,baseY-h+20,4,6,.20f,.42f,.40f,.35f);
        }
    }
    rect(0,274,viewWidth_,86,.040f,.055f,.068f,.5f);
}
void GlRenderer::drawWorld(const Simulation& s,float interpolation) {
    for(const auto& solid:s.world.solids) {
        if(solid.x+solid.w<camera_.x-viewWidth_*.5f-40 ||
           solid.x>camera_.x+viewWidth_*.5f+40)continue;
        worldRect(solid.x,solid.y,solid.w,solid.h,.13f,.18f,.22f);
        worldRect(solid.x,solid.y,solid.w,3,.37f,.60f,.59f);
        for(int i=0;i<static_cast<int>(solid.w/38);++i) {
            worldRect(solid.x+i*38+10,solid.y+7,2,std::min(15.0f,solid.h-7),.22f,.31f,.36f,.65f);
        }
    }
    for(const auto& p:s.world.oneWay) {
        if(p.x+p.w<camera_.x-viewWidth_*.5f-40 || p.x>camera_.x+viewWidth_*.5f+40)continue;
        worldRect(p.x,p.y,p.w,p.h,.17f,.27f,.28f);
        worldRect(p.x,p.y,p.w,3,.42f,.74f,.70f);
    }
    const float x = s.player.prevPos.x +(s.player.pos.x-s.player.prevPos.x)*interpolation;
    const float y = s.player.prevPos.y +(s.player.pos.y-s.player.prevPos.y)*interpolation;
    worldRect(x-14,y-2,28,3,0,0,0,.48f);
    for(const auto& enemy : s.combat.enemies) {
        if(!enemy.alive || std::abs(enemy.x-camera_.x)>viewWidth_*.5f+36)continue;
        const float ex=enemy.previousX+(enemy.x-enemy.previousX)*interpolation;
        const float ey=enemy.previousY+(enemy.y-enemy.previousY)*interpolation;
        const float health=static_cast<float>(enemy.health)/enemy.maxHealth;
        worldRect(ex-11,ey-42,22,3,.12f,.12f,.14f);
        worldRect(ex-11,ey-42,22*health,3,
                  enemy.role==EnemyRole::Boss && enemy.bossPhase==2?1.f:.87f,.28f,.20f);
        sprite(ex,ey,enemy.animator.frame,enemy.animator.animation,!enemy.facingRight,1.0f,
               enemy.hitFlash>0?0.85f:1.0f,
               enemy.hitFlash>0?0.85f:1.0f,1.0f,enemy.visualIndex==255?static_cast<int>(enemy.role)+1:enemy.visualIndex);
        if(enemy.state==EnemyState::Windup) {
            const float range=enemy.role==EnemyRole::Gunner?90.0f:enemy.role==EnemyRole::Boss?52.f:enemy.role==EnemyRole::Heavy?42.0f:31.0f;
            worldRect(enemy.facingRight?ex:ex-range,ey-28,range,2,1.0f,.38f,.17f,.95f);
        }
    }
    for(const auto& entry : s.objects.entries()) {
        const auto& object=entry.value;
        if(std::abs(object.x-camera_.x)>viewWidth_*.5f+object.radius)continue;
        if(object.kind==WorldObjectKind::Crate) {
            if(object.health<=0)continue;
            const float side=object.radius;
            worldRect(object.x-side*.5f,object.y-side,side,side,.32f,.23f,.15f);
            worldRect(object.x-side*.5f+3,object.y-side+3,side-6,side-6,.55f,.39f,.21f);
            worldRect(object.x-side*.5f,object.y-side,side,3,.76f,.59f,.35f);
        } else {
            worldRect(object.x-5,object.y-28,10,28,object.activated?.3f:.20f,
                      object.activated?.90f:.46f,object.activated?.72f:.42f);
            worldRect(object.x-9,object.y-31,18,5,object.activated?.6f:.28f,
                      object.activated?.92f:.64f,.62f);
        }
    }
    for(const auto& entry : s.combat.transients.projectiles()) {
        const auto& bullet=entry.value;
        const float bx=bullet.prevX+(bullet.x-bullet.prevX)*interpolation;
        const float by=bullet.prevY+(bullet.y-bullet.prevY)*interpolation;
        worldRect(bx-5,by-2,9,4,bullet.hostile?1.0f:1.0f,
                  bullet.hostile?.24f:.79f,bullet.hostile?.22f:.32f);
    }
    for(const auto& entry:s.combat.transients.pickups()) {
        const auto& pickup=entry.value;
        if(pickup.collected)continue;
        worldRect(pickup.x-6,pickup.y-6,12,12,.86f,.72f,.31f,.94f);
        worldRect(pickup.x-3,pickup.y-3,6,6,.21f,.16f,.07f,.95f);
    }
    // ECS transient effects share the existing sprite batch (no extra GL draw calls).
    for(const auto& slot:s.effects.entries()) {
        const auto& effect=slot.value;
        if(std::abs(effect.x-camera_.x)>viewWidth_*.5f+16)continue;
        const float remaining=std::clamp(1.0f-effect.age/effect.duration,0.0f,1.0f);
        if(effect.kind==EffectKind::Death)
            worldRect(effect.x-8* (1-remaining),effect.y-4,16*(1-remaining),8,
                      .97f,.30f,.17f,remaining);
        else if(effect.kind==EffectKind::PlayerHit)
            worldRect(effect.x-6,effect.y-4,12,8,.93f,.26f,.27f,remaining);
        else if(effect.kind==EffectKind::Shot)
            worldRect(effect.x-2,effect.y-2,6,4,1.0f,.88f,.43f,remaining);
        else worldRect(effect.x-4,effect.y-3,8,6,.98f,.69f,.36f,remaining);
    }
    sprite(x,y,s.player.animator.frame,s.player.animator.animation,!s.player.facingRight);
    if(s.combat.meleeActive()) {
        worldRect(s.player.facingRight?x:x-s.combat.melee.reach,y-31,
                  s.combat.melee.reach,2,.80f,.94f,.73f,.85f);
    }
}
// Tiny 7-segment numeric overlay, built from existing batched quads.
// No font texture or GPU state changes are required.
void GlRenderer::drawLabel(float x,float y,const std::string& label,float scale) {
    // 5x7 ASCII glyphs (columns stored top-to-bottom, bit 0 = top).
    struct Glyph {char c; unsigned char col[5];};
    static constexpr Glyph glyphs[]={
        {'A',{0x7e,0x11,0x11,0x11,0x7e}}, {'B',{0x7f,0x49,0x49,0x49,0x36}},
        {'C',{0x3e,0x41,0x41,0x41,0x22}}, {'D',{0x7f,0x41,0x41,0x22,0x1c}},
        {'E',{0x7f,0x49,0x49,0x49,0x41}}, {'F',{0x7f,0x09,0x09,0x09,0x01}},
        {'G',{0x3e,0x41,0x49,0x49,0x7a}}, {'H',{0x7f,0x08,0x08,0x08,0x7f}},
        {'I',{0x00,0x41,0x7f,0x41,0x00}}, {'J',{0x20,0x40,0x41,0x3f,0x01}},
        {'K',{0x7f,0x08,0x14,0x22,0x41}}, {'L',{0x7f,0x40,0x40,0x40,0x40}},
        {'M',{0x7f,0x02,0x0c,0x02,0x7f}}, {'N',{0x7f,0x04,0x08,0x10,0x7f}},
        {'O',{0x3e,0x41,0x41,0x41,0x3e}}, {'P',{0x7f,0x09,0x09,0x09,0x06}},
        {'Q',{0x3e,0x41,0x51,0x21,0x5e}}, {'R',{0x7f,0x09,0x19,0x29,0x46}},
        {'S',{0x46,0x49,0x49,0x49,0x31}}, {'T',{0x01,0x01,0x7f,0x01,0x01}},
        {'U',{0x3f,0x40,0x40,0x40,0x3f}}, {'V',{0x1f,0x20,0x40,0x20,0x1f}},
        {'W',{0x7f,0x20,0x18,0x20,0x7f}}, {'X',{0x63,0x14,0x08,0x14,0x63}},
        {'Y',{0x07,0x08,0x70,0x08,0x07}}, {'Z',{0x61,0x51,0x49,0x45,0x43}},
        {'0',{0x3e,0x51,0x49,0x45,0x3e}}, {'1',{0,0x42,0x7f,0x40,0}},
        {'2',{0x42,0x61,0x51,0x49,0x46}}, {'3',{0x21,0x41,0x45,0x4b,0x31}},
        {'4',{0x18,0x14,0x12,0x7f,0x10}}, {'5',{0x27,0x45,0x45,0x45,0x39}},
        {'6',{0x3c,0x4a,0x49,0x49,0x30}}, {'7',{0x01,0x71,0x09,0x05,0x03}},
        {'8',{0x36,0x49,0x49,0x49,0x36}}, {'9',{0x06,0x49,0x49,0x29,0x1e}},
        {' ',{0,0,0,0,0}}, {'-',{0x08,0x08,0x08,0x08,0x08}},
        {'/',{0x40,0x30,0x08,0x06,0x01}}, {'.',{0,0,0x40,0,0}},
        {':',{0,0x36,0x36,0,0}}, {'+', {0x08,0x08,0x3e,0x08,0x08}}
    };
    for(char raw:label) {
        const char c=raw>='a'&&raw<='z'?static_cast<char>(raw-'a'+'A'):raw;
        const Glyph* glyph=nullptr;
        for(const auto& g:glyphs)if(g.c==c){glyph=&g;break;}
        if(glyph)for(int column=0;column<5;++column)
            for(int row=0;row<7;++row)
                if((glyph->col[column]>>row)&1)
                    rect(x+column*scale,y+row*scale,scale,scale,.84f,.90f,.87f,.98f);
        x+=6.f*scale;
    }
}
void GlRenderer::drawStatValue(float x,float y,int value) {
    constexpr unsigned char segments[10]={0x3f,0x06,0x5b,0x4f,0x66,
                                          0x6d,0x7d,0x07,0x7f,0x6f};
    const int clamped=std::clamp(value,-999,999);
    const std::string number=(clamped>0?"+":"")+std::to_string(clamped);
    const float r=clamped>0?.25f:clamped<0?.95f:.65f;
    const float g=clamped>0?.92f:clamped<0?.36f:.70f;
    const float b=clamped>0?.75f:clamped<0?.35f:.71f;
    float dx=x+(39.0f-number.size()*6.0f)*.5f;
    for(char digit:number) {
        if(digit=='+' || digit=='-') {
            rect(dx+1,y+3,3,1,r,g,b);
            if(digit=='+')rect(dx+2,y+1,1,5,r,g,b);
        } else {
            const unsigned char m=segments[digit-'0'];
            if(m&1)rect(dx+1,y,3,1,r,g,b);
            if(m&2)rect(dx+4,y+1,1,2,r,g,b);
            if(m&4)rect(dx+4,y+4,1,2,r,g,b);
            if(m&8)rect(dx+1,y+6,3,1,r,g,b);
            if(m&16)rect(dx,y+4,1,2,r,g,b);
            if(m&32)rect(dx,y+1,1,2,r,g,b);
            if(m&64)rect(dx+1,y+3,3,1,r,g,b);
        }
        dx+=6;
    }
}
void GlRenderer::drawUi(const Simulation& simulation,const TouchControls* touch) {
    const Vec2 inventory=TouchControls::buttonCenter(Control::Inventory,viewWidth_,360);
    rect(inventory.x-24,inventory.y-16,48,32,.24f,.43f,.49f,.76f);
    for(int i=0;i<3;++i)rect(inventory.x-15,inventory.y-8+i*7,30,3,.84f,.86f,.80f,.8f);
    if(simulation.inventoryOpen) {
        rect(0,0,viewWidth_,360,.03f,.05f,.08f,.88f);
        rect(viewWidth_*.5f-129,64,258,177,.13f,.18f,.22f,.98f);
        rect(viewWidth_*.5f-125,69,250,5,.41f,.63f,.61f,.88f);
        rect(inventory.x-23,inventory.y-16,46,32,.31f,.49f,.53f,.96f);
        rect(inventory.x-10,inventory.y-2,20,4,.90f,.91f,.84f,1.f);
        drawLabel(viewWidth_*.5f-113.f,53.f,"BACKPACK / EQUIPMENT");
        for(size_t index=0;index<simulation.combat.equipment.backpack.size();++index) {
            const float px=viewWidth_*.5f-114.f+(index%6)*38.f;
            const float py=79.f+(index/6)*38.f;
            const bool selected=simulation.inventorySelectionArmed && index==simulation.inventorySelected;
            rect(px,py,34,34,selected?.56f:.22f,selected?.54f:.30f,selected?.23f:.35f,.99f);
            const auto* w=simulation.combat.equipment.find(simulation.combat.equipment.backpack[index]);
            const auto& inventoryId=simulation.combat.equipment.backpack[index];
            const auto* item=simulation.combat.equipment.findItem(inventoryId);
            const auto* instance=simulation.combat.equipment.instance(inventoryId);
            if(item) {
                // Item rarity accent, defined in FCIT v2 (v1 defaults to common).
                constexpr float colors[5][3]={{.52f,.53f,.55f},{.30f,.69f,.48f},
                    {.32f,.54f,.91f},{.72f,.41f,.84f},{.97f,.72f,.25f}};
                rect(px+2,py+2,30,2,colors[item->rarity][0],colors[item->rarity][1],colors[item->rarity][2]);
                rect(px+7,py+7,20,20,item->kind==ItemKind::Armor?.29f:item->kind==ItemKind::Passive?.62f:.25f,
                     item->kind==ItemKind::Armor?.42f:item->kind==ItemKind::Passive?.35f:.72f,.42f,1.f);
            }
            if(instance) { // Small gold corner distinguishes independently rolled copies.
                rect(px+27,py+26,5,5,.98f,.80f,.32f,1.f);
            }
            if(w) {
                const bool melee=w->kind==WeaponKind::Melee;
                rect(px+7,py+7,20,20,melee?.70f:.35f,melee?.73f:.64f,melee?.69f:.91f,1.f);
                rect(px+14,py+11,6,12,.08f,.13f,.17f,1.f);
            }
        }
        // Six equipment slots: melee, ranged, armor, two passives, consumable.
        for(size_t i=0;i<6;++i) {
            const float x=viewWidth_*.5f+135.0f, y=79.0f+27.0f*i;
            rect(x,y,25,25,.15f,.24f,.29f,.98f);
            const auto& id=i<2?simulation.combat.equipment.equipped[i]:
                simulation.combat.equipment.accessories[i-2];
            if(!id.empty())rect(x+4,y+4,17,17,i==0?.63f:i==1?.27f:i==2?.43f:i==5?.29f:.68f,
                                i==0?.71f:i==1?.69f:i==2?.66f:i==5?.81f:.56f,.45f,1.f);
            else drawLabel(x+9,y+9,i==0?"M":i==1?"R":i==2?"A":i==5?"C":"P",1.f);
        }
        // Visual-only drag feedback: collision and equip remain determined by
        // pointer release in TouchControls, never by a rendered element.
        if(touch)if(const auto drag=touch->inventoryDrag()) {
            if(drag->toCell>=0 && drag->toCell<24) {
                const float x=viewWidth_*.5f-114.f+(drag->toCell%6)*38.f;
                const float y=79.f+(drag->toCell/6)*38.f;
                rect(x+1,y+1,32,2,.30f,.95f,.75f,.95f);
                rect(x+1,y+31,32,2,.30f,.95f,.75f,.95f);
            } else if(drag->toSlot>=0 && drag->toSlot<6) {
                const float x=viewWidth_*.5f+135.f,y=79.f+27.f*drag->toSlot;
                rect(x,y,25,3,.30f,.95f,.75f,.95f);
                rect(x,y+22,25,3,.30f,.95f,.75f,.95f);
            }
            const float x=std::clamp(drag->position.x,16.f,viewWidth_-16.f);
            const float y=std::clamp(drag->position.y,16.f,344.f);
            rect(x-13,y-13,26,26,.74f,.85f,.54f,.65f);
            rect(x-7,y-7,14,14,.25f,.32f,.26f,.86f);
        }
        // Selected item vs relevant equipment: five centered, signed delta bars.
        // Cyan=improvement, red=regression, muted gray=no change; order:
        // health, damage, defense, movement speed, healing. UI stays read-only.
        const auto& eq=simulation.combat.equipment;
        const auto& selectedId=eq.backpack[simulation.inventorySelected];
        if(simulation.inventorySelectionArmed && !selectedId.empty()) {
            const auto* weapon=eq.find(selectedId);
            const auto* item=eq.findItem(selectedId);
            const std::string name=weapon?weapon->name:item?item->name:"UNKNOWN";
            drawLabel(viewWidth_*.5f-113.f,239.f,name.substr(0,26),.85f);
            drawLabel(viewWidth_*.5f-113.f,289.f,"TAP AGAIN TO EQUIP",.8f);
        }
        size_t targetSlot=6;
        if(const auto* w=eq.find(selectedId))targetSlot=w->kind==WeaponKind::Melee?0:1;
        else if(const auto* i=eq.findItem(selectedId))
            targetSlot=i->kind==ItemKind::Armor?2:i->kind==ItemKind::Consumable?5:
                eq.accessories[1].empty()?3:4;
        if(simulation.inventorySelectionArmed && targetSlot<6) {
            const auto diff=eq.compareBackpackToSlot(simulation.inventorySelected,targetSlot);
            if(diff.compatible) {
                const int changes[5]={diff.healthDelta,diff.damageDelta,diff.defenseDelta,
                    diff.speedDeltaPct,diff.healingDelta};
                static constexpr const char* names[]={"HP","ATK","DEF","SPD","HEAL"};
                for(int i=0;i<5;++i)
                    drawLabel(viewWidth_*.5f-113+i*45.f,277.f,names[i],.8f);
                for(int i=0;i<5;++i) {
                    const float x=viewWidth_*.5f-113+i*45.f, y=251.f;
                    rect(x,y,39,15,.12f,.19f,.24f,.94f);
                    rect(x+19,y+2,1,11,.71f,.73f,.71f,.65f);
                    const int value=changes[i];
                    const float fill=std::min(17.0f,float(std::abs(value))*.7f);
                    if(value>0)rect(x+20,y+5,fill,5,.20f,.85f,.68f);
                    else if(value<0)rect(x+19-fill,y+5,fill,5,.90f,.32f,.29f);
                    else rect(x+18,y+6,3,3,.53f,.59f,.61f);
                    drawStatValue(x,y+19,value);
                }
            }
        }
        // Equip class determined by item: tap occupied cell to equip/swap.
        // Drop selected item via the adjacent red action control.
        const Vec2 drop=TouchControls::buttonCenter(Control::Drop,viewWidth_,360);
        rect(drop.x-19,drop.y-18,38,36,.59f,.19f,.19f,.93f);
        rect(drop.x-9,drop.y-2,18,5,.92f,.75f,.73f,.93f);
        const Vec2 sort=TouchControls::buttonCenter(Control::Sort,viewWidth_,360);
        rect(sort.x-22,sort.y-18,44,36,.22f,.43f,.56f,.94f);
        drawLabel(sort.x-17,sort.y-3,"SORT",.84f);
        return;
    }
    const Vec2 stick=TouchControls::buttonCenter(Control::Move,viewWidth_,360);
    rect(stick.x-48,stick.y-48,96,96,.36f,.53f,.55f,.15f);
    rect(stick.x-12,stick.y-12,24,24,.5f,.82f,.81f,.28f);
    for(Control c : {Control::Jump,Control::Roll,Control::Attack,Control::Shoot,Control::SwapMelee,Control::SwapRanged,Control::Interact,Control::UseConsumable}) {
        const Vec2 p=TouchControls::buttonCenter(c,viewWidth_,360);
        const float cr=c==Control::Interact?.45f:c==Control::Jump?.2f:c==Control::Roll?.28f:c==Control::Shoot?.40f:.48f;
        const float size=(c==Control::SwapMelee || c==Control::SwapRanged)?19.0f:26.0f;
        rect(p.x-size,p.y-size,2*size,2*size,cr,.46f,.52f,.3f);
        rect(p.x-12,p.y-12,24,24,.7f,.86f,.82f,.20f);
        const char* caption=c==Control::Jump?"JUMP":c==Control::Roll?"ROLL":
            c==Control::Attack?"HIT":c==Control::Shoot?"FIRE":
            c==Control::SwapMelee?"M":c==Control::SwapRanged?"R":
            c==Control::Interact?"USE":"MED";
        const float labelScale=(c==Control::SwapMelee||c==Control::SwapRanged)?1.5f:.87f;
        const float width=std::char_traits<char>::length(caption)*6.f*labelScale;
        drawLabel(p.x-width*.5f,p.y-3.5f*labelScale,caption,labelScale);
    }
    // Nearby pickup hints, rendered only when available to collect.
    for(const auto& entry:simulation.combat.transients.pickups())
        if(!entry.value.collected && std::abs(simulation.player.pos.x-entry.value.x)<38.f) {
            const Vec2 button=TouchControls::buttonCenter(Control::Interact,viewWidth_,360);
            rect(button.x-19,button.y-19,38,38,.74f,.64f,.18f,.5f);
            break;
        }
    // Equipped accessory slots in the inventory overlay, using color-coded placeholders.
    rect(18,17,147,8,.28f,.26f,.27f,.95f);
    rect(20,19,116.0f*simulation.player.health/simulation.player.maxHealth,4,
         .80f,.18f,.22f,.96f);
    // Ammo in magazine; red tick indicates reload in progress.
    if(simulation.combat.reloading())rect(20,30,70,3,.94f,.18f,.23f,.95f);
    // Simple ammo pips in the prototype HUD.
    for(int i=0;i<std::min(20,simulation.combat.magazineRemaining());++i)
        rect(20+i*5,32,3,5,.94f,.77f,.36f,.95f);
}
void GlRenderer::flush() {
    glUseProgram(program_);
    glUniform2f(resolutionUniform_,viewWidth_,360.0f);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D,texture_);
    glUniform1i(atlasUniform_,0);
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER,vbo_);
    // Avoid allocating a fresh GL buffer store each render tick; grow only
    // when a scene exceeds the initial batch capacity.
    if(vertices_.size()>vertexGpuCapacity_) {
        vertexGpuCapacity_=std::max(vertices_.size(),vertexGpuCapacity_*2);
        glBufferData(GL_ARRAY_BUFFER,vertexGpuCapacity_*sizeof(Vertex),nullptr,GL_STREAM_DRAW);
    }
    if(!vertices_.empty()) {
        glBufferSubData(GL_ARRAY_BUFFER,0,vertices_.size()*sizeof(Vertex),vertices_.data());
        glDrawArrays(GL_TRIANGLES,0,static_cast<GLsizei>(vertices_.size()));
    }
    glBindVertexArray(0);
}
void GlRenderer::render(const Simulation& simulation,float interpolation,const TouchControls* touch) {
    vertices_.clear();
    glClearColor(.04f,.06f,.09f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    camera_=simulation.camera.interpolated(interpolation);
    drawParallax(simulation);
    drawWorld(simulation,interpolation);
    drawUi(simulation,touch);
    flush();
}
}
