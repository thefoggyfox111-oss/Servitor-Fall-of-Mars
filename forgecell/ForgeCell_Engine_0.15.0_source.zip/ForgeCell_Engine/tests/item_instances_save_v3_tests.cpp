#include "forge/Simulation.hpp"
#include "forge/SaveSystem.hpp"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

using namespace forge;
static void expect(bool yes,const char* description) {
    if(!yes){std::cerr<<"FAIL: "<<description<<'\n';std::exit(1);}
}
static std::vector<std::byte> fixture(const char* filename) {
    std::ifstream in(std::filesystem::path(FORGECELL_SOURCE_ROOT)/
        "android/app/src/main/assets"/filename,std::ios::binary);
    expect(in.good(),"item fixture available");
    std::vector<char> raw((std::istreambuf_iterator<char>(in)),{});
    std::vector<std::byte> bytes;
    for(unsigned char c:raw)bytes.push_back(static_cast<std::byte>(c));
    return bytes;
}
static uint32_t crc32(const std::vector<std::byte>& b) {
    uint32_t c=0xffffffffu;
    for(size_t i=16;i<b.size();++i) {
        c^=std::to_integer<uint8_t>(b[i]);
        for(int j=0;j<8;++j)c=(c>>1)^(0xedb88320u&static_cast<uint32_t>(-static_cast<int>(c&1)));
    }
    return ~c;
}
static void patch32(std::vector<std::byte>& b,size_t at,uint32_t value) {
    for(size_t i=0;i<4;++i)b[at+i]=std::byte((value>>(8*i))&0xff);
}
static void checksum(std::vector<std::byte>& b) {
    patch32(b,8,static_cast<uint32_t>(b.size()-16));patch32(b,12,crc32(b));
}
static size_t locate(const Equipment& e,const std::string& token) {
    for(size_t i=0;i<e.backpack.size();++i)if(e.backpack[i]==token)return i;
    return e.backpack.size();
}
int main() {
    Simulation simulation;
    std::string error;
    expect(simulation.combat.loadItems(fixture("demo.fcit"),error),"load item catalog");
    auto& e=simulation.combat.equipment;
    uint32_t a=0,b=0,sword=0;
    expect(e.addInstanceToBackpack("vitality_chip",{12,2,0,6,0},&a),"first independent passive");
    expect(e.addInstanceToBackpack("vitality_chip",{25,1,3,11,0},&b),"second independent passive");
    expect(e.addInstanceToBackpack("rusted_sword",{0,14,0,0,0},&sword),"independent weapon");
    expect(a!=b && a!=sword && e.instances().size()==3,"unique stable IDs");
    const std::string one="~"+std::to_string(a),two="~"+std::to_string(b);
    expect(e.findItem(one) && e.findItem(two) && e.findItem(one)==e.findItem(two),
           "two instances share immutable definition");
    expect(!e.addInstanceToBackpack("vitality_chip",{0,0,0,101,0}),"reject invalid roll");
    expect(!e.addInstanceToBackpack("no_such_item",{}),"reject missing definition");
    const auto slotA=locate(e,one),slotB=locate(e,two);
    expect(slotA<24 && slotB<24,"both physical items in backpack");
    const auto aComparison=e.compareBackpackToSlot(slotA,3);
    const auto bComparison=e.compareBackpackToSlot(slotB,3);
    expect(aComparison.healthDelta==27 && bComparison.healthDelta==40 &&
           bComparison.speedDeltaPct==19,"instance-specific comparison includes base stats");
    expect(e.equipAccessoryFromBackpack(slotA,1),"equip first instance");
    expect(e.bonusHealth()==27 && e.speedBonusPercent()==14,"affixes affect player stats");
    const auto swapComparison=e.compareBackpackToSlot(slotB,3);
    expect(swapComparison.healthDelta==13 && swapComparison.speedDeltaPct==5,
           "comparison subtracts currently equipped instance");
    expect(e.equipAccessoryFromBackpack(slotB,1),"equip second instance");
    expect(e.accessories[1]==two && e.backpack[slotB]==one,"swap retains physical identities");
    expect(e.bonusHealth()==40 && e.speedBonusPercent()==19,"new bonuses apply");
    auto weaponSlot=locate(e,"~"+std::to_string(sword));
    expect(e.equipFromBackpack(weaponSlot,0),"equip rolled sword");
    expect(e.weaponDamage(0)==44,"rolled sword damage calculation");
    // Invoking the combat wrapper also updates the active melee configuration.
    expect(simulation.combat.equipFromBackpack(weaponSlot,0),"equip normal sword again");
    weaponSlot=locate(e,"~"+std::to_string(sword));
    expect(simulation.combat.equipFromBackpack(weaponSlot,0),"equip rolled sword through combat");
    expect(simulation.combat.melee.damage==44,"melee stat changes in combat engine");
    simulation.player.maxHealth=100+e.bonusHealth();
    simulation.player.health=119;
    // Persist a dropped instance in the world, not only equipped slots.
    const auto tokenOne=locate(e,one);
    expect(simulation.combat.dropFromBackpack(tokenOne,simulation.player),"drop rolled item");
    expect(!e.backpack[tokenOne].size(),"dropped item removed from bag");
    const auto saved=SaveCodec::encode(simulation);
    expect(saved.size()>100 && saved[4]==std::byte{3},"FCSV v3 written");
    Simulation loaded;
    expect(loaded.combat.loadItems(fixture("demo.fcit"),error),"restore catalog");
    if(!SaveCodec::decode(saved,loaded,error)) {std::cerr<<"decode: "<<error<<"\n";expect(false,"v3 roundtrip succeeds");}
    expect(loaded.player.health==119 && loaded.player.maxHealth==140,
           "instance health bonus and saved HP restored");
    expect(loaded.combat.equipment.accessories[1]==two &&
           loaded.combat.equipment.weaponDamage(0)==44,"equipped instance data restored");
    expect(loaded.combat.equipment.instances().size()==3,"instance identities persisted");
    bool foundDrop=false;
    for(const auto& entry:loaded.combat.transients.pickups())
        if(entry.value.weaponId==one)foundDrop=true;
    expect(foundDrop,"dropped rolled copy survives save");
    expect(loaded.combat.collectNearby(loaded.player),"reclaim dropped rolled item");
    expect(locate(loaded.combat.equipment,one)<24,"recovered copy preserves UID");
    expect(loaded.combat.equipment.instance(one) &&
           loaded.combat.equipment.bonuses(one).health==12,"recovered affixes preserved");
    // Malformed payload: valid checksum alone must not bypass identity validation.
    auto corrupted=saved;
    corrupted.back()=std::byte{255};checksum(corrupted);
    Simulation unchanged;
    expect(unchanged.combat.loadItems(fixture("demo.fcit"),error),"bad save setup");
    const auto oldPosition=unchanged.player.pos;
    expect(!SaveCodec::decode(corrupted,unchanged,error),"out-of-range affix rejected");
    expect(unchanged.player.pos.x==oldPosition.x && unchanged.combat.equipment.instances().empty(),
           "failed load is atomic");
    // Restore a legacy FCSV v2 checkpoint without instance data.
    Simulation legacy;
    expect(legacy.combat.loadItems(fixture("demo.fcit"),error),"legacy catalog");
    auto legacyV3=SaveCodec::encode(legacy);
    expect(legacyV3[legacyV3.size()-1]==std::byte{0} &&
           legacyV3[legacyV3.size()-2]==std::byte{0},"legacy fixture has zero instance records");
    legacyV3.resize(legacyV3.size()-2);
    legacyV3[4]=std::byte{2};checksum(legacyV3);
    Simulation legacyTarget;
    expect(legacyTarget.combat.loadItems(fixture("demo.fcit"),error),"initialize legacy target");
    expect(SaveCodec::decode(legacyV3,legacyTarget,error),"read historical FCSV v2");
    expect(legacyTarget.combat.equipment.instances().empty(),"old save contains no affixes");
    // Removing an instance from the catalog invalidates affected slot references.
    Equipment invalid;
    expect(invalid.restoreInstances({{1,"rusted_sword",{0,10,0,0,0}}}),
           "legal instance catalog accepted");
    expect(!invalid.restoreInstances({{1,"rusted_sword",{}},{1,"pistol",{}}}),
           "duplicate IDs rejected atomically");
    expect(invalid.instances().size()==1,"failed restore kept previous state");
    expect(!invalid.restoreInstances({{1,"unknown",{}}}),"unknown base item rejected");
    // The expensive platform graph should not be recomputed on every tick.
    Simulation navigation;
    navigation.combat.enemies.clear();
    Combatant hunter;
    hunter.id=731;hunter.role=EnemyRole::Grunt;
    hunter.x=hunter.previousX=hunter.spawnX=260;
    hunter.y=hunter.previousY=294;
    hunter.detectionRange=350;
    navigation.combat.enemies.push_back(hunter);
    navigation.player.pos={120,294};navigation.player.grounded=true;
    for(int tick=0;tick<90;++tick)navigation.tick(kFixedDt,{});
    expect(navigation.combat.navigationQueries>=3 && navigation.combat.navigationQueries<40,
           "AI batches navigation replanning instead of planning at 60Hz");
    auto& npc=navigation.combat.enemies.front();
    npc.aggroMemory=2; npc.navPlanTimer=.18f;
    navigation.player.pos.x+=55;
    const auto before=navigation.combat.navigationQueries;
    navigation.tick(kFixedDt,{});
    expect(navigation.combat.navigationQueries>before,
           "significant player movement invalidates cached navigation");
    std::cout<<"ForgeCell Item Instances/FCSV v3: ALL ASSERTIONS PASSED\n";
}
