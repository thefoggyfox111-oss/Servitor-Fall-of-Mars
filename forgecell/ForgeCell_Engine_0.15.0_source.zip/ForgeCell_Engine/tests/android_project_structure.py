"""Host-side manifest/config/assets smoke test; not a substitute for an APK build."""
from pathlib import Path
import re
import struct
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent.parent
manifest = ET.parse(root / 'android/app/src/main/AndroidManifest.xml').getroot()
ns = '{http://schemas.android.com/apk/res/android}'
activity = manifest.find('./application/activity')
assert activity is not None
assert activity.get(ns + 'screenOrientation') == 'landscape'
assert activity.get(ns + 'exported') == 'true'
assert activity.find('meta-data').get(ns + 'value') == 'forgecell'
styles = (root / 'android/app/src/main/res/values/styles.xml').read_text()
assert '@android:style/Theme.Material.NoActionBar' in styles
assert 'AppCompat' not in styles
app = (root / 'android/app/build.gradle.kts').read_text()
for line in ('compileSdk = 35', 'minSdk = 26', 'versionName = "0.15.0"',
             'games-activity:4.4.2', 'prefab = true', 'arm64-v8a'):
    assert line in app, line
assets = root / 'android/app/src/main/assets'
for suffix, magic in {'fcan': b'FCAN', 'fcva': b'FCVA', 'fcwp': b'FCWP',
                      'fcey': b'FCEY', 'fcit': b'FCIT', 'fcob': b'FCOB',
                      'fclt': b'FCLT', 'fcl': b'FCLV'}.items():
    asset = assets / ('demo.' + suffix)
    assert asset.is_file() and asset.read_bytes()[:4] == magic, asset
atlas = (assets / 'atlas.rgba').read_bytes()
assert atlas[:4] == b'FCAT'
w, h = struct.unpack_from('<HH', atlas, 4)
assert (w, h) == (1056, 1200)
assert len(atlas) == 8 + w * h * 4
# Host-side check that Android renderer is wired to the touch drag preview.
renderer = (root / 'android/app/src/main/cpp/GlRenderer.cpp').read_text()
appmain = (root / 'android/app/src/main/cpp/android_main.cpp').read_text()
assert 'glBufferSubData' in renderer and 'vertexGpuCapacity_' in renderer
assert 'touch->inventoryDrag()' in renderer
assert 'renderer.render(game,interpolation,&touch)' in appmain
assert (root / 'tools/check_apk.py').is_file()
assert 'tools/check_apk.py' in (root / '.github/workflows/validate.yml').read_text()
print('Android manifest, Gradle, assets, and APK CI check: PASS (host-only)')
