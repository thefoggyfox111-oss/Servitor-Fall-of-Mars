#include "forge/Simulation.hpp"
#include "forge/SaveSystem.hpp"
#include "forge/EnemyFormat.hpp"
#include "forge/Equipment.hpp"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <unistd.h>
using namespace forge;
static void require(bool pass,const char* what) {
    if(!pass){std::cerr<<"FAIL: "<<what<<'\n';std::exit(1);}
}
static std::vector<std::byte> bytes(std::filesystem::path file) {
    std::ifstream in(file,std::ios::binary);
    require(in.good(),"required fixture exists");
    std::vector<char> c((std::istreambuf_iterator<char>(in)),std::istreambuf_iterator<char>());
    std::vector<std::byte> result;
    for(unsigned char b:c)result.push_back(static_cast<std::byte>(b));
    return result;
}
int main() {
    const auto root=std::filesystem::path(FORGECELL_SOURCE_ROOT);
    Simulation original;
    std::string err;
    const auto weapons=bytes(root/"android/app/src/main/assets/demo.fcwp");
    const auto items=bytes(root/"android/app/src/main/assets/demo.fcit");
    const auto enemies=bytes(root/"android/app/src/main/assets/demo.fcey");
    require(original.combat.loadEquipment(weapons,err),"load weapon file");
    require(original.combat.loadItems(items,err),"load item file");
    require(original.combat.loadEnemies(enemies,original.world,err),"load enemy file");
    require(original.combat.enemies.size()==5 && original.combat.enemies[1].lootId=="heavy_axe",
        "enemies have data-driven stats and loot");
    require(original.combat.enemies[2].detectionRange==310.f,"ranged enemy detection configured");
    std::vector<Combatant> decoded;
    require(decodeEnemyBinary(enemies,decoded,err) && decoded.size()==5,"FCEY standalone parse");
    auto badEnemy=enemies;badEnemy.resize(badEnemy.size()-1);
    auto pristine=original.combat.enemies;
    require(!original.combat.loadEnemies(badEnemy,original.world,err) &&
            original.combat.enemies.size()==pristine.size(),"corrupt enemy load is atomic");
    auto badItems=items;badItems[0]=std::byte{'X'};
    auto count=original.combat.equipment.itemDefinitions.size();
    require(!original.combat.loadItems(badItems,err)&&original.combat.equipment.itemDefinitions.size()==count,
        "corrupt item catalog is rejected without mutation");
    auto& eq=original.combat.equipment;
    auto findInBag=[&](const char* id)->size_t {
        for(size_t i=0;i<eq.backpack.size();++i)if(eq.backpack[i]==id)return i;
        return eq.backpack.size();
    };
    require(eq.equipAccessoryFromBackpack(findInBag("scrap_armor"),0),"equip armor from backpack");
    require(eq.equipAccessoryFromBackpack(findInBag("berserker_rune"),1),"equip passive from backpack");
    require(eq.equipAccessoryFromBackpack(findInBag("vitality_chip"),2),"equip second passive");
    require(eq.equipAccessoryFromBackpack(findInBag("medkit"),3),"equip consumable");
    require(eq.bonusHealth()==40 && eq.bonusDamage()==7 && eq.damageReduction()==4,
        "equipment modifiers combine by slot");
    original.player.maxHealth=140;original.player.health=95;
    require(original.combat.useConsumable(original.player),"consume healing item");
    require(original.player.health==130 && eq.accessories[3].empty(),"consumable removed and healing applied");
    require(!original.combat.useConsumable(original.player),"consumable cannot be used twice");
    original.player.pos={150,294};original.player.prevPos=original.player.pos;
    original.player.facingRight=false;
    original.player.health=117;
    original.combat.enemies[4].health=120;
    original.combat.enemies[4].bossPhase=2;
    original.combat.enemies[4].attacksFinished=3;
    original.combat.enemies[1].health=0;
    original.combat.enemies[1].alive=false;
    original.combat.enemies[1].lootSpawned=true;
    original.combat.transients.addPickup({2,"heavy_axe",760,282,false});
    original.combat.setAmmo(41);
    require(original.combat.magazineRemaining()==12,"initial magazine count expected");
    original.combat.reload();
    auto save=SaveCodec::encode(original);
    require(save.size()>100&&save.size()<256*1024,"bounded checkpoint created");
    Simulation restored;
    require(restored.combat.loadEquipment(weapons,err),"target weapon defs");
    require(restored.combat.loadItems(items,err),"target item defs");
    require(restored.combat.loadEnemies(enemies,restored.world,err),"target enemy defs");
    require(SaveCodec::decode(save,restored,err),"read checkpoint");
    require(restored.player.health==117 && restored.player.maxHealth==140 &&
        restored.player.pos.x==150 && !restored.player.facingRight,"player state round trip");
    require(restored.combat.enemies[4].health==120 && restored.combat.enemies[4].bossPhase==2 &&
        restored.combat.enemies[4].attacksFinished==3,"boss progress restored");
    require(!restored.combat.enemies[1].alive && restored.combat.enemies[1].lootSpawned &&
        restored.combat.transients.pickups().size()==1,"enemy deaths and uncollected loot persist");
    require(restored.combat.equipment.accessories[0]=="scrap_armor" &&
        restored.combat.equipment.accessories[1]=="berserker_rune" &&
        restored.combat.equipment.accessories[3].empty(),"accessories and consumed items persist");
    require(restored.combat.ammo()==41 && restored.combat.magazineRemaining()==12 &&
        !restored.combat.reloading(),"ammo persists; transient reload resets");
    restored.combat.tick(kFixedDt,restored.player,restored.world,false,false);
    auto tampered=save;tampered.back()^=std::byte{0x01};
    const auto previousHealth=restored.player.health;
    require(!SaveCodec::decode(tampered,restored,err)&&restored.player.health==previousHealth,
        "CRC error leaves world unchanged");
    auto truncated=save;truncated.pop_back();
    require(!SaveCodec::decode(truncated,restored,err),"truncated checkpoint rejected");
    auto invalidVersion=save;invalidVersion[4]=std::byte{99};
    require(!SaveCodec::decode(invalidVersion,restored,err),"unknown version rejected");
    Simulation incompatible;
    require(incompatible.combat.loadEquipment(weapons,err),"init incompatible game");
    require(incompatible.combat.loadEnemies(enemies,incompatible.world,err),"init incompatible enemies");
    require(!SaveCodec::decode(save,incompatible,err),"unavailable saved items are rejected");
    const auto temp=std::filesystem::temp_directory_path()/
        ("forgecell_test_"+std::to_string(getpid())+".fcsv");
    require(saveCheckpoint(temp.string(),original,err),"atomic POSIX write");
    Simulation disk;
    require(disk.combat.loadEquipment(weapons,err)&&disk.combat.loadItems(items,err)&&
        disk.combat.loadEnemies(enemies,disk.world,err),"setup disk target");
    require(loadCheckpoint(temp.string(),disk,err)&&disk.player.health==117,"read saved file");
    require(!std::filesystem::exists(temp.string()+".tmp"),"no orphan temporary checkpoint");
    std::filesystem::remove(temp);
    std::cout<<"ForgeCell Save/Content: ALL ASSERTIONS PASSED\n";
}
