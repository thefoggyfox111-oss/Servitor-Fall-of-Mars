#include "forge/Simulation.hpp"
#include "forge/TouchControls.hpp"
#include "forge/SaveSystem.hpp"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>
#include <set>
#include <string>
#include <vector>
using namespace forge;
namespace {
void testSort() {
    Simulation sim;
    auto& eq=sim.combat.equipment;
    ItemDefinition common; common.id="basic_armor"; common.name="Basic armor";
    common.kind=ItemKind::Armor;common.rarity=0;common.level=5;
    ItemDefinition rare=common;rare.id="rare_armor";rare.name="Rare armor";
    rare.rarity=4;rare.level=6;
    ItemDefinition consumable;consumable.id="medkit";consumable.name="Medkit";
    consumable.kind=ItemKind::Consumable;consumable.rarity=2;consumable.healAmount=25;
    assert(eq.setItems({common,rare,consumable}));
    assert(eq.addInstanceToBackpack("rare_armor",{12,1,0,0,0}));
    std::string rareToken;
    for(const auto& token:eq.backpack)if(eq.instance(token))rareToken=token;
    assert(!rareToken.empty());
    // Intentionally scramble categories and rarity; keep physical instance token.
    eq.backpack={};
    eq.backpack[3]="medkit";
    eq.backpack[9]="basic_armor";
    eq.backpack[17]="rifle";
    eq.backpack[18]=rareToken;
    eq.backpack[21]="heavy_axe";
    const auto equippedBefore=eq.equipped;
    const uint32_t instanceUid=eq.instance(rareToken)->uid;
    sim.inventoryOpen=true;
    sim.inventorySelectionArmed=true;
    sim.inventorySelected=21;
    const Vec2 playerBefore=sim.player.pos;
    Input sort;sort.sortInventoryPressed=true;sort.move=1;
    sim.tick(kFixedDt,sort);
    assert(sim.inventoryOpen && !sim.inventorySelectionArmed);
    assert(sim.player.pos.x==playerBefore.x && sim.player.pos.y==playerBefore.y);
    assert(eq.backpack[0]=="heavy_axe");
    assert(eq.backpack[1]=="rifle");
    assert(eq.backpack[2]==rareToken && eq.backpack[3]=="basic_armor");
    assert(eq.backpack[4]=="medkit");
    assert(eq.equipped==equippedBefore);
    assert(eq.instance(rareToken) && eq.instance(rareToken)->uid==instanceUid);
    for(size_t i=5;i<eq.backpack.size();++i)assert(eq.backpack[i].empty());
    const auto save=SaveCodec::encode(sim);
    Simulation restored;
    assert(restored.combat.equipment.setItems({common,rare,consumable}));
    std::string error;
    if(!SaveCodec::decode(save,restored,error)) {
        std::cerr<<"Decode failed: "<<error<<'\n';std::abort();
    }
    assert(restored.combat.equipment.backpack==eq.backpack);
    assert(restored.combat.equipment.instance(rareToken));
    restored.combat.equipment.sortBackpack();
    assert(restored.combat.equipment.backpack==eq.backpack); // idempotent
}
void testTouch() {
    TouchControls touch;touch.resize(640,360);touch.setInventoryOpen(true);
    // Sort is left of the bag, drop is right; each edge occurs exactly once.
    const auto sort=TouchControls::buttonCenter(Control::Sort,640,360);
    const auto drop=TouchControls::buttonCenter(Control::Drop,640,360);
    touch.pointerDown(12,sort.x,sort.y);
    Input request=touch.sample();
    assert(request.sortInventoryPressed && !request.dropSelectedPressed);
    assert(!touch.sample().sortInventoryPressed);
    touch.pointerUp(12,sort.x,sort.y);
    touch.pointerDown(13,drop.x,drop.y);
    request=touch.sample();
    assert(!request.sortInventoryPressed && request.dropSelectedPressed);
    touch.pointerUp(13,drop.x,drop.y);
    touch.pointerDown(14,sort.x,sort.y);
    touch.clear();
    assert(!touch.sample().sortInventoryPressed); // lifecycle cancellation
}
void testCeilingOrder() {
    World world;
    world.width=600;world.height=360;
    world.oneWay={};
    world.solids={{0,294,600,66},{100,211,60,21},{100,211,60,23}};
    Combatant enemy;enemy.id=101;enemy.role=EnemyRole::Dummy;
    enemy.x=enemy.previousX=enemy.spawnX=120.f;
    enemy.y=enemy.previousY=270.f;enemy.spawnY=294.f;
    enemy.vy=-355.f;enemy.airborne=true;
    enemy.navTargetX=120.f;enemy.navTargetY=270.f;
    CombatSystem sim;sim.enemies={enemy};
    Player player;player.health=0;
    sim.tick(kFixedDt,player,world,false,false);
    assert(std::abs(sim.enemies.front().y-268.f)<.01f);
    assert(sim.enemies.front().vy==0 && sim.enemies.front().airborne);
    // Opposite authored order must give the same physical result.
    std::swap(world.solids[1],world.solids[2]);
    CombatSystem reversed;reversed.enemies={enemy};
    reversed.tick(kFixedDt,player,world,false,false);
    assert(std::abs(reversed.enemies.front().y-268.f)<.01f);
}
void testFallRecovery() {
    World world;
    world.width=600;world.height=360;
    world.solids={{0,228,600,16}};
    world.oneWay.clear();
    Combatant enemy;
    enemy.id=99;enemy.role=EnemyRole::Dummy;
    enemy.spawnX=enemy.x=enemy.previousX=320.f;
    enemy.spawnY=enemy.y=enemy.previousY=228.f;
    enemy.y=world.height+71.f;
    enemy.airborne=true;enemy.vy=490;
    enemy.navPlanTimer=.15f;enemy.navPlanValid=true;
    CombatSystem combat;
    combat.enemies={enemy};
    Player player;player.health=0;
    combat.tick(kFixedDt,player,world,false,false);
    const auto& recovered=combat.enemies.front();
    assert(std::abs(recovered.y-228.f)<.01f);
    assert(std::abs(recovered.x-320.f)<.01f);
    assert(recovered.previousX==recovered.x && recovered.previousY==recovered.y);
    assert(!recovered.airborne && recovered.vx==0 && recovered.vy==0);
    assert(!recovered.navPlanValid);
}
}
int main() {
    testSort();testTouch();testFallRecovery();testCeilingOrder();
    std::cout<<"ForgeCell 0.14 inventory and recovery: PASS\n";
}
