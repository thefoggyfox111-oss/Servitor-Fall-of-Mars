#include "forge/Simulation.hpp"
#include "forge/Navigation.hpp"
#include "forge/TouchControls.hpp"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
using namespace forge;
static void check(bool ok,const char* msg) {if(!ok){std::cerr<<"FAILED: "<<msg<<'\n';std::exit(1);}}
static World arena() {World w;w.width=900;w.height=360;w.solids={{0,294,900,66}};w.oneWay={};return w;}
static Combatant unit(uint32_t id,float x,EnemyRole role,int hp=100) {
    Combatant c;c.id=id;c.x=c.previousX=c.spawnX=x;c.y=294;
    c.role=role;c.health=c.maxHealth=hp;return c;
}
int main() {
    World gap=arena();gap.solids={{0,294,245,66},{315,294,585,66}};
    auto hop=planPlatformHop(gap,{210,294},{350,294});
    check(hop.valid && hop.transition && hop.takeoffX>=220 && hop.landingX>=315,
          "short gap has a route with distinct takeoff/landing points");
    World chasm=arena();chasm.solids={{0,294,220,66},{440,294,460,66}};
    check(!planPlatformHop(chasm,{200,294},{475,294}).valid,
          "unreachable chasm not erroneously connected");
    World step=arena();step.solids.push_back({270,228,115,14});
    auto elevated=planPlatformHop(step,{220,294},{335,228});
    check(elevated.valid && elevated.transition && elevated.landingY==228,
          "elevated platform reachable with jump");

    CombatSystem enemies;
    enemies.enemies={unit(1,210,EnemyRole::Grunt)};
    Player player;player.pos={355,294};player.prevPos=player.pos;player.grounded=true;
    bool jumped=false;
    for(int i=0;i<300;++i) {
        enemies.tick(kFixedDt,player,gap,false,false);
        jumped|=enemies.enemies.front().airborne;
    }
    check(jumped,"ground fighter performs a planned jump");
    check(enemies.enemies.front().x>315 && !enemies.enemies.front().airborne,
          "fighter lands across a reachable short gap");

    // Returning enemies use pathfinding too; they must not freeze on the
    // opposite side of a gap once the player leaves their detection zone.
    player.health=0; // suppress reacquisition while testing the return path
    bool returningJump=false;
    for(int i=0;i<540;++i) {
        enemies.tick(kFixedDt,player,gap,false,false);
        returningJump|=enemies.enemies.front().airborne;
    }
    check(returningJump && std::abs(enemies.enemies.front().x-210.f)<40.f &&
          std::abs(enemies.enemies.front().y-294.f)<2.f,
          "enemy returns across a gap using platform navigation");
    player.health=100;

    // For overlapping landing candidates, resolve the earliest crossed surface
    // even when the surfaces appear in reverse order in the level data.
    World landing=arena();
    landing.solids={{0,294,900,66},{300,250,90,12}};
    landing.oneWay={{300,230,90,8}};
    CombatSystem descending;
    Combatant falling=unit(55,340,EnemyRole::Dummy);
    falling.y=falling.previousY=205;
    falling.airborne=true;falling.vy=490;
    falling.navTargetX=340;falling.navTargetY=294;
    descending.enemies={falling};
    Player noTarget;noTarget.health=0;
    for(int i=0;i<8;++i)descending.tick(kFixedDt,noTarget,landing,false,false);
    check(std::abs(descending.enemies.front().y-230.f)<.1f &&
          !descending.enemies.front().airborne,
          "first top surface wins regardless of list ordering");

    CombatSystem climbers;
    climbers.enemies={unit(7,220,EnemyRole::Grunt)};
    player.pos={335,228};player.prevPos=player.pos;
    bool ascended=false;
    for(int i=0;i<300;++i) {
        climbers.tick(kFixedDt,player,step,false,false);
        ascended|=climbers.enemies.front().airborne;
    }
    check(ascended,"enemy tries to jump up to higher platform");
    check(std::abs(climbers.enemies.front().y-228.f)<2.f,
          "enemy lands on higher platform without passing through solid underside");

    CombatSystem fromUnder;
    fromUnder.enemies={unit(9,308,EnemyRole::Grunt)};
    player.pos={335,228};player.prevPos=player.pos;
    for(int i=0;i<360;++i)fromUnder.tick(kFixedDt,player,step,false,false);
    check(std::abs(fromUnder.enemies.front().y-228.f)<2.f,
          "enemy below raised platform routes around its edge rather than phasing through it");

    CombatSystem boss;
    boss.enemies={unit(8,235,EnemyRole::Boss,350)};
    check(boss.enemies.front().bossPhase==1,"boss starts in phase 1");
    boss.enemies.front().health=170;
    player.pos={160,294};player.prevPos=player.pos;player.health=200;player.maxHealth=200;
    boss.tick(kFixedDt,player,arena(),false,false);
    check(boss.enemies.front().bossPhase==2,"boss changes phase at 50 percent HP");
    boss.enemies.front().attacksFinished=1;
    for(int i=0;i<100;++i)boss.tick(kFixedDt,player,arena(),false,false);
    check(boss.enemyAttackEvents>0,"phase 2 performs an attack");
    check(boss.enemies.front().attacksFinished>1,"boss attack lifecycle advances");

    CombatSystem drops;drops.enemies={unit(40,225,EnemyRole::Heavy,12)};
    player.pos={200,294};player.prevPos=player.pos;player.facingRight=true;
    drops.tick(kFixedDt,player,arena(),true,false);
    for(int i=0;i<20;++i)drops.tick(kFixedDt,player,arena(),false,false);
    check(!drops.enemies.front().alive && drops.transients.pickups().size()==1 && !drops.transients.pickups().front().value.collected,
          "lethal damage spawns exactly one collectible");
    check(drops.collectNearby(player),"nearby item can be collected into backpack");
    check(drops.pickupsCollected==1 && drops.transients.pickups().front().value.collected,
          "pickup is marked collected");
    check(!drops.collectNearby(player) && drops.pickupsCollected==1,"cannot collect loot twice");
    check(drops.dropFromBackpack(0,player),"backpack contents can be dropped");
    check(drops.equipment.backpack[0].empty(),"drop frees backpack cell");
    for(auto& slot:drops.equipment.backpack)slot="pistol";
    drops.transients.addPickup({99,"rifle",player.pos.x,player.pos.y-12,false});
    const int before=drops.pickupsCollected;
    check(!drops.collectNearby(player) && drops.pickupsCollected==before,
          "full backpack prevents collection and keeps item in world");

    Simulation sim;sim.combat.enemies.clear();sim.player.grounded=true;
    const Vec2 saved=sim.player.pos;
    Input input;input.inventoryPressed=true;
    sim.tick(kFixedDt,input);
    check(sim.inventoryOpen,"inventory toggles open");
    input={};input.move=1;input.jumpPressed=true;
    for(int i=0;i<20;++i)sim.tick(kFixedDt,input);
    check(sim.player.pos.x==saved.x && sim.player.pos.y==saved.y,
          "inventory pauses character movement");
    input={};input.inventoryIndex=0;sim.tick(kFixedDt,input);
    check(sim.inventorySelectionArmed && sim.combat.equipment.slot(0)->id=="rusted_sword",
          "first inventory tap previews without equipping");
    sim.tick(kFixedDt,input);
    check(!sim.inventorySelectionArmed && sim.combat.equipment.slot(0)->id=="heavy_axe",
          "second tap equips selected weapon class");
    input={};input.dropSelectedPressed=true;sim.tick(kFixedDt,input);
    check(!sim.combat.equipment.backpack[0].empty() && sim.combat.transients.pickups().empty(),
          "drop without selection is ignored");
    input={};input.inventoryIndex=0;sim.tick(kFixedDt,input);
    input={};input.dropSelectedPressed=true;sim.tick(kFixedDt,input);
    check(sim.combat.equipment.backpack[0].empty() && !sim.combat.transients.pickups().empty(),
          "inventory drop control removes selected item and creates world drop");
    input={};input.inventoryPressed=true;sim.tick(kFixedDt,input);
    check(!sim.inventoryOpen,"inventory closes");

    TouchControls touch;touch.resize(640,360);
    touch.pointerDown(1,320,28);
    check(touch.sample().inventoryPressed,"inventory control mapped to touch");
    touch.pointerUp(1);touch.setInventoryOpen(true);
    touch.pointerDown(2,206,79);
    check(touch.sample().inventoryIndex==-1,"inventory does not equip during drag");
    touch.pointerUp(2,206,79);
    check(touch.sample().inventoryIndex==0,"first inventory cell maps correctly on release");
    touch.pointerDown(3,470,270);
    check(touch.sample().dropSelectedPressed,"drop button maps correctly");
    std::cout<<"ForgeCell Navigation/Loot/UI: ALL ASSERTIONS PASSED\n";
}
