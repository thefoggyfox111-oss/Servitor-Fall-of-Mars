#include "forge/Simulation.hpp"
#include "forge/TouchControls.hpp"
#include "forge/WorldObjects.hpp"
#include "forge/SaveSystem.hpp"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>
#include <cmath>
using namespace forge;
static void check(bool good,const char* name) {
    if(!good){std::cerr<<"FAILED: "<<name<<'\n';std::exit(1);}
}
static std::vector<std::byte> read(const char* name) {
    std::ifstream input(std::string(FORGECELL_SOURCE_ROOT)+"/android/app/src/main/assets/"+name,std::ios::binary);
    check(input.good(),"load bundled asset");
    std::string raw(std::istreambuf_iterator<char>{input},{});
    std::vector<std::byte> bytes;
    for(unsigned char c:raw)bytes.push_back(static_cast<std::byte>(c));
    return bytes;
}
int main() {
    const auto bytes=read("demo.fcob");
    WorldObjectSystem props;
    World world;
    std::string error;
    check(props.load(bytes,world,error),"load real FCOB level objects");
    check(props.size()==4,"level spawns all objects");
    auto saved=props.entries().front().entity;
    auto corrupted=bytes;corrupted.back()=std::byte{0xFF};
    check(!props.load(corrupted,world,error),"invalid FCOB rejects non-finite size");
    check(props.size()==4 && props.get(saved),"rejected data never mutates gameplay");
    check(!props.add({10001,WorldObjectKind::Crate,260,294,50,50,24}).generation,
          "duplicate stable object id rejected");
    check(!props.add({12,WorldObjectKind::Crate,NAN,294,50,50,24}).generation,
          "non-finite coordinates rejected");
    WorldObjectSystem duplicated=props;
    check(duplicated.size()==props.size(),"ECS copy maintains components with own registry");
    check(duplicated.remove(duplicated.entries()[0].entity),"remove copy element");
    check(props.size()==4,"ECS copy doesn't alias original registry");
    const auto stale=duplicated.entries()[0].entity;
    duplicated.clear();
    check(!duplicated.get(stale),"clearing props invalidates handle");

    Player p;
    p.pos={217,294};p.facingRight=true;
    const auto* crate=props.get(saved);
    check(crate && crate->health==50,"crate begins with configured health");
    AttackDefinition sword;
    sword.damage=30;sword.reach=36;sword.height=27;
    check(props.applyMelee(p,sword,1)==1,"crate receives sword damage");
    check(props.get(saved)->health==20,"hit uses configured damage");
    check(props.applyMelee(p,sword,1)==0 && props.get(saved)->health==20,
          "one swing may not damage same crate twice");
    check(props.applyMelee(p,sword,2)==1 && props.get(saved)->health==0,
          "second swing destroys crate");
    check(props.applyMelee(p,sword,3)==0,"destroyed crate no longer takes damage");
    p.pos={170,294};
    check(props.interact(p) && props.lastCheckpoint()==10003,"checkpoint activates via world interaction");
    check(!props.interact(p),"checkpoint cannot activate repeatedly");
    check(!props.remove({saved.index,saved.generation+1}),"stale handle can't delete object");
    check(props.remove(saved) && !props.get(saved),"destruction invalidates generation");

    Equipment equipment;
    check(equipment.swapBackpack(0,4) && equipment.backpack[4]=="heavy_axe",
          "drag to empty backpack cell");
    check(equipment.swapBackpack(4,1) && equipment.backpack[1]=="heavy_axe" &&
          equipment.backpack[4]=="rifle","swap two items without duplication");
    check(!equipment.transferEquipmentToBackpack(0,3),"cannot unequip required weapon to empty slot");
    check(equipment.transferEquipmentToBackpack(0,1) && equipment.equipped[0]=="heavy_axe",
          "weapon slot exchanges compatible backpack weapon");
    check(!equipment.transferEquipmentToBackpack(0,4),"weapon rejects mismatched ranged item");
    check(!equipment.swapBackpack(0,99),"out-of-range drag rejected");

    TouchControls controls;controls.resize(640,360);controls.setInventoryOpen(true);
    controls.pointerDown(31,209,84);
    controls.pointerMove(31,396,84);
    check(controls.sample().inventoryIndex==-1,"drag does not trigger premature equip");
    controls.pointerUp(31,396,84);
    Input moved=controls.sample();
    check(moved.inventoryMoveFrom==0 && moved.inventoryMoveTo==5,
          "release creates backpack-to-backpack drag command");
    check(controls.sample().inventoryMoveFrom==-1,"gesture fires only once");
    controls.pointerDown(32,209,84);
    controls.pointerUp(32,457,82);
    Input equipped=controls.sample();
    check(equipped.inventoryMoveFrom==0 && equipped.inventoryEquipSlot==0,
          "drag from bag to melee equipment slot");
    controls.pointerDown(33,458,136); // armor slot, equipment index 2
    controls.pointerUp(33,209,84);
    Input unequipped=controls.sample();
    check(unequipped.inventoryUnequipSlot==2 && unequipped.inventoryUnequipTo==0,
          "drag armor from equipment to backpack");
    controls.pointerDown(34,209,84);
    controls.pointerUp(34,209,84);
    check(controls.sample().inventoryIndex==0,"tap selects the backpack cell for preview");
    controls.pointerDown(35,470,270);
    check(controls.sample().dropSelectedPressed,"drop button remains accessible");

    Simulation sim;
    check(sim.objects.load(bytes,sim.world,error),"scene owns live ECS prop entities");
    sim.combat.enemies.clear();sim.player.pos={217,294};sim.player.grounded=true;
    Input swing;swing.attackPressed=true;
    sim.tick(kFixedDt,swing);
    for(int i=0;i<12;++i)sim.tick(kFixedDt,{});
    check(sim.objects.entries().front().value.health==20,
          "simulation connects attack active window to ECS destructibles");
    for(int i=0;i<35;++i)sim.tick(kFixedDt,{}); // finish weapon attack before changing equipment
    Input inventory;inventory.inventoryPressed=true;sim.tick(kFixedDt,inventory);
    check(sim.inventoryOpen,"inventory pause open");
    inventory={};inventory.inventoryMoveFrom=0;inventory.inventoryMoveTo=5;
    sim.tick(kFixedDt,inventory);
    check(sim.combat.equipment.backpack[0].empty() &&
          sim.combat.equipment.backpack[5]=="heavy_axe", "simulation executes bag drag");
    inventory={};inventory.inventoryMoveFrom=5;inventory.inventoryEquipSlot=0;
    sim.tick(kFixedDt,inventory);
    check(sim.combat.equipment.equipped[0]=="heavy_axe" &&
          sim.combat.equipment.backpack[5]=="rusted_sword","simulation equips by drag");
    // Existing FCSV checkpoint remains readable with the new ECS objects in memory.
    Player adjacent=sim.player;adjacent.pos={170,294};
    check(sim.objects.interact(adjacent),"activated checkpoint before saving");
    const auto checkpoint=SaveCodec::encode(sim);
    check(checkpoint[4]==std::byte{3},"new saves use FCSV v3");
    Simulation restored;
    restored.combat.enemies.clear(); // match active enemy catalog of saved session
    check(restored.objects.load(bytes,restored.world,error),"new ECS objects loaded in restored scene");
    check(SaveCodec::decode(checkpoint,restored,error),"backwards-compatible FCSV checkpoint");
    check(restored.combat.equipment.slot(0)->id=="heavy_axe", "inventory survives save/load");
    check(restored.objects.entries().front().value.health==20 &&
          restored.objects.lastCheckpoint()==10003,
          "FCSV v2 restores destructible health and activated checkpoint");
    // Convert new v3 checkpoint to v1 by removing the instance catalog and object states.
    auto oldSave=checkpoint;
    oldSave.resize(oldSave.size()-2); // v3: zero individual instances in this fixture
    constexpr size_t objectStateBytes=2+4*7;
    oldSave.resize(oldSave.size()-objectStateBytes);
    oldSave[4]=std::byte{1};
    auto write32=[&](size_t at,uint32_t n) {
        for(unsigned i=0;i<4;++i)oldSave[at+i]=static_cast<std::byte>(n>>(i*8));
    };
    write32(8,static_cast<uint32_t>(oldSave.size()-16));
    uint32_t crc=0xFFFFFFFFu;
    for(size_t i=16;i<oldSave.size();++i) {
        crc^=std::to_integer<uint8_t>(oldSave[i]);
        for(int k=0;k<8;++k)crc=(crc>>1) ^ (0xEDB88320u &
            static_cast<uint32_t>(-static_cast<int>(crc&1)));
    }
    write32(12,~crc);
    Simulation migrated;
    migrated.combat.enemies.clear();
    check(migrated.objects.load(bytes,migrated.world,error),"load object definitions for old save");
    check(SaveCodec::decode(oldSave,migrated,error),"old FCSV v1 still loads");
    check(migrated.objects.entries().front().value.health==50,
          "old save initializes newly introduced objects to defaults");
    std::cout<<"ForgeCell Objects/Inventory: ALL ASSERTIONS PASSED\n";
}
