#include "forge/Simulation.hpp"
#include "forge/TouchControls.hpp"
#include "forge/EntityRegistry.hpp"
#include "forge/WorldFormat.hpp"
#include <cstring>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <iostream>
using namespace forge;
static void require(bool ok, const char* message) {
    if (!ok) { std::cerr << "FAILED: " << message << '\n'; std::exit(1); }
}
int main() {
    require(overlaps({0,0,10,10},{9,9,5,5}), "AABB overlap");
    require(!overlaps({0,0,10,10},{10,0,2,2}), "AABB touching edge");
    Simulation s;
    for(int i=0;i<90;++i) s.tick(kFixedDt, {});
    require(s.player.grounded, "gravity leads to grounded");
    require(std::abs(s.player.pos.y - 294) < 0.05f, "feet on fixed world ground");
    Input jump; jump.jumpPressed=true; jump.jumpHeld=true;
    s.tick(kFixedDt, jump);
    require(s.player.vel.y < 0, "jump generates upwards impulse");
    require(!s.player.grounded, "player airborne after jump");
    for(int i=0;i<100;++i) s.tick(kFixedDt, {});
    require(s.player.grounded, "player lands after jump");
    const float oldGroundY = s.world.solids[0].y;
    for(int i=0;i<60;++i) {Input run;run.move=1;s.tick(kFixedDt,run);}
    require(s.player.pos.x > 150, "player can run");
    require(s.world.solids[0].y == oldGroundY, "camera does not move world geometry");
    Simulation c;
    for(int i=0;i<90;++i) c.tick(kFixedDt,{});
    Input roll; roll.rollPressed=true;
    c.tick(kFixedDt,roll);
    require(c.player.rolling, "roll starts");
    for(int i=0;i<8;++i) c.tick(kFixedDt,{});
    require(c.player.invulnerable, "roll iframe active");
    for(int i=0;i<25;++i) c.tick(kFixedDt,{});
    require(!c.player.rolling && !c.player.invulnerable, "roll ends");
    Animator a; a.change(Animation::Run);
    for(int i=0;i<16;++i) a.tick(kFixedDt);
    require(a.frame > 0, "animation advances frames");
    FixedStepper step;
    int count=0;
    auto alpha=step.advance(1.0 / 30.0, [&](float){++count;});
    require(count==2 && alpha>=0 && alpha<1, "fixed 60Hz from 30Hz frame");
    TouchControls touch; touch.resize(640,360);
    touch.pointerDown(1, 90, 300);
    touch.pointerMove(1, 120, 300);
    touch.pointerDown(2, 565, 292);
    const Input t=touch.sample();
    require(t.move > 0.5f && t.jumpPressed && t.jumpHeld, "multitouch jump and move");
    require(!touch.sample().jumpPressed, "jump edge emitted once");
    touch.pointerUp(2); touch.pointerUp(1);
    require(!touch.sample().jumpHeld, "release jump");
    EntityRegistry ecs;
    auto e=ecs.create();
    ComponentPool<Vec2> positions;
    positions.set(e,{11,17});
    require(ecs.alive(e) && positions.get(e) && positions.get(e)->x==11, "component lookup");
    require(ecs.destroy(e) && !ecs.alive(e), "entity deletion");
    auto next=ecs.create();
    require(e.index == next.index && e.generation != next.generation &&
            positions.get(next)==nullptr, "stale generation safely ignored");
    // Verify binary format validation and that rejected levels preserve the old world.
    World original;
    std::string error;
    std::vector<std::byte> wrong(24);
    require(!loadWorldBinary(wrong,original,error), "bad world signature rejected");
    require(original.solids.size()==10, "invalid world cannot overwrite live world");
    std::cout << "ForgeCell Core: ALL ASSERTIONS PASSED\n";
}
