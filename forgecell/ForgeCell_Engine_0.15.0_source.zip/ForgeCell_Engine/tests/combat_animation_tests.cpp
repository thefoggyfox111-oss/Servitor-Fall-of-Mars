#include "forge/Simulation.hpp"
#include "forge/TouchControls.hpp"
#include "forge/AnimationFormat.hpp"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iterator>
#include <span>
#include <string>
#include <limits>
using namespace forge;
static void check(bool ok,const char* message) {
    if(!ok) {std::cerr<<"FAILED: "<<message<<'\n';std::exit(1);}
}
static World testWorld() {
    World w;
    w.width=1000;w.height=360;
    w.solids={{0,294,1000,66}};
    w.oneWay.clear();
    return w;
}
static Player testPlayer() {
    Player p;
    p.pos={200,294};p.prevPos=p.pos;p.grounded=true;
    return p;
}
static Combatant testDummy(uint32_t id, float x) {
    Combatant e;
    e.id=id; e.x=x; e.y=294; e.previousX=x; e.previousY=294;
    e.spawnX=x; e.health=e.maxHealth=100; e.vx=100;
    return e;
}
int main() {
    // Variable-duration clips, anchors, frame events, non-looping stop.
    Animator anim;
    SpriteClip clip;
    clip.loop=false;
    clip.frames.resize(3);
    clip.frames[0].seconds=.04f;
    clip.frames[1].seconds=.07f;
    clip.frames[2].seconds=.02f;
    clip.frames[1].events=0x02;
    clip.frames[1].anchors[static_cast<size_t>(AnchorId::Muzzle)]={27,18};
    check(anim.setClip(Animation::Attack,clip),"valid authored clip accepted");
    anim.change(Animation::Attack);
    anim.tick(.03f);
    check(anim.frame==0,"frame remains for authored duration");
    anim.tick(.02f);
    check(anim.frame==1,"frame changes at authored timing");
    check(anim.takeEvents()==0x02 && anim.takeEvents()==0,"events emitted exactly once");
    check(anim.currentFrame()->anchors[static_cast<size_t>(AnchorId::Muzzle)].x==27,
          "frame anchors are accessible");
    anim.tick(.12f);
    check(anim.frame==2,"non-looping clip holds last frame");
    anim.tick(.5f);
    check(anim.frame==2,"non-looping clip does not wrap");
    clip.frames[0].seconds=-1;
    check(!anim.setClip(Animation::Attack,clip),"invalid authored duration rejected");
    SpriteClip many;
    many.frames.resize(64);
    for(auto& f:many.frames) f.seconds=.01f;
    check(anim.setClip(Animation::Run,std::move(many)),"64 frame clip supported by runtime");
    anim.change(Animation::Run);anim.tick(.31f);
    check(anim.frame==31,"over sixteen frames can play in simulation");

    // Runtime reads the same compiled asset used by the Android build.
    const std::string metadataPath=std::string(FORGECELL_SOURCE_ROOT)+
       "/android/app/src/main/assets/demo.fcan";
    std::ifstream file(metadataPath,std::ios::binary);
    check(file.good(),"FCAN demo asset exists");
    const std::string fileContents((std::istreambuf_iterator<char>(file)),
                                   std::istreambuf_iterator<char>());
    auto bytes=std::as_bytes(std::span(fileContents.data(),fileContents.size()));
    std::string error;
    Animator loaded;
    check(loadAnimationBinary(bytes,loaded,error),"compiled FCAN asset loads");
    loaded.change(Animation::Attack);
    loaded.tick(.105f);
    check(loaded.frame==4,"authored attack frame durations match runtime");
    check(loaded.takeEvents()==2,"authored frame event emitted");
    check(loaded.currentFrame()->anchors[static_cast<size_t>(AnchorId::Muzzle)].x==28,
          "authored muzzle anchor loaded");
    std::string invalid=fileContents;
    invalid[0]='X';
    const int previousFrame=loaded.frame;
    check(!loadAnimationBinary(std::as_bytes(std::span(invalid.data(),invalid.size())),
         loaded,error),"corrupted FCAN header rejected");
    check(loaded.frame==previousFrame,"rejected metadata preserves active animation");
    invalid=fileContents.substr(0,fileContents.size()-7);
    check(!loadAnimationBinary(std::as_bytes(std::span(invalid.data(),invalid.size())),
         loaded,error),"truncated FCAN frames rejected");

    World world=testWorld();
    Player player=testPlayer();
    CombatSystem combat; combat.resetDemo();
    combat.enemies={testDummy(10,228)};
    combat.tick(kFixedDt,player,world,true,false);
    check(combat.enemies[0].health==100,"melee startup has no early hit");
    for(int i=0;i<8;++i)combat.tick(kFixedDt,player,world,false,false);
    check(combat.enemies[0].health==70,"active hitbox damages front-facing enemy");
    for(int i=0;i<35;++i)combat.tick(kFixedDt,player,world,false,false);
    check(combat.enemies[0].health==70,"single swing never hits same target twice");
    check(!combat.attacking(),"attack recovery eventually completes");
    combat.tick(kFixedDt,player,world,true,false);
    for(int i=0;i<8;++i)combat.tick(kFixedDt,player,world,false,false);
    check(combat.enemies[0].health==40,"another swing can hit same target");
    combat.resetDemo();combat.enemies={testDummy(10,170)};
    combat.tick(kFixedDt,player,world,true,false);
    for(int i=0;i<20;++i)combat.tick(kFixedDt,player,world,false,false);
    check(combat.enemies[0].health==100,"hitbox does not hit enemies behind player");
    combat.resetDemo();combat.enemies={testDummy(10,228)};
    player.rolling=true;
    combat.tick(kFixedDt,player,world,true,true);
    check(combat.enemies[0].health==100 && combat.shotsFired()==0,
          "roll prevents starting melee and ranged attacks");
    player.rolling=false;

    // Projectile continuous collision and wall occlusion.
    combat.resetDemo(); combat.enemies={testDummy(10,420)};
    combat.tick(.35f,player,world,false,true); // bullet moves 227.5 units in one tick
    check(combat.enemies[0].health==84 && combat.transients.projectiles().empty(),
          "swept projectile hits a thin target despite coarse timestep");
    check(combat.ammo()==59,"shooting consumes ammo");
    combat.resetDemo();combat.enemies={testDummy(10,420)};
    world.solids.push_back({300,240,2,55});
    combat.tick(.35f,player,world,false,true);
    check(combat.enemies[0].health==100 && combat.transients.projectiles().empty(),
          "thin wall prevents projectile hitting target behind it");

    // Attacks stop when out of ammo; new projectiles have unique IDs.
    combat.resetDemo();combat.setAmmo(1);
    combat.tick(kFixedDt,player,testWorld(),false,true);
    check(combat.ammo()==0 && combat.shotsFired()==1,"last ammunition fires once");
    for(int i=0;i<20;++i)combat.tick(kFixedDt,player,testWorld(),false,false);
    combat.tick(kFixedDt,player,testWorld(),false,true);
    check(combat.shotsFired()==1,"empty magazine cannot fire");

    TouchControls touch;touch.resize(640,360);
    touch.pointerDown(1,105,290);
    touch.pointerDown(2,589,185);
    const auto both=touch.sample();
    check(both.shootPressed && both.move>0,"shoot and movement work in one multitouch sample");
    check(!touch.sample().shootPressed,"shoot edge consumed once");
    touch.pointerUp(2);touch.pointerUp(1);
    std::cout<<"ForgeCell Combat/Animation: ALL ASSERTIONS PASSED\n";
}
