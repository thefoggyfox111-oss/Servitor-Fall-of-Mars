#include "forge/Simulation.hpp"
#include "forge/Navigation.hpp"
#include "forge/SaveSystem.hpp"
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
using namespace forge;
static void check(bool ok,const char* msg) {
    if(!ok){std::cerr<<"FAILED: "<<msg<<'\n';std::exit(1);}
}
static std::vector<std::byte> bytes(const std::filesystem::path& file) {
    std::ifstream f(file,std::ios::binary);
    check(f.good(),"fixture exists");
    std::vector<char> chars((std::istreambuf_iterator<char>(f)),{});
    std::vector<std::byte> out;
    for(unsigned char ch:chars)out.push_back(static_cast<std::byte>(ch));
    return out;
}
int main() {
    const auto base=std::filesystem::path(FORGECELL_SOURCE_ROOT);
    std::string error;
    Equipment eq;
    const auto v2=bytes(base/"android/app/src/main/assets/demo.fcit");
    const auto v1=bytes(base/"tests/fixtures/items_v1.fcit");
    check(loadItemBinary(v2,eq,error),"FCIT v2 loads");
    check(eq.findItem("vitality_chip") && eq.findItem("vitality_chip")->level==3 &&
          eq.findItem("vitality_chip")->speedBonusPct==8 &&
          eq.findItem("berserker_rune")->rarity==2,"metadata preserved");
    check(eq.findItem("medkit") && eq.findItem("medkit")->level==1,"defaults in v2");
    auto corrupted=v2;
    // Last entry carries six extra bytes: rarity, level, speed.
    corrupted[corrupted.size()-6]=std::byte{0xff};
    check(!loadItemBinary(corrupted,eq,error) && eq.findItem("vitality_chip")->speedBonusPct==8,
          "bad rarity rejected atomically");
    auto truncated=v2;truncated.pop_back();
    check(!loadItemBinary(truncated,eq,error) && eq.itemDefinitions.size()==4,
          "truncated v2 catalog rejected atomically");
    auto trailing=v2;trailing.push_back(std::byte{0});
    check(!loadItemBinary(trailing,eq,error),"trailing bytes rejected");
    check(loadItemBinary(v1,eq,error),"FCIT v1 backward-compatible load");
    check(eq.findItem("vitality_chip")->speedBonusPct==0 &&
          eq.findItem("berserker_rune")->rarity==0 &&
          eq.findItem("scrap_armor")->level==1,"v1 metadata defaults");
    check(loadItemBinary(v2,eq,error),"reloading v2 succeeds");
    for(const auto& d:eq.itemDefinitions)check(eq.addToBackpack(d.id),"add demo items to bag");
    auto locate=[&](const char* id)->size_t {
        for(size_t i=0;i<eq.backpack.size();++i)
            if(eq.backpack[i]==id)return i;
        return eq.backpack.size();
    };
    const size_t chip=locate("vitality_chip");
    check(chip<eq.backpack.size(),"vitality chip available");
    const auto cmp=eq.compareBackpackToSlot(chip,3);
    check(cmp.compatible && cmp.healthDelta==15 && cmp.speedDeltaPct==8 && cmp.levelDelta==3 &&
          cmp.rarity==1,"passive item stat comparison");
    check(!eq.compareBackpackToSlot(chip,2).compatible,"invalid equipment slot comparison");
    check(!eq.compareBackpackToSlot(1000,3).compatible,"out-of-range compare safe");
    check(eq.equipAccessoryFromBackpack(chip,1),"equip chip");
    check(eq.speedBonusPercent()==8 && eq.bonusHealth()==15,"equipped bonus active");
    // Comparison doesn't mutate equipment and reflects actual delta on swap.
    const auto moved=locate("berserker_rune");
    auto passive=eq.compareBackpackToSlot(moved,3);
    check(passive.compatible && passive.speedDeltaPct==-8 && passive.damageDelta==7,
          "comparison vs currently equipped passive");
    check(eq.accessories[1]=="vitality_chip","stat preview read-only");
    check(eq.equipAccessoryFromBackpack(moved,1),"swap passive");
    check(eq.speedBonusPercent()==0 && eq.bonusDamage()==7,"bonuses update after swap");
    // Selection preview before equip: no mutation until second tap.
    Simulation preview;
    check(preview.combat.loadItems(v2,error),"preview catalog");
    preview.combat.enemies.clear();
    Input toggle;toggle.inventoryPressed=true;preview.tick(kFixedDt,toggle);
    size_t previewIndex=0;
    while(previewIndex<preview.combat.equipment.backpack.size() &&
          preview.combat.equipment.backpack[previewIndex]!="vitality_chip")++previewIndex;
    Input select;select.inventoryIndex=static_cast<int>(previewIndex);
    preview.tick(kFixedDt,select);
    check(preview.inventorySelectionArmed && preview.combat.equipment.accessories[1].empty(),
          "first tap previews instead of equipping");
    check(preview.combat.equipment.compareBackpackToSlot(previewIndex,3).speedDeltaPct==8,
          "preview computes positive movement bonus");
    preview.tick(kFixedDt,select);
    check(!preview.inventorySelectionArmed && preview.combat.equipment.accessories[1]=="vitality_chip",
          "second tap commits equip");
    // Save compatibility: no change to serialized FCSV v2 shape.
    Simulation saved;
    check(saved.combat.loadItems(v2,error),"simulation items loaded");
    auto& savedEquipment=saved.combat.equipment;
    size_t chipIndex=0;
    while(chipIndex<savedEquipment.backpack.size()&&savedEquipment.backpack[chipIndex]!="vitality_chip")++chipIndex;
    check(savedEquipment.equipAccessoryFromBackpack(chipIndex,1),"equip chip in simulation");
    const auto checkpoint=SaveCodec::encode(saved);
    Simulation restored;
    check(restored.combat.loadItems(v2,error) &&
          SaveCodec::decode(checkpoint,restored,error),"checkpoint round trip with v2 catalog");
    check(restored.combat.equipment.accessories[1]=="vitality_chip" &&
          restored.combat.equipment.speedBonusPercent()==8,"metadata reconstructed from external catalog");
    // Speed bonus is actually used by movement controller.
    Simulation normal,fast;
    check(fast.combat.loadItems(v2,error),"load catalog for speed test");
    auto& fe=fast.combat.equipment;
    size_t index=0;
    while(index<fe.backpack.size()&&fe.backpack[index]!="vitality_chip")++index;
    check(fe.equipAccessoryFromBackpack(index,1),"equip speed mod");
    normal.combat.enemies.clear();fast.combat.enemies.clear();
    normal.player.pos={120,294};fast.player.pos={120,294};
    normal.player.grounded=true;fast.player.grounded=true;
    Input right;right.move=1;
    for(int tick=0;tick<90;++tick){normal.tick(kFixedDt,right);fast.tick(kFixedDt,right);}
    check(fast.player.pos.x>normal.player.pos.x+9,"speed item changes actual movement speed");
    // Navigation should not choose a physically impassable short gap with a tall wall.
    World gap;gap.width=700;gap.solids={{0,294,235,66},{305,294,395,66}};gap.oneWay.clear();
    check(planPlatformHop(gap,{195,294},{350,294}).valid,"short gap initially traversable");
    gap.solids.push_back({250,140,30,154});
    check(!planPlatformHop(gap,{195,294},{350,294}).valid,"tall solid wall blocks gap traversal");
    gap.solids.back()={250,275,30,19};
    check(planPlatformHop(gap,{195,294},{350,294}).valid,"low obstacle can be vaulted");
    std::cout<<"ForgeCell ItemV2/Equipment/Navigation: ALL ASSERTIONS PASSED\n";
}
