#include "forge/Simulation.hpp"
#include "forge/VisualFormat.hpp"
#include "forge/EnemyFormat.hpp"
#include "forge/SaveSystem.hpp"
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <limits>
#include <span>
#include <string>
#include <vector>
using namespace forge;
static void ok(bool value,const char* why){if(!value){std::cerr<<"FAILED: "<<why<<"\n";std::exit(1);}}
static std::vector<std::byte> read(const std::string& path){
    std::ifstream f(path,std::ios::binary);
    const std::string s((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());
    return {std::as_bytes(std::span(s.data(),s.size())).begin(),
            std::as_bytes(std::span(s.data(),s.size())).end()};
}
static Combatant enemy(uint32_t id,float x=250){
    Combatant a;a.id=id;a.x=a.spawnX=a.previousX=x;
    a.y=a.previousY=294;a.health=a.maxHealth=90;return a;
}
int main(){
    EnemyActors actors;
    const EntityId first=actors.add(enemy(20));
    ok(first.generation!=0 && actors.get(first)!=nullptr && actors.handle(20)==first,
       "enemy owned by component pool and addressable by stable ID/handle");
    ok(!actors.add(enemy(20)).generation && actors.size()==1,
       "duplicate stable IDs rejected");
    ok(actors.erase(first) && !actors.get(first),"destroyed enemy not accessible");
    const EntityId reused=actors.add(enemy(30));
    ok(reused.index==first.index && reused.generation!=first.generation,
       "reused ECS entity index carries next generation");
    ok(!actors.get(first) && actors.get(reused),"stale handle cannot access reused slot");
    auto snapshot=actors;
    snapshot.front().health=5;
    ok(actors.front().health==90,"ECS copies are independent");
    std::vector<Combatant> valid={enemy(44),enemy(45)};
    ok(actors.replace(valid) && actors.size()==2 && !actors.get(reused),
       "atomic replacement invalidates previous ECS handles");
    auto bad=valid;bad.push_back(enemy(44));
    ok(!actors.replace(bad) && actors.size()==2 && actors.handle(44).generation,
       "duplicate rejected without losing active enemies");
    bad=valid;bad[1].x=std::numeric_limits<float>::infinity();
    ok(!actors.replace(bad) && actors.size()==2,"non-finite world position rejected atomically");
    actors.clear();
    for(uint32_t i=1;i<=EnemyActors::kMaxEnemies;++i)
        ok(actors.add(enemy(i)).generation,"ECS enemy capacity accepting valid actors");
    ok(!actors.add(enemy(200)).generation,"enemy capacity enforced");

    const std::string dir=FORGECELL_SOURCE_ROOT;
    const auto visuals=read(dir+"/android/app/src/main/assets/demo.fcva");
    std::string error;VisualCatalog atlas;
    ok(decodeVisualBinary(visuals,atlas,error),"compiled visual catalog parsed");
    ok(atlas.atlasWidth==1056 && atlas.atlasHeight==1200 &&
       atlas.get(0) && atlas.get(1) && atlas.get(5) && !atlas.get(7),
       "visual slots and texture dimensions authored in data");
    ok(atlas.get(3)->y==384 && atlas.get(5)->x==0,
       "archetype UV origins read from metadata, not hardcoded renderer values");
    auto corrupted=visuals;corrupted[0]=std::byte{'X'};
    ok(!decodeVisualBinary(corrupted,atlas,error) && atlas.get(5),
       "corrupt FCVA is rejected atomically");
    corrupted=visuals;corrupted.pop_back();
    ok(!decodeVisualBinary(corrupted,atlas,error),"truncated archetype rejected");
    corrupted=visuals;
    // Layout: header 12 bytes, each style 18; duplicate slot 0 in style 1.
    corrupted[30]=std::byte{0};corrupted[31]=std::byte{0};
    ok(!decodeVisualBinary(corrupted,atlas,error),"duplicate visual slot rejected");

    const auto profiles=read(dir+"/android/app/src/main/assets/demo.fcey");
    std::vector<Combatant> decoded;
    ok(decodeEnemyBinary(profiles,decoded,error) && decoded.size()==5,
       "FCEY v2 enemy profiles decoded");
    ok(decoded.front().visualIndex==2 && decoded[1].visualIndex==3 &&
       decoded[4].visualIndex==5,"FCEY v2 graphic archetype ID parsed");
    const auto legacy=read(dir+"/tests/fixtures/enemies_v1.fcey");
    ok(decodeEnemyBinary(legacy,decoded,error) && decoded[0].visualIndex==255,
       "backward-compatible FCEY v1 actor has role-based fallback");
    Simulation src;
    ok(src.combat.loadEnemies(profiles,src.world,error),"ECS accepts FCEY v2 catalog");
    const auto checkpoint=SaveCodec::encode(src);
    Simulation target;
    ok(target.combat.loadEnemies(profiles,target.world,error) &&
       SaveCodec::decode(checkpoint,target,error),"FCSV v2 loads after ECS migration");
    ok(target.combat.enemies.size()==5 && target.combat.enemies[4].visualIndex==5,
       "graphics archetypes preserved from level content after restoring progress");
    std::cout<<"ForgeCell Actors/Visuals: ALL ASSERTIONS PASSED\n";
}
