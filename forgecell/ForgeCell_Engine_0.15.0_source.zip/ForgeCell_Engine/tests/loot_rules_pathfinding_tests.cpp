#include "forge/Simulation.hpp"
#include "forge/Loot.hpp"
#include "forge/Navigation.hpp"
#include "forge/SaveSystem.hpp"
#include <algorithm>
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>
using namespace forge;
static std::vector<std::byte> asset(const char* filename) {
    std::ifstream in(std::filesystem::path(FORGECELL_SOURCE_ROOT)/
        "android/app/src/main/assets"/filename,std::ios::binary);
    assert(in);
    std::vector<char> bytes((std::istreambuf_iterator<char>(in)),{});
    std::vector<std::byte> result;
    for(unsigned char b:bytes)result.push_back(std::byte(b));
    return result;
}
static Combatant heavy(uint32_t id) {
    Combatant e; e.id=id;e.role=EnemyRole::Heavy;e.health=e.maxHealth=12;
    e.x=e.previousX=e.spawnX=225;e.y=e.previousY=294;
    e.lootId="vitality_chip";
    return e;
}
static void killEnemy(Simulation& game) {
    game.player.pos={200,294};game.player.prevPos=game.player.pos;
    game.player.facingRight=true;game.player.grounded=true;
    game.combat.tick(kFixedDt,game.player,game.world,true,false);
    for(int i=0;i<25;++i)game.combat.tick(kFixedDt,game.player,game.world,false,false);
    assert(!game.combat.enemies.front().alive);
}
int main() {
    auto source=asset("demo.fclt");
    LootTable table;
    std::string error;
    assert(table.load(source,error));
    assert(table.seed==8027238498251188577ULL);
    assert(table.roll(451,2)==table.roll(451,2));
    const auto r=table.roll(451,2);assert(r.has_value());
    const auto nonzero=unsigned(r->health>0)+unsigned(r->damage>0)+
        unsigned(r->defense>0)+unsigned(r->speedPct>0)+unsigned(r->healing>0);
    assert(nonzero==2); // Heavy roll = two distinct stat modifiers
    assert(!table.roll(0,2) && !table.roll(1,8));
    for(uint32_t id=1;id<2000;++id) {
        auto item=table.roll(id,4);
        assert(item.has_value());
        assert(item->health<=100 && item->damage<=100 && item->speedPct<=100);
    }
    auto bad=source;
    bad[16]=std::byte{5}; // role out of range
    assert(!table.load(bad,error) && table.seed==8027238498251188577ULL);
    bad=source;bad[17]=std::byte{255};
    assert(!table.load(bad,error) && table.roll(451,2)==r);
    bad=source;bad[24]=std::byte{0}; // duplicate role 0
    assert(!table.load(bad,error));
    bad=source;bad.pop_back();
    assert(!table.load(bad,error));
    bad=source;bad[20]=std::byte{101}; // min > 100
    assert(!table.load(bad,error));

    Simulation killed;
    assert(killed.combat.loadItems(asset("demo.fcit"),error));
    assert(killed.combat.loadLoot(source,error));
    killed.combat.enemies={heavy(451)};
    killEnemy(killed);
    assert(killed.combat.transients.pickups().size()==1);
    const auto& loot=killed.combat.transients.pickups().front().value;
    const std::string token=loot.weaponId;
    assert(token.starts_with("~") && killed.combat.equipment.instance(token));
    assert(killed.combat.equipment.bonuses(token).health==r->health);
    assert(killed.combat.equipment.bonuses(token).damage==r->damage);
    const auto save=SaveCodec::encode(killed);
    Simulation restored;
    assert(restored.combat.loadItems(asset("demo.fcit"),error));
    restored.combat.enemies={heavy(451)};
    if(!SaveCodec::decode(save,restored,error)) {std::cerr<<error<<'\n';return 1;}
    assert(restored.combat.transients.pickups().size()==1);
    assert(restored.combat.transients.pickups().front().value.weaponId==token);
    assert(restored.combat.collectNearby(restored.player));
    assert(restored.combat.equipment.instance(token));
    // A collected pickup is a tombstone; don't double-count its instance UID.
    const auto ownedSave=SaveCodec::encode(restored);
    Simulation reloaded;
    assert(reloaded.combat.loadItems(asset("demo.fcit"),error));
    reloaded.combat.enemies={heavy(451)};
    if(!SaveCodec::decode(ownedSave,reloaded,error)) {std::cerr<<error<<'\n';return 1;}
    assert(reloaded.combat.equipment.instance(token));
    bool inBag=false;
    for(const auto& entry:reloaded.combat.equipment.backpack)inBag|=entry==token;
    assert(inBag && !reloaded.combat.collectNearby(reloaded.player));

    Simulation capacity;
    assert(capacity.combat.loadItems(asset("demo.fcit"),error));
    capacity.combat.enemies={heavy(451)};
    for(uint32_t n=1;n<=TransientEntities::kMaxPickups;++n)
        assert(capacity.combat.transients.addPickup({n+1000,"pistol",100,280,false}).generation);
    killEnemy(capacity);
    assert(capacity.combat.equipment.instances().empty());
    assert(capacity.combat.transients.pickups().size()==TransientEntities::kMaxPickups);

    World alternatives;
    alternatives.width=900;alternatives.height=360;alternatives.oneWay={};
    alternatives.solids={{0,294,100,66},{100,228,130,14},{150,294,50,66},{255,294,125,66}};
    auto chosen=planPlatformHop(alternatives,{80,294},{300,294});
    assert(chosen.valid && chosen.transition && chosen.landingY==294);
    std::cout << "ForgeCell loot rules / path scoring: ALL ASSERTIONS PASSED\n";
}
