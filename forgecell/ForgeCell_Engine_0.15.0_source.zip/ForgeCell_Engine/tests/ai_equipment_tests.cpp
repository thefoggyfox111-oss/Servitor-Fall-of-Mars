#include "forge/Simulation.hpp"
#include "forge/TouchControls.hpp"
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <span>
#include <string>
using namespace forge;
static void expect(bool ok,const char* message) {
    if(!ok){std::cerr<<"FAILED: "<<message<<'\n';std::exit(1);}
}
static World arena() {
    World w;w.width=900;w.height=360;w.solids={{0,294,900,66}};w.oneWay.clear();return w;
}
static Player standing() {
    Player p;p.pos={200,294};p.prevPos=p.pos;p.grounded=true;return p;
}
static Combatant enemy(uint32_t id,float x,EnemyRole role) {
    Combatant e;e.id=id;e.x=e.previousX=e.spawnX=x;e.role=role;
    return e;
}
int main() {
    // Configured weapons + backpack swap; all IDs are stable strings.
    CombatSystem combat;combat.resetDemo();
    expect(combat.equipment.backpack.size()==24,"24 backpack slots available");
    expect(combat.equipment.slot(0)->id=="rusted_sword","melee default equipped");
    expect(combat.equipment.slot(1)->id=="pistol","ranged default equipped");
    expect(combat.cycleWeapon(0),"swap sword for axe in slot 0");
    expect(combat.equipment.slot(0)->id=="heavy_axe" && combat.melee.damage==48,
           "axe stats wired into combat");
    expect(combat.equipment.backpack[0]=="rusted_sword","unequipped item retained");
    expect(combat.cycleWeapon(1),"swap pistol for rifle in slot 1");
    expect(combat.equipment.slot(1)->id=="rifle" && combat.magazineRemaining()==24,
           "rifle magazine and class loaded");
    expect(!combat.equipFromBackpack(0,1),"cannot equip sword in ranged slot");
    expect(!combat.equipFromBackpack(100,0),"invalid inventory index rejected");
    expect(combat.cycleWeapon(0),"melee can be swapped back");
    expect(combat.equipment.slot(0)->id=="rusted_sword","old sword is still available");

    std::string error;
    const std::string filename=std::string(FORGECELL_SOURCE_ROOT)+
       "/android/app/src/main/assets/demo.fcwp";
    std::ifstream file(filename,std::ios::binary);
    expect(file.good(),"compiled FCWP exists");
    const std::string contents((std::istreambuf_iterator<char>(file)),{});
    Equipment imported;
    imported.equipped={"heavy_axe","rifle"};
    auto bytes=std::as_bytes(std::span(contents.data(),contents.size()));
    expect(loadWeaponBinary(bytes,imported,error),"compiled weapon config loads");
    expect(imported.definitions.size()==4 && imported.slot(1)->name=="Pistol",
           "external weapon metadata accessible");
    std::string corrupt=contents;
    corrupt[0]='X';
    expect(!loadWeaponBinary(std::as_bytes(std::span(corrupt.data(),corrupt.size())),imported,error),
           "reject invalid weapon signature");
    expect(imported.definitions.size()==4 && imported.slot(0)->id=="rusted_sword",
           "failed import is atomic");
    corrupt=contents.substr(0,contents.size()-3);
    expect(!loadWeaponBinary(std::as_bytes(std::span(corrupt.data(),corrupt.size())),imported,error),
           "reject truncated weapon entry");
    corrupt=contents+std::string("JUNK");
    expect(!loadWeaponBinary(std::as_bytes(std::span(corrupt.data(),corrupt.size())),imported,error),
           "reject trailing data");
    expect(combat.loadEquipment(bytes,error),"live combat reloads weapon database");
    expect(combat.equipment.slot(0)->id=="rusted_sword" && combat.melee.damage==30,
           "loaded attack values applied");
    expect(combat.equipFromBackpack(0,0),"equip axe from file");
    expect(combat.melee.startup>.2f,"axe has longer startup than sword");
    Player p=standing();
    combat.enemies={enemy(5,228,EnemyRole::Dummy)};
    combat.tick(kFixedDt,p,arena(),true,false);
    for(int i=0;i<16;++i)combat.tick(kFixedDt,p,arena(),false,false);
    expect(combat.enemies.front().health==52,"damage uses equipped axe definition");
    expect(!combat.cycleWeapon(0),"cannot replace melee weapon during attack");
    for(int i=0;i<40;++i)combat.tick(kFixedDt,p,arena(),false,false);
    expect(combat.cycleWeapon(0),"can replace weapon after recovery");

    // Reload waits for a full configured duration and refills only from reserve.
    CombatSystem reloadTest;
    reloadTest.resetDemo();
    reloadTest.enemies.clear();
    expect(reloadTest.cycleWeapon(1),"rifle equipped for reload test");
    reloadTest.setAmmo(30);
    Player reloadPlayer=standing();
    for(int shot=0;shot<24;++shot) {
        reloadTest.tick(kFixedDt,reloadPlayer,arena(),false,true);
        for(int wait=0;wait<7;++wait)reloadTest.tick(kFixedDt,reloadPlayer,arena(),false,false);
    }
    expect(reloadTest.shotsFired()==24 && reloadTest.magazineRemaining()==0 &&
           reloadTest.ammo()==6,"rifle magazine depleted with reserve left");
    reloadTest.tick(kFixedDt,reloadPlayer,arena(),false,true);
    expect(reloadTest.reloading(),"dry trigger starts reload from reserve");
    for(int wait=0;wait<60;++wait)reloadTest.tick(kFixedDt,reloadPlayer,arena(),false,false);
    expect(reloadTest.magazineRemaining()==0,"magazine stays empty during reload");
    for(int wait=0;wait<46;++wait)reloadTest.tick(kFixedDt,reloadPlayer,arena(),false,false);
    expect(!reloadTest.reloading() && reloadTest.magazineRemaining()==6 &&
           reloadTest.reloadEvents==1,"reload refills only remaining ammunition");

    // Hostile grunt: telegraph, committed active window, player damage, recovery.
    CombatSystem grunt;
    grunt.enemies={enemy(21,224,EnemyRole::Grunt)};
    p=standing();
    for(int i=0;i<12;++i)grunt.tick(kFixedDt,p,arena(),false,false);
    expect(grunt.enemies.front().state==EnemyState::Windup,"grunt telegraphs before hit");
    expect(p.health==100,"no damage in startup frames");
    for(int i=0;i<15;++i)grunt.tick(kFixedDt,p,arena(),false,false);
    expect(p.health==91 && grunt.playerDamageEvents==1,"grunt does 9 damage once in active window");
    for(int i=0;i<15;++i)grunt.tick(kFixedDt,p,arena(),false,false);
    expect(p.health==91 && grunt.enemyAttackEvents==1,"same attack cannot hit again");

    // Invulnerability is independent of animation and prevents damage.
    CombatSystem invulnerable;
    invulnerable.enemies={enemy(22,224,EnemyRole::Heavy)};
    p=standing();p.invulnerable=true;
    for(int i=0;i<55;++i)invulnerable.tick(kFixedDt,p,arena(),false,false);
    expect(invulnerable.enemyAttackEvents>=1 && p.health==100,
           "roll invulnerability protects from heavy telegraphed strike");

    // Ranged AI fires hostile projectiles, swept against player hurtbox.
    CombatSystem gunner;
    gunner.enemies={enemy(23,347,EnemyRole::Gunner)};
    p=standing();
    for(int i=0;i<95;++i)gunner.tick(kFixedDt,p,arena(),false,false);
    expect(gunner.enemyAttackEvents>0,"gunner eventually shoots");
    expect(p.health<=90,"hostile bullet damages player");
    // Thin solid wall must occlude the exact same bullet path.
    World w=arena();w.solids.push_back({274,246,2,47});
    CombatSystem covered;
    covered.enemies={enemy(24,347,EnemyRole::Gunner)};
    p=standing();
    for(int i=0;i<95;++i)covered.tick(kFixedDt,p,w,false,false);
    expect(covered.enemyAttackEvents>0 && p.health==100,
           "thin wall blocks enemy bullets even with swept collision");

    // Patrol/chase must not walk unsupported into a gap.
    World gap=arena();gap.solids={{0,294,245,66},{410,294,490,66}};
    CombatSystem cliff;
    cliff.enemies={enemy(25,220,EnemyRole::Grunt)};
    p=standing();p.pos.x=365;
    for(int i=0;i<130;++i)cliff.tick(kFixedDt,p,gap,false,false);
    expect(cliff.enemies.front().x<=240,"enemy cannot chase off ledge");

    TouchControls touch;touch.resize(640,360);
    touch.pointerDown(10,470,45);touch.pointerDown(11,550,45);
    touch.pointerDown(12,130,290);
    auto input=touch.sample();
    expect(input.swapMeleePressed && input.swapRangedPressed && input.move>0,
           "two equipment keys and movement coexist via multitouch");
    expect(!touch.sample().swapMeleePressed && !touch.sample().swapRangedPressed,
           "equipment key edges consumed only once");
    std::cout<<"ForgeCell AI/Equipment: ALL ASSERTIONS PASSED\n";
}
