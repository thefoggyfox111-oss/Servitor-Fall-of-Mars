#include "forge/Simulation.hpp"
#include "forge/SaveSystem.hpp"
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace forge;
static void check(bool good, const char* description) {
    if(!good) {std::cerr<<"FAILED: "<<description<<'\n';std::exit(1);}
}
int main() {
    TransientEntities ecs;
    const auto a=ecs.addProjectile({1,80,270,80,270,600,0,2,2,15,false});
    check(a.generation!=0 && ecs.projectile(a)!=nullptr && ecs.pickup(a)==nullptr,
          "typed projectile handle resolves only correct component");
    check(ecs.removeProjectile(a) && !ecs.projectile(a),"removal invalidates old handle");
    const auto reused=ecs.addPickup({8,"heavy_axe",200,280,false});
    check(reused.generation && reused.index==a.index && reused.generation!=a.generation,
          "cross-type allocation reuses index but advances generation");
    check(!ecs.projectile(a) && !ecs.pickup(a) && ecs.pickup(reused),
          "stale ECS handle cannot access new pickup");
    check(!ecs.addPickup({8,"rifle",240,280,false}).generation,"duplicate saved pickup ID rejected");
    TransientEntities copy=ecs;
    check(copy.pickups().size()==1 && copy.removePickup(copy.pickups().front().entity),
          "copy owns independent registry and components");
    check(ecs.pickups().size()==1 && ecs.pickup(reused),"copy mutation cannot affect original");
    const auto surviving=ecs.pickups().front().entity;
    ecs.clear();
    check(!ecs.pickup(surviving),"clear invalidates generation-checked handles");
    for(uint32_t i=1;i<=TransientEntities::kMaxProjectiles;++i)
        check(ecs.addProjectile({i,80,270,80,270,10,0,2,2,15,false}).generation,
              "accepted projectile below entity cap");
    check(!ecs.addProjectile({9999,80,270,80,270,10,0,2,2,15,false}).generation,
          "projectile entity limit enforced");
    ecs.mutableProjectiles().front().value.life=0;
    const auto expired=ecs.projectiles().front().entity;
    ecs.removeExpiredProjectiles();
    check(ecs.projectiles().size()==TransientEntities::kMaxProjectiles-1 &&
          !ecs.projectile(expired),"expired projectile removed from packed component pool");
    ecs.clear();
    // A saturated projectile pool must not charge ammo for an unspawned shot.
    CombatSystem saturated;
    saturated.enemies.clear();
    for(uint32_t i=1;i<=TransientEntities::kMaxProjectiles;++i)
        check(saturated.transients.addProjectile({i,60,120,60,120,1,0,5,2,10,false}).generation,
              "prepare saturation test");
    Player activePlayer;activePlayer.pos={130,294};
    const int ammunition=saturated.ammo();
    saturated.tick(kFixedDt,activePlayer,World{},false,true);
    check(saturated.ammo()==ammunition && saturated.shotsFired()==0,
          "failed projectile allocation cannot consume ammunition");
    std::vector<Pickup> replace={{31,"rifle",220,276,false},{32,"heavy_axe",240,278,true}};
    check(ecs.replacePickups(replace) && ecs.pickups().size()==2,
          "restore pickups into ECS");
    auto duplicate=replace;duplicate.back().id=31;
    check(!ecs.replacePickups(duplicate) && ecs.pickups().size()==2,
          "failed replacement retains previous ECS state");

    Simulation sim;
    sim.combat.enemies.clear();
    sim.objects.clear();
    check(sim.objects.add({101,WorldObjectKind::Crate,230,294,14,14,26}).generation,
          "register shooting target");
    sim.player.pos={130,294};sim.player.prevPos=sim.player.pos;sim.player.facingRight=true;
    sim.combat.tick(.20f,sim.player,sim.world,false,true,&sim.objects);
    check(sim.objects.entries().front().value.health==0 &&
          sim.combat.transients.projectiles().empty(),
          "swept projectile damages crate and despawns on impact");
    sim.combat.resetDemo();sim.combat.enemies.clear();
    sim.objects.clear();
    sim.objects.add({101,WorldObjectKind::Crate,230,294,14,14,26});
    sim.world.solids.push_back({187,260,2,34});
    sim.combat.tick(.20f,sim.player,sim.world,false,true,&sim.objects);
    check(sim.objects.entries().front().value.health==14,
          "solid wall blocks projectile before destructible crate");

    Simulation saved;
    saved.combat.transients.addPickup({102,"rifle",234,280,false});
    saved.combat.transients.addPickup({103,"heavy_axe",330,279,true});
    const auto blob=SaveCodec::encode(saved);
    Simulation loaded;
    std::string err;
    check(SaveCodec::decode(blob,loaded,err),"save/load unchanged FCSV v2 format");
    check(loaded.combat.transients.pickups().size()==2 &&
          loaded.combat.pickupsCollected==1 && loaded.combat.transients.projectiles().empty(),
          "ECS loot saved and active projectiles deliberately discarded");
    check(loaded.combat.transients.pickups()[0].value.id==102 &&
          loaded.combat.transients.pickups()[1].value.collected,
          "stable pickup identifiers and collection flags survive save/load");
    std::cout<<"ForgeCell Transient ECS: ALL ASSERTIONS PASSED\n";
}
