#include "forge/Simulation.hpp"
#include "forge/EntityRegistry.hpp"
#include "forge/Effects.hpp"
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <span>
#include <string>
#include <vector>
#include <unordered_set>
using namespace forge;
static void expect(bool ok, const char* message) {
    if(!ok){std::cerr<<"FAILED: "<<message<<'\n';std::exit(1);}
}
static std::vector<std::byte> file(const std::string& name) {
    std::ifstream stream(std::string(FORGECELL_SOURCE_ROOT)+"/android/app/src/main/assets/"+name,
                         std::ios::binary);
    expect(stream.good(),"test asset exists");
    std::string bytes((std::istreambuf_iterator<char>(stream)),{});
    std::vector<std::byte> result;
    result.reserve(bytes.size());
    for(unsigned char c:bytes)result.push_back(static_cast<std::byte>(c));
    return result;
}
int main() {
    EntityRegistry entities;
    ComponentPool<int> components(&entities);
    std::vector<EntityId> ids;
    for(int n=0;n<1000;++n) {
        auto entity=entities.create();
        expect(components.set(entity,n),"attach packed component");
        ids.push_back(entity);
    }
    expect(entities.size()==1000 && components.size()==1000,"many ECS actors allocated");
    for(int n=0;n<1000;n+=2) {
        expect(components.remove(ids[n]),"O(1) swap-remove component");
        expect(entities.destroy(ids[n]),"delete ECS entity");
    }
    expect(components.size()==500 && entities.size()==500,"dense array compacted");
    for(int n=1;n<1000;n+=2)
        expect(components.get(ids[n]) && *components.get(ids[n])==n,"swap-delete preserved surviving ID");
    for(int n=0;n<1000;n+=2)
        expect(!components.get(ids[n]),"deleted ID absent");
    auto reused=entities.create();
    expect(reused.index!=UINT32_MAX && !components.get(ids[reused.index]),
           "stale generation rejected after reuse");
    expect(components.set(reused,42),"new recycled entity accepts component");
    expect(!components.set(ids[reused.index],7),"stale ID cannot mutate newer component");
    expect(components.get(reused) && *components.get(reused)==42,"new generation retained");
    expect(!entities.destroy(ids[reused.index]),"stale ID cannot destroy recycled entity");

    EffectSystem effects;
    EntityId handle=effects.emit(10,20,EffectKind::Hit);
    expect(effects.get(handle) && effects.get(handle)->duration>.15f,"runtime ECS effect created");
    expect(!effects.remove({handle.index,handle.generation+1}),"cannot remove effect via invalid generation");
    effects.tick(.21f);
    expect(effects.size()==0 && !effects.get(handle),"effect lifetime cleanup");
    auto second=effects.emit(20,30,EffectKind::Shot);
    expect(second.index==handle.index && second.generation!=handle.generation,
           "VFX reuses entity slot safely");
    expect(!effects.get(handle) && effects.get(second),"old VFX handle stays invalid");
    effects.clear();
    expect(!effects.get(second),"clear invalidates old runtime handles");
    auto afterClear=effects.emit(22,44,EffectKind::Hit);
    expect(!effects.get(second) && afterClear.generation!=second.generation,
           "clear does not revalidate previous VFX ID");
    effects.clear();
    for(size_t i=0;i<EffectSystem::kMaxEffects;++i)
        expect(effects.emit(float(i),0,EffectKind::Death).generation!=0,"VFX capacity fill");
    expect(effects.emit(1000,0,EffectKind::Hit).generation==0,"VFX capped at 256");
    expect(effects.emit(NAN,0,EffectKind::Hit).generation==0,"invalid effect rejected");
    effects.tick(1.0f);
    expect(effects.size()==0,"batch expiry leaves no effects");

    // Actors each own an independent animation FSM, loaded from validated FCAN files.
    CombatSystem c;c.resetDemo();
    std::string error;
    const auto grunt=file("enemy_grunt.fcan"), heavy=file("enemy_heavy.fcan");
    expect(c.loadEnemyAnimation(EnemyRole::Grunt,grunt,error),"grunt animation profile loads");
    expect(c.loadEnemyAnimation(EnemyRole::Heavy,heavy,error),"heavy animation profile loads");
    Combatant* g=nullptr;Combatant* h=nullptr;
    for(auto& e:c.enemies) {
        if(e.role==EnemyRole::Grunt && !g)g=&e;
        if(e.role==EnemyRole::Heavy)h=&e;
    }
    expect(g && h,"enemy archetypes available");
    g->animator.change(Animation::Run);
    h->animator.change(Animation::Run);
    g->animator.tick(.039f);
    h->animator.tick(.039f);
    expect(g->animator.frame==0 && h->animator.frame==0,"run animation starts on first frame");
    g->animator.tick(.022f);
    h->animator.tick(.022f);
    expect(g->animator.frame==1 && h->animator.frame==0,
           "per-type animation timings differ independently of render FPS");
    const int current=h->animator.frame;
    auto corrupted=heavy;corrupted[0]=std::byte{'X'};
    expect(!c.loadEnemyAnimation(EnemyRole::Heavy,corrupted,error),"corrupt profile rejected");
    expect(h->animator.frame==current,"failed asset reload preserves running animation");
    expect(g->animator.currentFrame()->anchors.size()==static_cast<size_t>(AnchorId::Count),
           "role-specific anchors retained");
    // Sprite sheet header includes 6 actor-specific animation groups, not just tints.
    const auto atlas=file("atlas.rgba");
    expect(atlas.size()==8+1056*1200*4,"atlas dimensions and byte count validated");
    expect(atlas[0]==std::byte{'F'} && atlas[1]==std::byte{'C'} &&
           atlas[2]==std::byte{'A'} && atlas[3]==std::byte{'T'},"FCAT signature");
    constexpr int atlasW=1056;
    constexpr int slots[6][2]={{0,0},{1,2},{1,0},{0,1},{1,1},{0,2}};
    // Verify actual sprite pixels: each actor/track supplies 16 distinct frames.
    for(const auto& actor:slots)for(int row=0;row<8;++row) {
        std::unordered_set<uint64_t> unique;
        for(int frame=0;frame<16;++frame) {
            uint64_t hash=14695981039346656037ull;
            for(int y=0;y<48;++y)for(int x=0;x<32*4;++x) {
                const size_t offset=8+size_t((actor[1]*384+row*48+y)*atlasW+actor[0]*512+frame*32)*4+x;
                hash=(hash ^ std::to_integer<uint8_t>(atlas[offset]))*1099511628211ull;
            }
            unique.insert(hash);
        }
        expect(unique.size()==16,"all six actors have sixteen distinct frames in every track");
    }

    // Hit feedback is produced by gameplay, then consumed by independent ECS VFX.
    Simulation scene;
    for(int i=0;i<80;++i)scene.tick(kFixedDt,{});
    scene.combat.enemies.clear();
    Combatant dummy;
    dummy.id=101;dummy.role=EnemyRole::Dummy;
    dummy.x=dummy.previousX=dummy.spawnX=scene.player.pos.x+25;
    dummy.y=dummy.previousY=294;
    scene.combat.enemies.push_back(dummy);
    Input attack;attack.attackPressed=true;
    scene.tick(kFixedDt,attack);
    for(int i=0;i<12;++i)scene.tick(kFixedDt,{});
    expect(scene.combat.damageEvents==1,"one melee attack only strikes once");
    expect(scene.effects.size()>0,"ECS visual feedback receives combat events");
    for(int i=0;i<70;++i)scene.tick(kFixedDt,{});
    expect(scene.effects.size()==0,"ECS visual feedback expires automatically");
    std::cout<<"ForgeCell ECS/Animation/VFX: ALL ASSERTIONS PASSED\n";
}
