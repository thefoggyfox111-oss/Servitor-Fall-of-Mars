#include "forge/Navigation.hpp"
#include "forge/Combat.hpp"
#include "forge/TouchControls.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
using namespace forge;

static void testSupportedTakeoff() {
    World world;
    world.width=620;world.height=360;
    // Target hangs over the left edge of the supporting platform.
    // Taking off on its left side means stepping into empty space.
    world.solids={{100,294,250,66},{100,230,70,16}};
    world.oneWay.clear();
    const auto hop=planPlatformHop(world,{108,294},{140,230});
    assert(hop.valid && hop.transition);
    assert(hop.takeoffX>=108 && hop.takeoffX<=342);
    assert(std::abs(hop.takeoffX-182.f)<0.001f);
    assert(std::abs(hop.landingX-156.f)<0.001f);
    // A platform covering the entire floor has neither supported side launch.
    world.solids[1]={100,230,250,16};
    assert(!planPlatformHop(world,{120,294},{230,230}).valid);
}
static void testAirborneLanding() {
    World world;
    world.width=620;world.height=360;
    world.solids={{100,294,250,66},{100,230,70,16}};
    world.oneWay.clear();
    Combatant e;
    e.id=99;e.role=EnemyRole::Dummy;
    e.x=e.previousX=e.spawnX=182;
    e.y=e.previousY=e.spawnY=294;
    e.airborne=true;e.vy=-355;e.navTargetX=156;e.navTargetY=230;
    CombatSystem combat; combat.enemies={e};
    Player player; player.health=0;player.pos={400,294};
    for(int frame=0;frame<80;++frame)combat.tick(kFixedDt,player,world,false,false);
    const auto& reached=combat.enemies.front();
    assert(!reached.airborne);
    assert(std::abs(reached.y-230.f)<0.01f);
    assert(reached.x>=110.f && reached.x<=170.f);
}
static void testInventoryDragPreview() {
    TouchControls touch;
    touch.resize(640,360);touch.setInventoryOpen(true);
    const float fromX=320-114+3*38+12,fromY=79+15;
    const float targetX=320+135+10,targetY=79+27*2+11;
    touch.pointerDown(3,fromX,fromY);
    assert(!touch.inventoryDrag());
    touch.pointerMove(3,targetX,targetY);
    const auto drag=touch.inventoryDrag();
    assert(drag && drag->fromCell==3 && drag->toSlot==2 && drag->toCell==-1);
    auto pending=touch.sample();
    assert(pending.inventoryMoveFrom==-1 && pending.inventoryEquipSlot==-1);
    touch.pointerUp(3,targetX,targetY);
    assert(!touch.inventoryDrag());
    pending=touch.sample();
    assert(pending.inventoryMoveFrom==3 && pending.inventoryEquipSlot==2);
    assert(touch.sample().inventoryMoveFrom==-1);
    // Cancelling Android touch input removes both preview and queued operations.
    touch.pointerDown(9,fromX,fromY);
    touch.pointerMove(9,targetX,targetY);
    touch.clear();
    assert(!touch.inventoryDrag() && touch.sample().inventoryMoveFrom==-1);
}
int main(){
    testSupportedTakeoff();testAirborneLanding();testInventoryDragPreview();
    std::cout<<"Navigation / inventory drag regression: PASS\n";
}
