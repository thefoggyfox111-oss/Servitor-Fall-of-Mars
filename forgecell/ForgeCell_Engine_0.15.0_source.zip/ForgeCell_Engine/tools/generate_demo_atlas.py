#!/usr/bin/env python3
"""Generate deterministic placeholder atlas for 6 visually distinct actor roles.

Each actor has eight clips of 16 different poses in 32x48 pixel cells.
Replace with authored original sprite artwork for production.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import math

WIDTH, HEIGHT = 1056, 1200
FRAME_W, FRAME_H = 32, 48

def draw_frame(target, row, frame):
    # Distinct poses for all 16 frames in every animation track.
    img=Image.new('RGBA',(FRAME_W,FRAME_H))
    d=ImageDraw.Draw(img)
    angle=frame/16*math.tau
    bob=round(1.2*math.sin(angle))
    running=(row==1)
    jumping=(row==2)
    falling=(row==3)
    landing=(row==4)
    rolling=(row==5)
    attacking=(row==6)
    shooting=(row==7)
    stride=(math.sin(angle)*(7 if running else 2))
    swordX=round(15+11*math.sin(angle/2)) if attacking else 26
    bodyY=3 if jumping else (7 if rolling else (9 if landing else 6))
    legY=34 if rolling else 35+bob
    # Scarf and jacket trailing to the left with run cycles.
    cloth=(65,29,31,255)
    capeX=3+(-2 if running else 0)+round(1.3*math.sin(angle+0.4))
    d.polygon([(capeX,bodyY+15),(15,bodyY+13),(17,bodyY+35),(capeX-1,bodyY+32)],fill=cloth)
    d.line([(capeX,bodyY+20),(capeX-2,bodyY+26)],fill=(144,43,41,255),width=2)
    # Exo-legs, with actual articulating strides.
    l1x=12+round(stride)
    l2x=21-round(stride)
    if jumping: l1x-=3; l2x+=3;legY-=4
    if falling: l1x+=2; l2x-=2
    d.line([(13,bodyY+28),(l1x,legY)],fill=(81,98,99,255),width=5)
    d.line([(20,bodyY+28),(l2x,legY)],fill=(73,90,92,255),width=5)
    d.rectangle([l1x-4,legY-1,l1x+2,legY+3],fill=(30,43,49,255))
    d.rectangle([l2x-3,legY-1,l2x+4,legY+3],fill=(30,43,49,255))
    # Main armour and chest with straps.
    d.polygon([(12,bodyY+12),(23,bodyY+11),(26,bodyY+25),(22,bodyY+31),(10,bodyY+30),(9,bodyY+20)],fill=(58,80,89,255))
    d.rectangle([13,bodyY+16,19,bodyY+28],fill=(105,118,109,255))
    d.line([(10,bodyY+14),(24,bodyY+26)],fill=(176,121,68,255),width=2)
    d.rectangle([14,bodyY+20,18,bodyY+22],fill=(26,174,129,255))
    # Mechanical arm with one frame per motion beat.
    armY=bodyY+(21 if rolling else 16)
    armEndX=26 + (round(math.sin(angle)*4) if running else 0)
    armEndY=armY + (round(math.sin(angle)*6) if attacking else round(math.cos(angle)*3))
    d.line([(22,bodyY+16),(armEndX,armEndY)],fill=(105,117,121,255),width=5)
    d.ellipse([armEndX-3,armEndY-3,armEndX+3,armEndY+3],fill=(160,168,163,255))
    # Mechanical sword arc: attack track extends arm and sword forward.
    if shooting:
        recoil=2 if frame in (1,2,3,4) else (1 if frame in (5,6,7,8) else 0)
        d.rectangle([armEndX-2-recoil,armEndY-4,armEndX+8-recoil,armEndY],
                    fill=(142,155,162,255))
        d.rectangle([armEndX+7-recoil,armEndY-3,armEndX+13-recoil,armEndY-2],
                    fill=(206,185,132,255))
        if frame in (3,4):
            d.polygon([(armEndX+13-recoil,armEndY-3),
                       (armEndX+17-recoil,armEndY-7),
                       (armEndX+19-recoil,armEndY-2)],fill=(255,218,116,255))
    elif attacking:
        swordY=armEndY-round(math.cos(angle/2)*14)
        d.line([(armEndX,armEndY),(swordX,swordY)],fill=(179,209,197,255),width=3)
        d.line([(swordX,swordY),(swordX+2,swordY-4)],fill=(229,233,215,255),width=2)
    else:
        d.line([(armEndX,armEndY),(armEndX+3,armEndY-7)],fill=(171,196,182,255),width=2)
    # Helm, glowing eye and aerial cable.
    headY=bodyY+(2 if rolling else 0)
    d.ellipse([11,headY+3,23,headY+17],fill=(67,76,84,255))
    d.polygon([(10,headY+7),(23,headY+6),(24,headY+12),(12,headY+15)],fill=(130,139,139,255))
    d.rectangle([18,headY+9,22,headY+11],fill=(46,241,197,255))
    d.line([(14,headY+3),(13,headY-1),(18,headY-2)],fill=(116,100,91,255),width=2)
    if row==0:
        # Idle breathing: 16 different micro-poses.
        d.line([(8,bodyY+19),(9+round(math.sin(angle)*2),bodyY+25)],fill=(194,96,68,255),width=2)
    target.paste(img,(frame*FRAME_W,row*FRAME_H),img)

# Slots: hero at (0,0); enemies occupy their own 8x16 sheets.
ACTOR_SLOTS = {"dummy": (1,2), "grunt":(1,0), "heavy":(0,1),
               "gunner":(1,1), "boss":(0,2)}

def draw_enemy_frame(atlas, role, row, frame):
    """Distinct 32x48 silhouettes and 16 non-duplicate action frames per role."""
    img=Image.new('RGBA',(FRAME_W, FRAME_H))
    d=ImageDraw.Draw(img)
    a=frame*math.tau/16
    stride=math.sin(a)* (6 if row==1 else 2)
    pulse=round(math.sin(a)*2)
    attack=row in (6,7)
    roll=row==5
    crouch=8 if roll else 0
    jump=-4 if row==2 else (2 if row==4 else 0)
    palette={
        'dummy':((111,99,73,255),(68,76,68,255),(226,166,89,255)),
        'grunt':((117,69,72,255),(69,56,69,255),(222,90,73,255)),
        'heavy':((82,93,98,255),(42,60,77,255),(255,146,65,255)),
        'gunner':((84,109,91,255),(43,58,57,255),(114,231,150,255)),
        'boss':((121,66,109,255),(66,41,73,255),(244,75,204,255)),
    }
    armor,shadow,accent=palette[role]
    neck=9+jump+crouch
    lx=11+round(stride);rx=21-round(stride)
    if roll:lx=10+round(3*math.sin(a));rx=23-round(3*math.sin(a))
    if row==2:lx-=3;rx+=3
    if row==3:lx+=2;rx-=2
    knee=33+crouch+jump+round(0.8*math.cos(a))
    for hip,foot in ((13,lx),(20,rx)):
        d.line([(hip,neck+21),(foot,knee)],fill=armor,width=5 if role!='heavy' else 6)
        d.rectangle((foot-4,knee-1,foot+3,knee+3),fill=shadow)
    if role=='dummy':
        d.rectangle((11,neck+8,22,neck+24),fill=armor)
        d.line([(16,neck+4),(16,neck+26)],fill=accent,width=2)
        d.line([(7,neck+18),(26,neck+18)],fill=shadow,width=4)
        d.ellipse((12,neck-1,21,neck+10),fill=shadow)
        d.rectangle((14,neck+2,19,neck+6),fill=accent)
    else:
        shoulder=5 if role=='heavy' else (3 if role=='boss' else 0)
        d.polygon([(12-shoulder,neck+8),(23+shoulder,neck+8),
                   (25+shoulder,neck+22),(22,neck+29),(9,neck+28),(8-shoulder,neck+17)],fill=armor)
        d.rectangle((14,neck+13,19,neck+22),fill=shadow)
        d.line([(13,neck+16),(21,neck+16)],fill=accent,width=2)
        # Role-specific armor silhouette.
        if role=='heavy':
            d.rectangle((3,neck+7,12,neck+14),fill=shadow)
            d.rectangle((22,neck+7,30,neck+14),fill=shadow)
            d.polygon([(6,neck+8),(10,neck+3),(14,neck+10)],fill=armor)
        if role=='boss':
            d.polygon([(6,neck+9),(4,neck+22),(10,neck+24),(13,neck+12)],fill=accent)
            d.polygon([(25,neck+9),(29,neck+22),(24,neck+24),(21,neck+12)],fill=accent)
        d.ellipse((11,neck-3,23,neck+10),fill=shadow)
        if role=='grunt':
            d.polygon([(11,neck+3),(10,neck-2),(16,neck-5),(24,neck+3)],fill=armor)
        elif role=='heavy':
            d.rectangle((8,neck-4,26,neck+3),fill=armor)
            d.rectangle((10,neck-7,24,neck-3),fill=shadow)
        elif role=='gunner':
            d.polygon([(9,neck),(13,neck-5),(22,neck-3),(25,neck+3)],fill=armor)
        elif role=='boss':
            d.polygon([(10,neck+1),(6,neck-7),(14,neck-2),(17,neck-11),
                       (20,neck-3),(27,neck-7),(24,neck+4)],fill=armor)
        d.rectangle((17,neck+2,23,neck+5),fill=accent)
        tip=27+(3 if attack else round(2*math.sin(a)))
        handY=neck+15+(round(6*math.sin(a)) if attack else pulse)
        d.line([(22,neck+12),(tip,handY)],fill=armor,width=4)
        if role=='gunner':
            recoil=2 if attack and frame in (4,5,6,7) else 0
            d.rectangle((19-recoil,handY-3,31-recoil,handY+1),fill=shadow)
            d.rectangle((24-recoil,handY-2,31-recoil,handY-1),fill=accent)
            if row==7 and frame in (5,6):d.rectangle((29,handY-2,31,handY),fill=(255,223,107,255))
        elif role=='boss':
            d.line([(tip,handY),(30,handY-7)],fill=accent,width=4)
        else:
            d.line([(tip,handY),(min(31,tip+2),handY-8)],fill=accent,width=3)
    # A moving armour diagnostic LED makes all 16 hand-authored placeholder
    # phases visibly distinct, including subtle idle/jump/fall poses.
    d.point((12 + frame % 8, neck + 17 + (frame // 8)*2),
            fill=(255,225,178,255))
    col,group=ACTOR_SLOTS[role]
    atlas.paste(img,(col*512+frame*FRAME_W,group*384+row*FRAME_H),img)

def main():
    atlas=Image.new('RGBA',(WIDTH,HEIGHT),(0,0,0,0))
    for row in range(8):
        for frame in range(16):
            draw_frame(atlas,row,frame)
            for role in ACTOR_SLOTS:
                draw_enemy_frame(atlas,role,row,frame)
    atlas.putpixel((1040,1180),(255,255,255,255))
    root=Path(__file__).resolve().parents[1]
    assets=root/'android/app/src/main/assets'
    assets.mkdir(parents=True,exist_ok=True)
    raw=b'FCAT'+WIDTH.to_bytes(2,'little')+HEIGHT.to_bytes(2,'little')+atlas.tobytes()
    (assets/'atlas.rgba').write_bytes(raw)
    atlas.save(root/'docs/atlas_preview.png')
    print(f'Generated {len(raw)} bytes; 6 actors, each 8 animations x 16 frames')
if __name__ == '__main__': main()
