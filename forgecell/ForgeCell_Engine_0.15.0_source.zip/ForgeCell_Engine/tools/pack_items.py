#!/usr/bin/env python3
"""Convert JSON item definitions to little-endian FCIT v1/v2."""
import json
import pathlib
import struct
import sys
KIND = {'armor': 0, 'passive': 1, 'consumable': 2}
def pack(doc):
    items = doc['items']
    if doc['version'] not in (1, 2) or not isinstance(items, list) or not 1 <= len(items) <= 128:
        raise ValueError('Unsupported item format/count')
    blob=bytearray(struct.pack('<4sHH', b'FCIT',doc['version'],len(items)))
    ids=set()
    for d in items:
        uid=d['id'].encode('utf8');name=d['name'].encode('utf8')
        if not 0<len(uid)<=63 or not 0<len(name)<=95 or uid in ids:
            raise ValueError('Invalid/duplicate ID or name')
        ids.add(uid)
        kind=KIND[d['kind']]
        values=[d.get(k,0) for k in ('health_bonus','damage_bonus','damage_reduction','heal')]
        if any(type(v)!=int or not 0<=v<=10000 for v in values):
            raise ValueError('Invalid modifier')
        if kind==2 and values[3]==0: raise ValueError('Consumables must have healing')
        blob.extend(struct.pack('<H',len(uid))+uid+struct.pack('<H',len(name))+name)
        blob.extend(struct.pack('<H4I',kind,*values))
        if doc['version'] == 2:
            rarity, level, speed = (d.get('rarity',0),d.get('level',1),d.get('speed_bonus_pct',0))
            if any(type(v)!=int for v in (rarity,level,speed)) or not 0<=rarity<=4 or not 1<=level<=100 or not 0<=speed<=100:
                raise ValueError('Invalid FCIT v2 rarity/level/speed')
            blob.extend(struct.pack('<3H',rarity,level,speed))
    if len(blob)>65536: raise ValueError('Too much data')
    return bytes(blob)
if __name__=='__main__':
    if len(sys.argv)!=3: sys.exit('Usage: pack_items.py input.json output.fcit')
    b=pack(json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf8')))
    pathlib.Path(sys.argv[2]).write_bytes(b)
    print(f'Wrote {len(b)} bytes')
