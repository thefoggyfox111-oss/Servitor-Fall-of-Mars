#!/usr/bin/env python3
"""Fail CI if the produced APK is missing its native engine or demo resources.

This is a package-level smoke check, not an Android device/runtime test.
"""
from pathlib import Path
import sys
from zipfile import BadZipFile, ZipFile

REQUIRED = {
    'AndroidManifest.xml', 'classes.dex',
    'lib/arm64-v8a/libforgecell.so',
    'assets/demo.fcl', 'assets/demo.fcan', 'assets/demo.fcwp',
    'assets/demo.fcit', 'assets/demo.fcey', 'assets/demo.fcob',
    'assets/demo.fclt', 'assets/demo.fcva', 'assets/atlas.rgba',
}

def main() -> int:
    if len(sys.argv) != 2:
        print('Usage: python tools/check_apk.py <path-to-apk>', file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    try:
        with ZipFile(path, 'r') as apk:
            bad = apk.testzip()
            if bad:
                print(f'Corrupt APK member: {bad}', file=sys.stderr)
                return 1
            names = set(apk.namelist())
            missing = REQUIRED - names
            if missing:
                print('Missing APK entries: ' + ', '.join(sorted(missing)), file=sys.stderr)
                return 1
            for file in REQUIRED:
                if apk.getinfo(file).file_size == 0:
                    print(f'Empty APK entry: {file}', file=sys.stderr)
                    return 1
    except (OSError, BadZipFile) as error:
        print(f'Cannot inspect APK: {error}', file=sys.stderr)
        return 1
    print('APK package smoke check: PASS (does not verify runtime)')
    return 0

if __name__ == '__main__':
    sys.exit(main())
