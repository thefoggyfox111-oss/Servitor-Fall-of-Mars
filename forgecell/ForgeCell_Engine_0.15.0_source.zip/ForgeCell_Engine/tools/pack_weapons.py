#!/usr/bin/env python3
"""Compile external JSON weapon definitions into bounded little-endian FCWP v1."""
import json
import math
import pathlib
import struct
import sys

FIELDS = ('startup', 'active', 'recovery', 'reach', 'hit_height',
          'knockback', 'cooldown', 'projectile_speed', 'reload_seconds')


def pack(source: pathlib.Path, dest: pathlib.Path) -> None:
    cfg = json.loads(source.read_text(encoding='utf-8'))
    assert cfg.get('version') == 1, 'unknown weapon format version'
    weapons = cfg['weapons']
    assert 1 <= len(weapons) <= 256
    ids = set()
    kinds = set()
    result = bytearray(b'FCWP')
    result += struct.pack('<HH', 1, len(weapons))
    for item in weapons:
        id_bytes = item['id'].encode('utf-8')
        name_bytes = item['name'].encode('utf-8')
        assert 0 < len(id_bytes) <= 63 and 0 < len(name_bytes) <= 95
        assert item['id'] not in ids, 'duplicate weapon ID'
        ids.add(item['id'])
        kind = {'melee': 0, 'ranged': 1}[item['kind']]
        kinds.add(kind)
        damage, magazine = int(item['damage']), int(item['magazine'])
        assert 1 <= damage <= 100000 and 1 <= magazine <= 1000
        nums = [float(item[key]) for key in FIELDS]
        assert all(math.isfinite(v) for v in nums)
        assert nums[0] >= 0 and nums[1] > 0 and nums[2] >= 0
        assert all(v > 0 for v in (nums[3], nums[4], nums[6], nums[7], nums[8]))
        assert nums[5] >= 0
        for b in (id_bytes, name_bytes):
            result += struct.pack('<H', len(b)) + b
        result += struct.pack('<HI', kind, damage)
        result += struct.pack('<8f', *nums[:8])
        result += struct.pack('<If', magazine, nums[8])
    assert kinds == {0, 1}, 'both weapon classes required'
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(result)
    print(f'Wrote {dest}: {len(weapons)} definitions, {len(result)} bytes')


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: pack_weapons.py config.json output.fcwp')
    pack(pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]))
