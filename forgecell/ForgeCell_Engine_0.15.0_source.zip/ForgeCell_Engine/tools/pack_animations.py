#!/usr/bin/env python3
"""Pack authorable animation JSON into validated little-endian FCAN v1.

Schema: {"idle": {"loop": true, "frames": [{"ms": 62.5,
    "events": 0, "anchors": {"muzzle": [24, 18]}}]}}
Tracks match the demo atlas rows; frames can contain different durations.
"""
import argparse
import json
import math
import struct
from pathlib import Path

TRACKS=['idle','run','jump','fall','landing','roll','attack','shoot']
ANCHORS=['left_hand','right_hand','weapon','muzzle','body','feet','effect']

def pack(document):
    if not isinstance(document, dict) or not document:
        raise ValueError('Animations must be an object with at least one track')
    unknown=set(document)-set(TRACKS)
    if unknown:raise ValueError(f'Unknown animation track(s): {sorted(unknown)}')
    out=bytearray(struct.pack('<4sHH',b'FCAN',1,len(document)))
    for track in TRACKS:
        if track not in document:continue
        spec=document[track];frames=spec['frames']
        if not isinstance(frames,list) or not 1<=len(frames)<=4096:
            raise ValueError(f'{track}: invalid frames array')
        loop=spec.get('loop',True)
        if not isinstance(loop,bool):raise ValueError(f'{track}: loop must be boolean')
        out.extend(struct.pack('<HHB3x',TRACKS.index(track),len(frames),int(loop)))
        for frame in frames:
            ms=frame['ms']
            if not isinstance(ms,(int,float)) or not math.isfinite(ms) or not 1<=ms<=10000:
                raise ValueError(f'{track}: invalid frame duration')
            events=frame.get('events',0)
            if not isinstance(events,int) or not 0<=events<=0xffffffff:
                raise ValueError(f'{track}: invalid event mask')
            anchors=frame.get('anchors',{})
            if set(anchors)-set(ANCHORS):raise ValueError(f'{track}: unknown anchors')
            out.extend(struct.pack('<fI',ms/1000,events))
            for name in ANCHORS:
                xy=anchors.get(name,(0,0))
                if len(xy)!=2 or any(not isinstance(v,(int,float)) or
                                    not math.isfinite(v) or abs(v)>10000 for v in xy):
                    raise ValueError(f'{track}: invalid anchor {name}')
                out.extend(struct.pack('<ff',*xy))
    return bytes(out)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('input',type=Path);ap.add_argument('output',type=Path)
    args=ap.parse_args()
    blob=pack(json.loads(args.input.read_text(encoding='utf8')))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_bytes(blob)
    print(f'Packed {len(blob)} bytes of animation metadata to {args.output}')
