#!/usr/bin/env python3
"""Pack ForgeCell FCOB v1 scene objects from a JSON source file."""
import json
import math
import struct
import sys
from pathlib import Path

def pack(source):
    objects=json.loads(Path(source).read_text(encoding='utf-8'))['objects']
    if not isinstance(objects,list) or len(objects)>128:
        raise ValueError('object count must be <=128')
    ids=set()
    data=bytearray(b'FCOB'+struct.pack('<HH',1,len(objects)))
    for o in objects:
        identifier=o['id']; kind={'crate':0,'checkpoint':1}[o['kind']]
        x,y,radius=(float(o[k]) for k in ('x','y','radius'))
        hp=int(o['health'])
        if not isinstance(identifier,int) or not 0<identifier<2**32 or identifier in ids:
            raise ValueError('duplicate/invalid stable object id')
        if any(not math.isfinite(v) for v in (x,y,radius)) or not 4<=radius<=128 or not 0<=x<=100000 or not 0<=y<=100000 or not 0<hp<=10000:
            raise ValueError('invalid object dimensions/health')
        ids.add(identifier)
        data.extend(struct.pack('<IBffHf',identifier,kind,x,y,hp,radius))
    return data

if __name__=='__main__':
    if len(sys.argv)!=3:sys.exit('Usage: python tools/pack_objects.py config/demo_objects.json output.fcob')
    Path(sys.argv[2]).write_bytes(pack(sys.argv[1]))
