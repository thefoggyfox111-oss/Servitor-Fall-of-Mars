#!/usr/bin/env python3
"""Convert LDtk's IntGrid collision layer to ForgeCell runtime FCLV v1.

Values: 0 empty, 1 solid, 2 one-way. Consecutive equal tiles in each
row are merged into one rectangle. This importer intentionally handles
collision geometry only; LDtk entities, art layers, and lighting are stage 7.
"""
import argparse
import json
import struct
from pathlib import Path

def convert(project: dict, level_name: str | None = None) -> bytes:
    levels = project.get('levels', [])
    if not levels:
        raise ValueError('LDtk project contains no levels')
    level = next((x for x in levels if x.get('identifier') == level_name),None) if level_name else levels[0]
    if level is None:
        raise ValueError(f'Unknown level: {level_name}')
    layers=level.get('layerInstances') or []
    if not layers:
        raise ValueError('External .ldtkl level must be embedded or separately loaded')
    solids=[]
    one_way=[]
    for layer in layers:
        if layer.get('__type') != 'IntGrid' or layer.get('__identifier') != 'Collisions':
            continue
        w,h=int(layer['__cWid']),int(layer['__cHei'])
        size=int(layer['__gridSize'])
        ox=int(layer.get('pxOffsetX',0));oy=int(layer.get('pxOffsetY',0))
        csv=layer['intGridCsv']
        if w<1 or h<1 or len(csv)!=w*h:raise ValueError('Malformed IntGrid')
        for y in range(h):
            x=0
            while x<w:
                t=csv[y*w+x]
                if t not in (1,2):x+=1;continue
                x2=x+1
                while x2<w and csv[y*w+x2]==t:x2+=1
                (solids if t==1 else one_way).append((ox+x*size,oy+y*size,(x2-x)*size,size))
                x=x2
    if not solids and not one_way:
        raise ValueError('No Collisions IntGrid with tile values 1 or 2')
    width=float(level['pxWid']);height=float(level['pxHei'])
    if width<640 or height<360:
        raise ValueError('Level too small; logical camera needs 640x360')
    result=struct.pack('<4sHHffII',b'FCLV',1,0,width,height,len(solids),len(one_way))
    for r in solids+one_way:
        result += struct.pack('<4f',*r)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('input',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--level',default=None)
    args=parser.parse_args()
    args.output.write_bytes(convert(json.loads(args.input.read_text(encoding='utf-8')),args.level))
    print(f'Wrote {args.output}: {args.output.stat().st_size} bytes')
