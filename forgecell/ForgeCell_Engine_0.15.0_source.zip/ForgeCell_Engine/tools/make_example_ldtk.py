#!/usr/bin/env python3
"""Create a small LDtk-like example to demonstrate geometry import."""
import json
from pathlib import Path
w,h=124,23
cells=[0]*(w*h)
def paint(x,y,length,kind=1):
    for cx in range(x,min(x+length,w)):
        cells[y*w+cx]=kind
for y in range(18,23):
    paint(0,y,33);paint(38,y,27);paint(69,y,55)
paint(19,14,7);paint(44,15,9);paint(55,12,6)
paint(76,14,10);paint(96,13,9)
paint(32,15,6,2);paint(65,14,7,2)
level={
    'identifier':'ForgeCell_Demo','pxWid':w*16,'pxHei':h*16,
    'layerInstances':[{'__type':'IntGrid','__identifier':'Collisions',
                       '__cWid':w,'__cHei':h,'__gridSize':16,
                       'pxOffsetX':0,'pxOffsetY':0,'intGridCsv':cells}]
}
root=Path(__file__).resolve().parents[1]
p=root/'docs/demo_ldtk_example.json'
p.write_text(json.dumps({'levels':[level]},ensure_ascii=False,indent=2),encoding='utf-8')
print(p)
