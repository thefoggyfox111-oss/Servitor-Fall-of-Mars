#!/usr/bin/env python3
"""Validate loot rules JSON and emit deterministic FCLT v1 binary."""
import json
import pathlib
import struct
import sys

ROLES = ('dummy', 'grunt', 'heavy', 'gunner', 'boss')
STATS = ('health', 'damage', 'defense', 'speed', 'healing')

def pack(data):
    seed = data['seed']
    if type(seed) is not int or not 0 <= seed < 2**64:
        raise ValueError('seed must be unsigned 64-bit integer')
    rules = data['rules']
    if not isinstance(rules, list) or len(rules) != len(ROLES):
        raise ValueError('exactly five rules required')
    output = bytearray(struct.pack('<4sHHQ', b'FCLT', 1, 5, seed))
    seen = set()
    for entry in rules:
        role = entry['role']
        if role not in ROLES or role in seen:
            raise ValueError('invalid or duplicate role')
        seen.add(role)
        chance, rolls, low, high = (entry[k] for k in ('chance', 'rolls', 'min', 'max'))
        stats = entry['stats']
        if any(type(v) is not int for v in (chance, rolls, low, high)):
            raise ValueError('values must be integers')
        if not (0 <= chance <= 100 and 0 <= rolls <= 3 and 0 <= low <= high <= 100):
            raise ValueError('invalid probability, number of bonuses or range')
        if not isinstance(stats, list) or len(stats) != len(set(stats)) or any(s not in STATS for s in stats):
            raise ValueError('unknown/duplicate stat')
        if len(stats) < rolls:
            raise ValueError('not enough eligible stats')
        mask = sum(1 << STATS.index(s) for s in stats)
        output.extend(struct.pack('<BBBBHH', ROLES.index(role), chance, rolls, mask, low, high))
    return bytes(output)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('usage: pack_loot.py config.json out.fclt')
    pathlib.Path(sys.argv[2]).write_bytes(pack(json.loads(pathlib.Path(sys.argv[1]).read_text())))
