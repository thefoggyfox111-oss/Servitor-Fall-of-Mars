#!/usr/bin/env python3
"""Compile pixel-atlas archetypes JSON to checked FCVA v1 metadata."""
import json
import pathlib
import struct
import sys

def pack(data):
    styles = data['styles']
    width, height = data['atlas_width'], data['atlas_height']
    if data.get('version') != 1 or not 32 <= width <= 8192 or not 32 <= height <= 8192:
        raise ValueError('Invalid FCVA version/atlas')
    if not isinstance(styles, list) or not 1 <= len(styles) <= 32:
        raise ValueError('Expected 1..32 visual archetypes')
    out = bytearray(struct.pack('<4sHHHH', b'FCVA', 1, len(styles), width, height))
    used = set()
    for s in styles:
        slot = s['slot']
        x,y,fw,fh = (s[k] for k in ('x','y','frame_width','frame_height'))
        frames, clips = s['frames'], s['animations']
        footx, footy = s['foot_x'], s['foot_y']
        if not (0 <= slot < 32 and slot not in used and 0 <= x and 0 <= y and
                1 <= fw <= 512 and 1 <= fh <= 512 and 1 <= frames <= 4096 and
                1 <= clips <= 32 and -512 <= footx <= 512 and -512 <= footy <= 512 and
                x+fw*frames <= width and y+fh*clips <= height):
            raise ValueError(f'Invalid visual archetype: {s}')
        used.add(slot)
        out.extend(struct.pack('<7H2h', slot,x,y,fw,fh,frames,clips,footx,footy))
    if 0 not in used:
        raise ValueError('Hero style slot 0 required')
    return bytes(out)

if __name__=='__main__':
    if len(sys.argv)!=3:
        sys.exit('Usage: pack_visuals.py input.json output.fcva')
    pathlib.Path(sys.argv[2]).write_bytes(pack(json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))))
