#!/usr/bin/env python3
"""Pack enemy profiles to FCEY v1/v2. v2 adds an FCVA visual slot."""
import json
import math
import pathlib
import struct
import sys

ROLES = {'dummy': 0, 'grunt': 1, 'heavy': 2, 'gunner': 3, 'boss': 4}
FIELDS = ('x', 'y', 'chase_speed', 'patrol_speed', 'detection_range',
          'attack_range', 'startup', 'active', 'recovery')

def pack(data):
    if data.get('version') not in (1, 2) or not isinstance(data.get('enemies'), list):
        raise ValueError('Expected FCEY version 1/2 and enemies array')
    enemies = data['enemies']
    if not 1 <= len(enemies) <= 128:
        raise ValueError('Expected 1..128 enemies')
    output = bytearray(struct.pack('<4sHH', b'FCEY', data['version'], len(enemies)))
    ids = set()
    for enemy in enemies:
        uid = enemy['id']
        if not isinstance(uid, int) or isinstance(uid, bool) or not 0 < uid < 2**32 or uid in ids:
            raise ValueError('Enemy ID must be a unique positive uint32')
        ids.add(uid)
        role = ROLES[enemy['role']]
        health, damage = enemy['health'], enemy['damage']
        if not isinstance(health, int) or not 1 <= health <= 100000:
            raise ValueError('Health out of range')
        if not isinstance(damage, int) or not 1 <= damage <= 10000:
            raise ValueError('Damage out of range')
        values = [float(enemy[k]) for k in FIELDS]
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Non-finite values')
        x,y,speed,patrol,detect,reach,start,active,recovery = values
        if not (abs(x) <= 100000 and abs(y) <= 100000 and
                0 < speed <= 1000 and 0 <= patrol <= 1000 and
                0 < detect <= 5000 and 0 < reach <= 2000 and
                0 < start <= 30 and 0 < active <= 30 and 0 < recovery <= 30):
            raise ValueError('Invalid enemy parameters')
        loot = enemy.get('loot', '').encode('utf-8')
        if len(loot) > 63:
            raise ValueError('Loot ID too long')
        output.extend(struct.pack('<IHI9fIH', uid, role, health, *values, damage, len(loot)))
        output.extend(loot)
        if data['version'] == 2:
            style = enemy.get('visual_index', role+1)
            if not isinstance(style, int) or isinstance(style,bool) or not 0 <= style < 32:
                raise ValueError('visual_index must be FCVA slot 0..31')
            output.extend(struct.pack('<H', style))
    if len(output) > 65536:
        raise ValueError('FCEY max size exceeded')
    return bytes(output)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('Usage: pack_enemies.py input.json output.fcey')
    result = pack(json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')))
    pathlib.Path(sys.argv[2]).write_bytes(result)
    print(f'Wrote {len(result)} bytes')
