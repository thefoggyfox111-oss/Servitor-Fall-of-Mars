#include "forge/Effects.hpp"
#include <cmath>
#include <algorithm>
namespace forge {
EntityId EffectSystem::emit(float x,float y,EffectKind kind) {
    if(!std::isfinite(x)||!std::isfinite(y)||size()>=kMaxEffects)return {};
    const EntityId id=entities_.create();
    if(!entities_.alive(id))return {};
    const float duration=kind==EffectKind::Death?.42f:
                         kind==EffectKind::Shot?.10f:.20f;
    if(!effects_.set(id,{x,y,0,duration,kind})) {
        entities_.destroy(id);
        return {};
    }
    return id;
}
bool EffectSystem::remove(EntityId id) {
    if(!entities_.alive(id))return false;
    effects_.remove(id);
    return entities_.destroy(id);
}
void EffectSystem::tick(float dt) {
    if(!std::isfinite(dt)||dt<=0)return;
    expired_.clear();
    for(const auto& item:effects_.entries()) {
        auto* e=effects_.get(item.entity);
        e->age+=dt;
        if(e->age>=e->duration)expired_.push_back(item.entity);
    }
    for(const auto id:expired_)remove(id);
}
void EffectSystem::clear() {
    effects_.clear();
    entities_.clear();
    expired_.clear();
}
}
