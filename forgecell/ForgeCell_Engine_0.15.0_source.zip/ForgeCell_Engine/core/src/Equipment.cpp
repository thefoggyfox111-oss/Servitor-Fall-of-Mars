#include "forge/Equipment.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <limits>
#include <charconv>
#include <utility>

namespace forge {
namespace {
WeaponDefinition sword() {WeaponDefinition d;d.id="rusted_sword";d.name="Rusted Sword";d.kind=WeaponKind::Melee;d.damage=30;return d;}
WeaponDefinition axe() {WeaponDefinition d;d.id="heavy_axe";d.name="Heavy Axe";d.kind=WeaponKind::Melee;d.damage=48;d.startup=.22f;d.active=.13f;d.recovery=.35f;d.reach=40;d.knockback=160;return d;}
WeaponDefinition pistol() {WeaponDefinition d;d.id="pistol";d.name="Pistol";d.kind=WeaponKind::Ranged;d.damage=16;d.cooldown=.21f;d.magazine=12;return d;}
WeaponDefinition rifle() {WeaponDefinition d;d.id="rifle";d.name="Rifle";d.kind=WeaponKind::Ranged;d.damage=11;d.cooldown=.11f;d.projectileSpeed=940;d.magazine=24;d.reloadSeconds=1.7f;return d;}
bool valid(const WeaponDefinition& d) {
    if(d.id.empty() || d.id[0]=='~' || d.id.size()>63 || d.name.empty() || d.name.size()>95 || d.damage<1 || d.damage>100000 ||
       d.magazine<1 || d.magazine>1000)return false;
    for(float value : {d.startup,d.active,d.recovery,d.reach,d.hitHeight,d.knockback,
                       d.cooldown,d.projectileSpeed,d.reloadSeconds}) if(!std::isfinite(value))return false;
    return d.startup>=0 && d.active>0 && d.recovery>=0 && d.reach>0 && d.hitHeight>0 &&
           d.knockback>=0 && d.cooldown>0 && d.projectileSpeed>0 && d.reloadSeconds>0;
}
struct Reader {
    std::span<const std::byte> data;
    size_t p=0;
    bool read16(uint16_t& v) {
        if(p+2>data.size())return false;
        v=static_cast<uint16_t>(std::to_integer<uint8_t>(data[p])) |
          (static_cast<uint16_t>(std::to_integer<uint8_t>(data[p+1]))<<8);
        p+=2;return true;
    }
    bool read32(uint32_t& v) {
        if(p+4>data.size())return false;
        v=0;
        for(int i=0;i<4;++i)v|=uint32_t(std::to_integer<uint8_t>(data[p+i]))<<(i*8);
        p+=4;return true;
    }
    bool readFloat(float& f) {uint32_t bits; if(!read32(bits))return false;std::memcpy(&f,&bits,4);return true;}
    bool readString(std::string& s, size_t maxLen) {
        uint16_t n=0;
        if(!read16(n) || n==0 || n>maxLen || n>data.size()-p)return false;
        s.assign(reinterpret_cast<const char*>(data.data()+p),n);p+=n;return true;
    }
};
}
Equipment::Equipment() {
    definitions={sword(),axe(),pistol(),rifle()};
    equipped={"rusted_sword","pistol"};
    backpack[0]="heavy_axe";backpack[1]="rifle";
}
const std::string& Equipment::definitionId(const std::string& token) const {
    if(const auto* item=instance(token))return item->definitionId;
    return token;
}
const ItemInstance* Equipment::instance(const std::string& token) const {
    if(token.size()<2 || token[0]!='~')return nullptr;
    uint32_t uid=0;
    const auto result=std::from_chars(token.data()+1,token.data()+token.size(),uid);
    if(result.ec!=std::errc{} || result.ptr!=token.data()+token.size() || uid==0)return nullptr;
    for(const auto& item:instances_)if(item.uid==uid)return &item;
    return nullptr;
}
const WeaponDefinition* Equipment::find(const std::string& id) const {
    if(!id.empty() && id[0]=='~' && !instance(id))return nullptr;
    const auto& base=definitionId(id);
    for(const auto& d:definitions)if(d.id==base)return &d;
    return nullptr;
}
const WeaponDefinition* Equipment::slot(size_t index) const {
    return index<equipped.size()?find(equipped[index]):nullptr;
}
ItemAffixes Equipment::bonuses(const std::string& token) const {
    const auto* value=instance(token);
    return value?value->affixes:ItemAffixes{};
}
int Equipment::weaponDamage(size_t slotIndex) const {
    if(slotIndex>=equipped.size())return 0;
    const auto* weapon=slot(slotIndex);
    return weapon?weapon->damage+bonuses(equipped[slotIndex]).damage:0;
}
int Equipment::consumableHealing() const {
    const auto* item=findItem(accessories[3]);
    return item?item->healAmount+bonuses(accessories[3]).healing:0;
}
namespace {
bool validAffixes(const ItemAffixes& a) {
    return a.health<=2000 && a.damage<=2000 && a.defense<=2000 &&
           a.speedPct<=100 && a.healing<=2000;
}
}
bool Equipment::addInstanceToBackpack(const std::string& base,ItemAffixes attrs,uint32_t* createdUid) {
    if(base.empty() || base[0]=='~' || (!find(base) && !findItem(base)) ||
       instances_.size()>=kMaxInstances || nextInstanceUid_==0 || !validAffixes(attrs))return false;
    auto empty=std::find(backpack.begin(),backpack.end(),std::string{});
    if(empty==backpack.end())return false;
    const uint32_t id=nextInstanceUid_++;
    instances_.push_back({id,base,attrs});
    *empty="~"+std::to_string(id);
    if(createdUid)*createdUid=id;
    return true;
}
std::string Equipment::createWorldInstance(const std::string& base,ItemAffixes attrs) {
    if(base.empty() || base[0]=='~' || (!find(base) && !findItem(base)) ||
       instances_.size()>=kMaxInstances || nextInstanceUid_==0 || !validAffixes(attrs))return {};
    const uint32_t id=nextInstanceUid_++;
    instances_.push_back({id,base,attrs});
    return "~"+std::to_string(id);
}
void Equipment::rollbackWorldInstance(const std::string& token) {
    if(instances_.empty())return;
    const auto* entry=instance(token);
    if(!entry || entry->uid!=instances_.back().uid)return;
    instances_.pop_back();
    // UID remains burned, so leaked references cannot alias later instances.
}
bool Equipment::restoreInstances(std::vector<ItemInstance> records) {
    if(records.size()>kMaxInstances)return false;
    std::unordered_set<uint32_t> ids;
    uint32_t largest=0;
    for(const auto& record:records) {
        if(record.uid==0 || record.uid==std::numeric_limits<uint32_t>::max() ||
           record.definitionId.empty() || record.definitionId[0]=='~' ||
           (!find(record.definitionId) && !findItem(record.definitionId)) ||
           !validAffixes(record.affixes) || !ids.insert(record.uid).second)return false;
        largest=std::max(largest,record.uid);
    }
    instances_=std::move(records);
    nextInstanceUid_=largest+1;
    return true;
}
bool Equipment::validReferences() const {
    for(size_t i=0;i<equipped.size();++i) {
        const auto* w=find(equipped[i]);
        if(!w || w->kind!=(i==0?WeaponKind::Melee:WeaponKind::Ranged))return false;
    }
    for(size_t i=0;i<accessories.size();++i) {
        if(accessories[i].empty())continue;
        const auto* d=findItem(accessories[i]);
        if(!d || d->kind!=(i==0?ItemKind::Armor:i==3?ItemKind::Consumable:ItemKind::Passive))return false;
    }
    for(const auto& token:backpack)if(!token.empty() && !find(token) && !findItem(token))return false;
    return true;
}
bool Equipment::addToBackpack(const std::string& id) {
    if(!find(id) && !findItem(id))return false;
    for(auto& item:backpack)if(item.empty()){item=id;return true;}
    return false;
}
void Equipment::sortBackpack() {
    // A stable sort groups equipped-compatible item families; existing physical
    // tokens (~uid) are moved, not cloned or regenerated. Empty cells go last.
    const auto group=[this](const std::string& token) -> int {
        if(token.empty())return 5;
        if(const auto* weapon=find(token))return weapon->kind==WeaponKind::Melee?0:1;
        if(const auto* item=findItem(token))return item->kind==ItemKind::Armor?2:
            item->kind==ItemKind::Passive?3:4;
        return 6; // invalid tokens retain stable order; save validation rejects them
    };
    std::stable_sort(backpack.begin(),backpack.end(),[&](const std::string& a,const std::string& b){
        const int ga=group(a),gb=group(b);
        if(ga!=gb)return ga<gb;
        const auto* ia=findItem(a),*ib=findItem(b);
        if(ia && ib) {
            if(ia->rarity!=ib->rarity)return ia->rarity>ib->rarity;
            if(ia->level!=ib->level)return ia->level>ib->level;
        }
        return false; // preserve placement within equal classes/rarity/level
    });
}
bool Equipment::swapBackpack(size_t from,size_t to) {
    if(from>=backpack.size()||to>=backpack.size()||from==to||backpack[from].empty())return false;
    std::swap(backpack[from],backpack[to]);
    return true;
}
bool Equipment::transferEquipmentToBackpack(size_t slot,size_t bag) {
    if(slot>=6 || bag>=backpack.size())return false;
    auto& currently=slot<2?equipped[slot]:accessories[slot-2];
    if(currently.empty())return false;
    const auto& target=backpack[bag];
    if(!target.empty()) {
        if(slot<2) {
            const auto* w=find(target);
            if(!w || w->kind!=(slot==0?WeaponKind::Melee:WeaponKind::Ranged))return false;
        } else {
            const auto* item=findItem(target);
            if(!item||item->kind!=(slot==2?ItemKind::Armor:slot==5?ItemKind::Consumable:ItemKind::Passive))return false;
        }
    }
    // Never unequip a required melee/ranged weapon: these have no empty-slot fallback.
    if(slot<2 && target.empty())return false;
    std::swap(currently,backpack[bag]);
    return true;
}
bool Equipment::equipFromBackpack(size_t backpackIndex,size_t slotIndex) {
    if(backpackIndex>=backpack.size() || slotIndex>=equipped.size())return false;
    const auto* next=find(backpack[backpackIndex]);
    if(!next || (slotIndex==0 && next->kind!=WeaponKind::Melee) ||
       (slotIndex==1 && next->kind!=WeaponKind::Ranged))return false;
    std::swap(equipped[slotIndex],backpack[backpackIndex]);
    return true;
}
bool Equipment::setDefinitions(std::vector<WeaponDefinition> defs) {
    if(defs.empty() || defs.size()>256)return false;
    std::unordered_set<std::string> ids;
    for(const auto& item:itemDefinitions)ids.insert(item.id);
    for(const auto& d:defs) if(!valid(d) || !ids.insert(d.id).second)return false;
    const auto findKind=[&](WeaponKind kind)->std::string {
        for(const auto& d:defs)if(d.kind==kind)return d.id;
        return {};
    };
    const auto melee=findKind(WeaponKind::Melee),ranged=findKind(WeaponKind::Ranged);
    if(melee.empty() || ranged.empty())return false;
    // Validate complete candidate first, then commit atomically.
    std::array<std::string,kBackpackSize> newBag {};
    size_t nextBag=0;
    for(const auto& d:defs)if(d.id!=melee && d.id!=ranged && nextBag<newBag.size())newBag[nextBag++]=d.id;
    definitions=std::move(defs);
    equipped={melee,ranged};backpack=std::move(newBag);
    accessories={};
    instances_.clear();nextInstanceUid_=1;
    return true;
}
const ItemDefinition* Equipment::findItem(const std::string& id) const {
    if(!id.empty() && id[0]=='~' && !instance(id))return nullptr;
    const auto& base=definitionId(id);
    for(const auto& d:itemDefinitions)if(d.id==base)return &d;
    return nullptr;
}
bool Equipment::setItems(std::vector<ItemDefinition> items) {
    if(items.empty() || items.size()>128)return false;
    std::unordered_set<std::string> ids;
    for(const auto& w:definitions)ids.insert(w.id);
    for(const auto& d:items) {
        if(d.id.empty() || d.id[0]=='~' || d.id.size()>63 || d.name.empty() || d.name.size()>95 ||
           static_cast<int>(d.kind)>2 || d.healthBonus<0 || d.healthBonus>10000 ||
           d.damageBonus<0 || d.damageBonus>10000 || d.damageReduction<0 || d.damageReduction>10000 ||
           d.healAmount<0 || d.healAmount>10000 ||
           d.level<1 || d.level>100 || d.rarity>4 || d.speedBonusPct>100 ||
           !ids.insert(d.id).second)return false;
        if(d.kind==ItemKind::Consumable && d.healAmount==0)return false;
    }
    // Preserve only accessories that still resolve with matching type.
    for(size_t slot=0;slot<accessories.size();++slot) {
        bool matches=false;
        for(const auto& d:items)
            if(d.id==definitionId(accessories[slot]) && d.kind==
                (slot==0?ItemKind::Armor:slot==3?ItemKind::Consumable:ItemKind::Passive))matches=true;
        if(!matches)accessories[slot].clear();
    }
    itemDefinitions=std::move(items);
    // Catalog hot reload cannot leave dangling tokens. Weapons remain valid.
    std::erase_if(instances_,[&](const ItemInstance& inst){
        return !find(inst.definitionId) && !findItem(inst.definitionId);
    });
    for(auto& token:backpack)if(!token.empty() && !find(token) && !findItem(token))token.clear();
    for(auto& token:accessories)if(!token.empty() && !findItem(token))token.clear();
    return true;
}
bool Equipment::equipAccessoryFromBackpack(size_t bag,size_t slot) {
    if(bag>=backpack.size() || slot>=accessories.size())return false;
    const auto* item=findItem(backpack[bag]);
    if(!item || item->kind!=(slot==0?ItemKind::Armor:slot==3?ItemKind::Consumable:ItemKind::Passive))return false;
    std::swap(backpack[bag],accessories[slot]);return true;
}
int Equipment::bonusHealth() const {
    int result=0;
    for(size_t i=0;i<3;++i)if(const auto* d=findItem(accessories[i]))result+=d->healthBonus+bonuses(accessories[i]).health;
    return result;
}
int Equipment::bonusDamage() const {
    int result=0;
    for(size_t i=0;i<3;++i)if(const auto* d=findItem(accessories[i]))result+=d->damageBonus+bonuses(accessories[i]).damage;
    return result;
}
int Equipment::damageReduction() const {
    int result=0;
    for(size_t i=0;i<3;++i)if(const auto* d=findItem(accessories[i]))result+=d->damageReduction+bonuses(accessories[i]).defense;
    return result;
}
int Equipment::speedBonusPercent() const {
    int total=0;
    for(size_t i=0;i<3;++i)
        if(const auto* d=findItem(accessories[i]))total+=d->speedBonusPct+bonuses(accessories[i]).speedPct;
    return std::min(total,100);
}
EquipmentComparison Equipment::compareBackpackToSlot(size_t bag,size_t slot) const {
    EquipmentComparison result;
    if(bag>=backpack.size() || slot>=6)return result;
    const auto& candidate=backpack[bag];
    const auto& current=slot<2?equipped[slot]:accessories[slot-2];
    if(slot<2) {
        const auto* item=find(candidate);
        if(!item || item->kind!=(slot==0?WeaponKind::Melee:WeaponKind::Ranged))return result;
        const auto* equippedItem=find(current);
        result.compatible=true;
        result.damageDelta=item->damage+bonuses(candidate).damage-(equippedItem?equippedItem->damage+bonuses(current).damage:0);
        return result;
    }
    const auto* item=findItem(candidate);
    if(!item || item->kind!=(slot==2?ItemKind::Armor:slot==5?ItemKind::Consumable:ItemKind::Passive))return result;
    const auto* equippedItem=findItem(current);
    result.compatible=true;
    const auto a=bonuses(candidate),b=bonuses(current);
    result.healthDelta=int(item->healthBonus+a.health)-(equippedItem?int(equippedItem->healthBonus+b.health):0);
    result.damageDelta=int(item->damageBonus+a.damage)-(equippedItem?int(equippedItem->damageBonus+b.damage):0);
    result.defenseDelta=int(item->damageReduction+a.defense)-(equippedItem?int(equippedItem->damageReduction+b.defense):0);
    result.speedDeltaPct=int(item->speedBonusPct+a.speedPct)-(equippedItem?int(equippedItem->speedBonusPct+b.speedPct):0);
    result.healingDelta=int(item->healAmount+a.healing)-(equippedItem?int(equippedItem->healAmount+b.healing):0);
    result.levelDelta=int(item->level)-(equippedItem?int(equippedItem->level):0);
    result.rarity=item->rarity;
    return result;
}
int Equipment::useConsumable() {
    const auto* d=findItem(accessories[3]);
    if(!d || d->kind!=ItemKind::Consumable)return 0;
    const int heal=consumableHealing();
    if(const auto* inst=instance(accessories[3])) {
        const auto uid=inst->uid;
        std::erase_if(instances_,[&](const ItemInstance& i){return i.uid==uid;});
    }
    accessories[3].clear();return heal;
}
bool loadWeaponBinary(std::span<const std::byte> b, Equipment& equipment,std::string& error) {
    if(b.size()<8 || b.size()>1024*128) {error="FCWP size invalid";return false;}
    if(std::memcmp(b.data(),"FCWP",4)!=0) {error="FCWP signature invalid";return false;}
    Reader r{b,4};uint16_t version=0,count=0;
    if(!r.read16(version) || !r.read16(count) || version!=1 || count==0 || count>256) {
        error="FCWP version/count invalid";return false;
    }
    std::vector<WeaponDefinition> defs;defs.reserve(count);
    for(size_t i=0;i<count;++i) {
        WeaponDefinition d;uint16_t kind=0;uint32_t damage=0,magazine=0;
        if(!r.readString(d.id,63) || !r.readString(d.name,95) || !r.read16(kind) || kind>1 ||
           !r.read32(damage) || !r.readFloat(d.startup) || !r.readFloat(d.active) ||
           !r.readFloat(d.recovery) || !r.readFloat(d.reach) || !r.readFloat(d.hitHeight) ||
           !r.readFloat(d.knockback) || !r.readFloat(d.cooldown) ||
           !r.readFloat(d.projectileSpeed) || !r.read32(magazine) ||
           !r.readFloat(d.reloadSeconds)) {error="FCWP weapon entry truncated";return false;}
        if(damage>100000 || magazine>1000) {error="FCWP numbers out of range";return false;}
        d.damage=static_cast<int>(damage);d.magazine=static_cast<int>(magazine);
        d.kind=static_cast<WeaponKind>(kind);defs.push_back(std::move(d));
    }
    if(r.p!=b.size() || !equipment.setDefinitions(std::move(defs))) {
        error="FCWP trailing bytes or invalid catalog";return false;
    }
    error.clear();return true;
}
}
