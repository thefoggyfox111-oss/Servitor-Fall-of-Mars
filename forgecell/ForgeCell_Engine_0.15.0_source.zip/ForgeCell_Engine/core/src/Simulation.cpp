#include "forge/Simulation.hpp"
#include <cmath>

namespace forge {
bool overlaps(Rect a, Rect b) {
    return a.x < b.x + b.w && a.x + a.w > b.x &&
           a.y < b.y + b.h && a.y + a.h > b.y;
}
World::World() {
    solids = {
        {0, 294, 530, 66}, {602, 294, 440, 66}, {1110, 294, 870, 66},
        {312, 234, 110, 15}, {705, 238, 140, 15}, {880, 193, 90, 15},
        {1220, 224, 160, 16}, {1530, 210, 130, 16},
        {0, 0, 16, 360}, {1964, 0, 16, 360}
    };
    oneWay = {{500, 244, 90, 12}, {1080, 236, 105, 12}};
}
Vec2 Camera::interpolated(float a) const {
    return {previous.x + (center.x - previous.x) * a,
            previous.y + (center.y - previous.y) * a};
}
float FixedStepper::advance(double seconds) {
    return advance(seconds, [](float){});
}
float Simulation::approach(float value, float target, float step) {
    return value < target ? std::min(value + step, target) : std::max(value - step, target);
}
Simulation::Simulation() {combat.resetDemo();}
void Simulation::reset() { *this = Simulation{}; }
void Simulation::tick(float dt, const Input& input) {
    if(input.inventoryPressed) {
        inventoryOpen=!inventoryOpen;
        inventorySelectionArmed=false;
    }
    if(inventoryOpen) {
        if(input.inventoryIndex>=0 &&
           static_cast<size_t>(input.inventoryIndex)<combat.equipment.backpack.size()) {
            const size_t index=static_cast<size_t>(input.inventoryIndex);
            if(!inventorySelectionArmed || inventorySelected!=index) {
                inventorySelected=index; // preview without changing any equipment
                inventorySelectionArmed=true;
            } else {
                const auto& id=combat.equipment.backpack[inventorySelected];
                if(const auto* weapon=combat.equipment.find(id))
                    combat.equipFromBackpack(inventorySelected,
                        weapon->kind==WeaponKind::Melee?0:1);
                else if(const auto* item=combat.equipment.findItem(id)) {
                    const size_t slot=item->kind==ItemKind::Armor?0:
                        item->kind==ItemKind::Consumable?3:
                        combat.equipment.accessories[1].empty()?1:2;
                    combat.equipment.equipAccessoryFromBackpack(inventorySelected,slot);
                }
                inventorySelectionArmed=false;
            }
        }
        // Drop acts on an explicitly highlighted item only; otherwise the
        // default index 0 could be discarded without the player selecting it.
        const bool dropConfirmed=input.dropSelectedPressed && inventorySelectionArmed;
        if(input.inventoryMoveFrom>=0 || input.inventoryUnequipSlot>=0 ||
           input.dropSelectedPressed || input.sortInventoryPressed)inventorySelectionArmed=false;
        if(input.sortInventoryPressed)combat.equipment.sortBackpack();
        if(input.inventoryMoveFrom>=0 && input.inventoryMoveTo>=0) {
            combat.equipment.swapBackpack(static_cast<size_t>(input.inventoryMoveFrom),
                                          static_cast<size_t>(input.inventoryMoveTo));
        }
        if(input.inventoryMoveFrom>=0 && input.inventoryEquipSlot>=0) {
            const size_t bag=static_cast<size_t>(input.inventoryMoveFrom);
            const int slot=input.inventoryEquipSlot;
            if(slot<2)combat.equipFromBackpack(bag,static_cast<size_t>(slot));
            else combat.equipment.equipAccessoryFromBackpack(bag,static_cast<size_t>(slot-2));
        }
        if(input.inventoryUnequipSlot>=0 && input.inventoryUnequipTo>=0) {
            const int slot=input.inventoryUnequipSlot;
            const size_t bag=static_cast<size_t>(input.inventoryUnequipTo);
            if(slot>=2)combat.equipment.transferEquipmentToBackpack(static_cast<size_t>(slot),bag);
            else {
                const auto* replacement=bag<combat.equipment.backpack.size()?
                    combat.equipment.find(combat.equipment.backpack[bag]):nullptr;
                if(replacement && replacement->kind==(slot==0?WeaponKind::Melee:WeaponKind::Ranged))
                    combat.equipFromBackpack(bag,static_cast<size_t>(slot));
            }
        }
        if(dropConfirmed)combat.dropFromBackpack(inventorySelected,player);
        // Inventory pauses physics/AI and ammunition timing in single-player.
        player.prevPos=player.pos;
        camera.previous=camera.center;
        return;
    }
    player.maxHealth=100+combat.equipment.bonusHealth();
    player.health=std::clamp(player.health,0,player.maxHealth);
    if(input.useConsumablePressed)combat.useConsumable(player);
    player.prevPos = player.pos;
    player.damageIframes=std::max(0.0f,player.damageIframes-dt);
    camera.previous = camera.center;
    if (input.jumpPressed) player.jumpBufferTimer = config.jumpBufferSeconds;
    else player.jumpBufferTimer = std::max(0.0f, player.jumpBufferTimer - dt);

    if (player.grounded) player.coyoteTimer = config.coyoteSeconds;
    else player.coyoteTimer = std::max(0.0f, player.coyoteTimer - dt);

    if (input.move > 0.15f) player.facingRight = true;
    else if (input.move < -0.15f) player.facingRight = false;

    if (input.attackPressed && !player.rolling) player.attackTimer = 0.36f;
    player.attackTimer = std::max(0.0f, player.attackTimer - dt);
    if (input.rollPressed && player.grounded && !player.rolling) {
        player.attackTimer = 0;
        player.rolling = true;
        player.rollTimer = 0;
    }
    if (player.rolling) {
        player.rollTimer += dt;
        player.vel.x = player.facingRight ? config.rollSpeed : -config.rollSpeed;
        player.invulnerable = player.damageIframes>0 || (player.rollTimer >= config.rollInvulnerabilityFrom &&
            player.rollTimer <= config.rollInvulnerabilityTo);
        if (player.rollTimer >= config.rollSeconds) {
            player.rolling = false;
            player.invulnerable = player.damageIframes>0;
        }
    } else {
        player.invulnerable=player.damageIframes>0;
        const float speedMultiplier=1.0f+combat.equipment.speedBonusPercent()/100.0f;
        const float wanted = std::clamp(input.move, -1.0f, 1.0f) * config.maxSpeed*speedMultiplier;
        const float accel = std::abs(wanted) < 0.001f ? config.deceleration :
            (player.grounded ? config.groundAcceleration : config.airAcceleration);
        player.vel.x = approach(player.vel.x, wanted, accel * dt);
    }
    if (!player.rolling && player.jumpBufferTimer > 0 && player.coyoteTimer > 0) {
        player.vel.y = -config.jumpSpeed;
        player.grounded = false;
        player.coyoteTimer = 0;
        player.jumpBufferTimer = 0;
    }
    // Short jump: releasing jump early increases downward acceleration.
    const float gravityScale = (!input.jumpHeld && player.vel.y < 0) ? 1.85f : 1.0f;
    player.vel.y = std::min(config.maxFallSpeed, player.vel.y + config.gravity * gravityScale * dt);
    const bool wasGrounded = player.grounded;
    moveWithCollisions(dt);
    if (player.grounded && !wasGrounded) player.landingTimer = 0.12f;
    else player.landingTimer = std::max(0.0f, player.landingTimer - dt);

    if(input.swapMeleePressed)combat.cycleWeapon(0);
    if(input.swapRangedPressed)combat.cycleWeapon(1);
    player.shootTimer=std::max(0.0f,player.shootTimer-dt);
    const int shotsBefore=combat.shotsFired();
    combat.tick(dt,player,world,input.attackPressed,input.shootPressed,&objects);
    if(combat.meleeActive()) {
        const int broken=objects.applyMelee(player,combat.melee,combat.attackSerial());
        if(broken>0)effects.emit(player.pos.x+(player.facingRight?22:-22),player.pos.y-22,EffectKind::Hit);
    }
    if(input.interactPressed)objects.interact(player);
    effects.tick(dt);
    for(const auto& cue:combat.feedback) {
        EffectKind kind=EffectKind::Hit;
        if(cue.type==CombatCueType::PlayerHit)kind=EffectKind::PlayerHit;
        else if(cue.type==CombatCueType::EnemyKilled)kind=EffectKind::Death;
        else if(cue.type==CombatCueType::Muzzle)kind=EffectKind::Shot;
        effects.emit(cue.x,cue.y,kind);
    }
    if(input.interactPressed)combat.collectNearby(player);
    if(combat.shotsFired()>shotsBefore)player.shootTimer=0.25f;
    if (player.rolling) player.animator.change(Animation::Roll);
    else if (player.attackTimer > 0) player.animator.change(Animation::Attack);
    else if (player.shootTimer > 0) player.animator.change(Animation::Shoot);
    else if (!player.grounded && player.vel.y < 0) player.animator.change(Animation::Jump);
    else if (!player.grounded) player.animator.change(Animation::Fall);
    else if (player.landingTimer > 0) player.animator.change(Animation::Landing);
    else if (std::abs(player.vel.x) > 12) player.animator.change(Animation::Run);
    else player.animator.change(Animation::Idle);
    player.animator.tick(dt);

    // Camera follows with a horizontal lookahead. World geometry stays unchanged.
    const float targetX = std::clamp(player.pos.x + (player.facingRight ? 55.0f : -55.0f),
        camera.viewWidth * 0.5f, std::max(camera.viewWidth * 0.5f, world.width - camera.viewWidth * 0.5f));
    const float targetY = std::clamp(player.pos.y - 70.0f,
        camera.viewHeight * 0.5f, std::max(camera.viewHeight * 0.5f, world.height - camera.viewHeight * 0.5f));
    const float smoothing = 1.0f - std::exp(-7.5f * dt);
    camera.center.x += (targetX - camera.center.x) * smoothing;
    camera.center.y += (targetY - camera.center.y) * smoothing;
}
void Simulation::moveWithCollisions(float dt) {
    player.pos.x += player.vel.x * dt;
    for (Rect solid : world.solids) {
        if (!overlaps(player.bounds(), solid)) continue;
        if (player.vel.x > 0) player.pos.x = solid.x - 9;
        else if (player.vel.x < 0) player.pos.x = solid.x + solid.w + 9;
        player.vel.x = 0;
    }
    const float previousFoot = player.pos.y;
    player.pos.y += player.vel.y * dt;
    player.grounded = false;
    for (Rect solid : world.solids) {
        if (!overlaps(player.bounds(), solid)) continue;
        if (player.vel.y >= 0 && previousFoot <= solid.y + 1.0f) {
            player.pos.y = solid.y;
            player.grounded = true;
        } else if (player.vel.y < 0) {
            player.pos.y = solid.y + solid.h + 36;
        }
        player.vel.y = 0;
    }
    for (Rect platform : world.oneWay) {
        if (player.vel.y >= 0 && previousFoot <= platform.y + 0.1f &&
            player.pos.y >= platform.y &&
            player.pos.x + 9 > platform.x && player.pos.x - 9 < platform.x + platform.w) {
            player.pos.y = platform.y;
            player.vel.y = 0;
            player.grounded = true;
        }
    }
    player.pos.x = std::clamp(player.pos.x, 24.0f, world.width - 24.0f);
}
}
