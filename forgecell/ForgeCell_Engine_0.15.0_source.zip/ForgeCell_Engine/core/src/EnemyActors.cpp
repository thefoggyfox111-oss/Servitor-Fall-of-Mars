#include "forge/Combat.hpp"
#include <algorithm>
#include <cmath>
#include <unordered_set>
#include <utility>

namespace forge {
EnemyActors::EnemyActors():actors_(&registry_){}
EnemyActors::~EnemyActors()=default;
EnemyActors::EnemyActors(const EnemyActors& src):EnemyActors(){
    for(const auto& actor:src) add(actor);
}
EnemyActors& EnemyActors::operator=(const EnemyActors& src){
    if(this==&src)return *this;
    EnemyActors pending(src);
    *this=std::move(pending);
    return *this;
}
EnemyActors::EnemyActors(EnemyActors&& src) : EnemyActors(){
    // Relocation changes handles by design. Stable IDs are retained for saves.
    for(const auto& actor:src)add(actor);
    src.clear();
}
EnemyActors& EnemyActors::operator=(EnemyActors&& src) {
    if(this==&src)return *this;
    // Reuse our registry: generation checking remains valid for old handles.
    clear();
    for(const auto& actor:src)add(actor);
    src.clear();
    return *this;
}
EnemyActors& EnemyActors::operator=(std::initializer_list<Combatant> list){
    (void)replace(std::span<const Combatant>(list.begin(),list.size()));return *this;
}
EnemyActors& EnemyActors::operator=(std::vector<Combatant> list){
    (void)replace(list);return *this;
}
bool EnemyActors::replace(std::span<const Combatant> list){
    if(list.size()>kMaxEnemies)return false;
    std::unordered_set<uint32_t> seen;
    for(const Combatant& actor:list){
        if(actor.id==0||!seen.insert(actor.id).second||
           !std::isfinite(actor.x)||!std::isfinite(actor.y)||
           !std::isfinite(actor.spawnX)||actor.maxHealth<=0||actor.maxHealth>100000||
           actor.health<0||actor.health>actor.maxHealth)return false;
    }
    // Validate first, then clear. Failed imports do not change live actors.
    clear();
    reserve(list.size());
    for(const auto& actor:list) if(!add(actor).generation)return false;
    return true;
}
EntityId EnemyActors::add(Combatant actor){
    if(size()>=kMaxEnemies||actor.id==0||handle(actor.id).generation||
       !std::isfinite(actor.x)||!std::isfinite(actor.y)||
       actor.health<0||actor.maxHealth<=0||actor.health>actor.maxHealth)return {};
    const auto entity=registry_.create();
    if(!actors_.set(entity,std::move(actor))){registry_.destroy(entity);return {};}
    return entity;
}
void EnemyActors::push_back(Combatant actor){(void)add(std::move(actor));}
bool EnemyActors::erase(EntityId entity){
    if(!registry_.alive(entity)||!actors_.remove(entity))return false;
    return registry_.destroy(entity);
}
Combatant* EnemyActors::get(EntityId entity){return actors_.get(entity);}
const Combatant* EnemyActors::get(EntityId entity) const{return actors_.get(entity);}
EntityId EnemyActors::handle(uint32_t stableId) const{
    for(const auto& entry:actors_.entries())if(entry.value.id==stableId)return entry.entity;
    return {};
}
Combatant* EnemyActors::find(uint32_t id){return get(handle(id));}
const Combatant* EnemyActors::find(uint32_t id) const{return get(handle(id));}
void EnemyActors::clear(){actors_.clear();registry_.clear();}
void EnemyActors::reserve(size_t count){
    count=std::min(count,kMaxEnemies);registry_.reserve(count);actors_.reserve(count);
}
size_t EnemyActors::size() const{return actors_.size();}
bool EnemyActors::empty() const{return size()==0;}
Combatant& EnemyActors::operator[](size_t i){return actors_.mutableEntries()[i].value;}
const Combatant& EnemyActors::operator[](size_t i) const{return actors_.entries()[i].value;}
Combatant& EnemyActors::front(){return (*this)[0];}
const Combatant& EnemyActors::front() const{return (*this)[0];}
EnemyActors::iterator EnemyActors::begin(){return {actors_.mutableEntries(),0};}
EnemyActors::iterator EnemyActors::end(){return {actors_.mutableEntries(),size()};}
EnemyActors::const_iterator EnemyActors::begin() const{return {actors_.entries(),0};}
EnemyActors::const_iterator EnemyActors::end() const{return {actors_.entries(),size()};}
}
