#include "forge/Navigation.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <queue>
#include <functional>
#include <vector>
namespace forge {
namespace {
struct Surface {float left,right,y;};
float gap(const Surface& a,const Surface& b) {
    return std::max(0.f,std::max(a.left-b.right,b.left-a.right));
}
// Ascending beside a solid overhang requires taking off beyond its side wall,
// *while still standing on the current surface*. Reject impossible links early.
struct AscentEdge { bool valid=false; float takeoff=0,landing=0; };
AscentEdge ascentEdge(const Surface& from,const Surface& to,float currentX) {
    const float leftLaunch=to.left-12.f, rightLaunch=to.right+12.f;
    const bool leftSupported=leftLaunch>=from.left+8.f && leftLaunch<=from.right-8.f;
    const bool rightSupported=rightLaunch>=from.left+8.f && rightLaunch<=from.right-8.f;
    if(!leftSupported && !rightSupported)return {};
    const bool left=leftSupported &&
        (!rightSupported || std::abs(leftLaunch-currentX)<=std::abs(rightLaunch-currentX));
    return {true,left?leftLaunch:rightLaunch,left?to.left+14.f:to.right-14.f};
}
int nearestSurface(const std::vector<Surface>& surfaces,Vec2 point) {
    float best=std::numeric_limits<float>::infinity(); int found=-1;
    for(size_t i=0;i<surfaces.size();++i) {
        const auto& s=surfaces[i];
        const float dx=std::max(0.f,std::max(s.left-point.x,point.x-s.right));
        const float dy=std::abs(s.y-point.y);
        const float score=dx*dx+dy*dy*3.f;
        if(score<best){best=score;found=static_cast<int>(i);}
    }
    return best<200.f*200.f ? found : -1;
}
}
NavigationHop planPlatformHop(const World& world,Vec2 from,Vec2 target) {
    std::vector<Surface> surfaces;
    for(const auto& b:world.solids)if(b.w>=26 && b.y>15)surfaces.push_back({b.x,b.x+b.w,b.y});
    for(const auto& b:world.oneWay)if(b.w>=26)surfaces.push_back({b.x,b.x+b.w,b.y});
    if(surfaces.empty() || surfaces.size()>512)return {};
    const int source=nearestSurface(surfaces,from),goal=nearestSurface(surfaces,target);
    if(source<0 || goal<0)return {};
    if(source==goal)return {true,false,target.x,target.x,surfaces[goal].y};
    // Weighted shortest path: penalize difficult ascents and long gaps instead
    // of choosing the first equal-hop route from the authored layer order.
    std::vector<int> previous(surfaces.size(),-1);
    std::vector<float> costs(surfaces.size(),std::numeric_limits<float>::infinity());
    using Node=std::pair<float,int>;
    std::priority_queue<Node,std::vector<Node>,std::greater<Node>> open;
    costs[source]=0.f;previous[source]=source;open.push({0.f,source});
    while(!open.empty()) {
        const auto [cost,n]=open.top();open.pop();
        if(cost>costs[n]+1e-6f)continue;
        if(n==goal)break;
        for(size_t i=0;i<surfaces.size();++i) {
            if(static_cast<int>(i)==n)continue;
            const auto& a=surfaces[n];const auto& b=surfaces[i];
            const float dy=b.y-a.y;
            const float distance=gap(a,b);
            // 355 px/s initial jump, 860 px/s² gravity, fast airborne steering.
            // Conservative bounds: avoid planning leaps our controller cannot make.
            if(dy < -72 || dy>105 || distance>(dy<-15?60.f:110.f))continue;
            // Do not put an impossible under-platform climb into the graph.
            if(dy<0.f && distance==0.f &&
               !ascentEdge(a,b,(a.left+a.right)*.5f).valid)continue;
            // Reject narrow gaps sealed by solid walls higher than the jump arc.
            // These surfaces may otherwise be connected by gap distance alone.
            if(distance>1.f) {
                const float gapL=a.right<=b.left?a.right:b.right;
                const float gapR=a.right<=b.left?b.left:a.left;
                bool sealed=false;
                for(const Rect& wall:world.solids) {
                    if(wall.x>=gapR || wall.x+wall.w<=gapL)continue;
                    if(wall.y<=std::min(a.y,b.y)-75.f &&
                       wall.y+wall.h>=std::max(a.y,b.y)-20.f) {
                        sealed=true;break;
                    }
                }
                if(sealed)continue;
            }
            const float edgeCost=1.f+distance*.045f+std::abs(dy)*.065f+
                (dy<0?1.f:0.f); // ascent requires tighter timing
            if(cost+edgeCost+1e-5f<costs[i]) {
                costs[i]=cost+edgeCost;previous[i]=n;
                open.push({costs[i],static_cast<int>(i)});
            }
        }
    }
    if(previous[goal]<0)return {};
    int next=goal;
    while(previous[next]!=source)next=previous[next];
    const auto& a=surfaces[source];const auto& b=surfaces[next];
    NavigationHop hop;hop.valid=true;hop.transition=true;hop.landingY=b.y;
    if(b.left>a.right) {
        hop.takeoffX=a.right-12;
        hop.landingX=b.left+14;
    } else if(b.right<a.left) {
        hop.takeoffX=a.left+12;
        hop.landingX=b.right-14;
    } else {
        if(b.y<a.y) {
            // Choose a supported launch point outside the target side wall.
            // The previous nearest-edge rule could select a point past the
            // current platform edge, where advanceEnemy() would refuse to walk.
            const AscentEdge edge=ascentEdge(a,b,from.x);
            if(!edge.valid)return {};
            hop.takeoffX=edge.takeoff;
            hop.landingX=edge.landing;
        } else {
            const float lo=std::max(a.left,b.left)+10,hi=std::min(a.right,b.right)-10;
            const float center=(lo<=hi)?std::clamp(from.x,lo,hi):
                (std::max(a.left,b.left)+std::min(a.right,b.right))/2;
            hop.takeoffX=center;hop.landingX=center;
        }
    }
    return hop;
}
}
