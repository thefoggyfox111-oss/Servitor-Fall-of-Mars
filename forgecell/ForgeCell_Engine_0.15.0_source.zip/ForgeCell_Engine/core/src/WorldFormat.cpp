#include "forge/WorldFormat.hpp"
#include <cmath>
#include <cstring>
#include <limits>
namespace forge {
namespace {
uint32_t uint32le(const std::byte* b) {
    return uint32_t(std::to_integer<uint8_t>(b[0])) |
        (uint32_t(std::to_integer<uint8_t>(b[1])) << 8) |
        (uint32_t(std::to_integer<uint8_t>(b[2])) << 16) |
        (uint32_t(std::to_integer<uint8_t>(b[3])) << 24);
}
uint16_t uint16le(const std::byte* b) {
    return uint16_t(std::to_integer<uint8_t>(b[0])) |
        (uint16_t(std::to_integer<uint8_t>(b[1])) << 8);
}
float float32le(const std::byte* b) {
    const uint32_t u=uint32le(b);
    float v=0;
    static_assert(sizeof(u)==sizeof(v));
    std::memcpy(&v,&u,4);
    return v;
}
}
bool loadWorldBinary(std::span<const std::byte> data, World& output, std::string& error) {
    if(data.size()<24) {error="Level header truncated"; return false;}
    const auto* b=data.data();
    if(b[0]!=std::byte{'F'} || b[1]!=std::byte{'C'} ||
       b[2]!=std::byte{'L'} || b[3]!=std::byte{'V'} || uint16le(b+4)!=1) {
        error="Invalid FCLV signature/version"; return false;
    }
    const float width=float32le(b+8), height=float32le(b+12);
    const uint32_t solidCount=uint32le(b+16), oneWayCount=uint32le(b+20);
    if(!std::isfinite(width) || !std::isfinite(height) ||
       width<640 || height<360 || width>200000 || height>200000 ||
       solidCount>30000 || oneWayCount>30000 ||
       data.size()!=24ull+(static_cast<size_t>(solidCount)+oneWayCount)*16ull) {
        error="Invalid level dimensions/counts/size"; return false;
    }
    World parsed;
    parsed.width=width;parsed.height=height;
    parsed.solids.clear();parsed.oneWay.clear();
    auto load=[&](std::vector<Rect>& out,size_t& pos,uint32_t count)->bool {
        out.reserve(count);
        for(uint32_t i=0;i<count;++i) {
            const auto r=Rect{float32le(b+pos),float32le(b+pos+4),
                              float32le(b+pos+8),float32le(b+pos+12)};
            if(!std::isfinite(r.x)||!std::isfinite(r.y)||!std::isfinite(r.w)||!std::isfinite(r.h)||
               r.w<=0 || r.h<=0) return false;
            out.push_back(r);pos+=16;
        }
        return true;
    };
    size_t pos=24;
    if(!load(parsed.solids,pos,solidCount) || !load(parsed.oneWay,pos,oneWayCount)) {
        error="Invalid collision rectangle"; return false;
    }
    output=std::move(parsed);
    error.clear();
    return true;
}
}
