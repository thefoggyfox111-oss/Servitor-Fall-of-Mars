#include "forge/AnimationFormat.hpp"
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <utility>

namespace forge {
namespace {
uint16_t u16(const std::byte* b) {
    return static_cast<uint16_t>(std::to_integer<uint8_t>(b[0]) |
       (uint16_t(std::to_integer<uint8_t>(b[1])) << 8));
}
uint32_t u32(const std::byte* b) {
    return uint32_t(std::to_integer<uint8_t>(b[0])) |
      (uint32_t(std::to_integer<uint8_t>(b[1])) << 8) |
      (uint32_t(std::to_integer<uint8_t>(b[2])) << 16) |
      (uint32_t(std::to_integer<uint8_t>(b[3])) << 24);
}
float f32(const std::byte* b) {return std::bit_cast<float>(u32(b));}
}
bool loadAnimationBinary(std::span<const std::byte> bytes, Animator& animator,std::string& error) {
    if(bytes.size()<8 || bytes[0]!=std::byte{'F'} || bytes[1]!=std::byte{'C'} ||
       bytes[2]!=std::byte{'A'} || bytes[3]!=std::byte{'N'} || u16(bytes.data()+4)!=1) {
        error="Invalid FCAN v1 header";return false;
    }
    const size_t count=u16(bytes.data()+6);
    if(count==0 || count>static_cast<size_t>(Animation::Count)) {
        error="Unsupported animation clip count";return false;
    }
    std::array<bool,static_cast<size_t>(Animation::Count)> seen {};
    std::array<SpriteClip,static_cast<size_t>(Animation::Count)> clips {};
    size_t offset=8;
    for(size_t i=0;i<count;++i) {
        if(offset+8>bytes.size()) {error="Truncated clip header";return false;}
        const auto* b=bytes.data()+offset;
        const size_t index=u16(b),frames=u16(b+2);
        const uint8_t loop=std::to_integer<uint8_t>(b[4]);
        if(index>=clips.size() || seen[index] || frames==0 || frames>4096 || loop>1 ||
           std::to_integer<uint8_t>(b[5])!=0 || u16(b+6)!=0) {
            error="Invalid animation track header";return false;
        }
        seen[index]=true;
        offset+=8;
        constexpr size_t frameBytes=8+static_cast<size_t>(AnchorId::Count)*8;
        if(frames>(bytes.size()-offset)/frameBytes) {error="Truncated animation frames";return false;}
        auto& clip=clips[index];clip.loop=(loop!=0);
        clip.frames.reserve(frames);
        for(size_t f=0;f<frames;++f) {
            auto* data=bytes.data()+offset;
            SpriteFrame frame;
            frame.seconds=f32(data);
            frame.events=u32(data+4);
            if(!std::isfinite(frame.seconds) || frame.seconds<0.001f || frame.seconds>10.0f) {
                error="Invalid frame duration";return false;
            }
            for(size_t a=0;a<static_cast<size_t>(AnchorId::Count);++a) {
                frame.anchors[a]={f32(data+8+a*8),f32(data+12+a*8)};
                if(!std::isfinite(frame.anchors[a].x) || !std::isfinite(frame.anchors[a].y) ||
                   std::abs(frame.anchors[a].x)>10000 || std::abs(frame.anchors[a].y)>10000) {
                    error="Invalid attachment coordinate";return false;
                }
            }
            clip.frames.push_back(frame);
            offset+=frameBytes;
        }
    }
    if(offset!=bytes.size()) {error="Unexpected trailing animation data";return false;}
    // Application happens only after every authored clip passes validation.
    for(size_t i=0;i<clips.size();++i) if(seen[i])
        animator.setClip(static_cast<Animation>(i),std::move(clips[i]));
    error.clear();return true;
}
}
