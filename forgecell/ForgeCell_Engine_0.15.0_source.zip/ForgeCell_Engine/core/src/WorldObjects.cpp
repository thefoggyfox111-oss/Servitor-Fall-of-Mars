#include "forge/WorldObjects.hpp"
#include "forge/Simulation.hpp"
#include "forge/Combat.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <unordered_set>

namespace forge {
namespace {
struct Reader {
    std::span<const std::byte> bytes; size_t pos=0;
    bool u8(uint8_t& out) {if(pos>=bytes.size())return false;out=std::to_integer<uint8_t>(bytes[pos++]);return true;}
    bool u16(uint16_t& out) {uint8_t a,b;if(!u8(a)||!u8(b))return false;out=uint16_t(a)|uint16_t(b)<<8;return true;}
    bool u32(uint32_t& out) {out=0;for(int n=0;n<4;++n){uint8_t b;if(!u8(b))return false;out|=uint32_t(b)<<(8*n);}return true;}
    bool f32(float& out) {uint32_t bits;if(!u32(bits))return false;std::memcpy(&out,&bits,4);return std::isfinite(out);}
};
}
WorldObjectSystem::WorldObjectSystem(const WorldObjectSystem& other) : WorldObjectSystem() {
    for(const auto& entry:other.entries())add(entry.value);
    lastCheckpoint_=other.lastCheckpoint_;
}
WorldObjectSystem& WorldObjectSystem::operator=(const WorldObjectSystem& other) {
    if(this==&other)return *this;
    clear();
    for(const auto& entry:other.entries())add(entry.value);
    lastCheckpoint_=other.lastCheckpoint_;
    return *this;
}
WorldObjectSystem::WorldObjectSystem(WorldObjectSystem&& other) noexcept :
    WorldObjectSystem(static_cast<const WorldObjectSystem&>(other)) {}
WorldObjectSystem& WorldObjectSystem::operator=(WorldObjectSystem&& other) noexcept {
    return operator=(static_cast<const WorldObjectSystem&>(other));
}
EntityId WorldObjectSystem::add(WorldObject object) {
    if(objects_.size()>=kMaxObjects || object.stableId==0 ||
       !std::isfinite(object.x)||!std::isfinite(object.y)||
       !std::isfinite(object.radius)||object.radius<4||object.radius>128||
       object.maxHealth<1||object.maxHealth>10000||object.health<0||object.health>object.maxHealth||
       static_cast<unsigned>(object.kind)>1)return {};
    for(const auto& entry:objects_.entries())if(entry.value.stableId==object.stableId)return {};
    const EntityId id=entities_.create();
    if(!objects_.set(id,std::move(object))) {entities_.destroy(id);return {};}
    return id;
}
bool WorldObjectSystem::remove(EntityId id) {
    if(!entities_.alive(id)||!objects_.remove(id))return false;
    return entities_.destroy(id);
}
void WorldObjectSystem::clear() {objects_.clear();entities_.clear();lastCheckpoint_=0;}
int WorldObjectSystem::applyMelee(const Player& p,const AttackDefinition& a,uint64_t serial) {
    if(!serial || p.health<=0 || p.rolling)return 0;
    int hits=0;
    const Rect hit=p.facingRight?Rect{p.pos.x,p.pos.y-a.height,a.reach,a.height}:
                                 Rect{p.pos.x-a.reach,p.pos.y-a.height,a.reach,a.height};
    for(auto& entry:objects_.mutableEntries()) {
        auto& o=entry.value;
        if(o.kind!=WorldObjectKind::Crate||o.health<=0||o.lastStrike==serial)continue;
        if(!overlaps(hit,Rect{o.x-o.radius*.5f,o.y-o.radius,o.radius,o.radius}))continue;
        o.lastStrike=serial;
        o.health=std::max(0,o.health-a.damage);
        ++hits;
    }
    return hits;
}
bool WorldObjectSystem::applyProjectile(EntityId entity,int damage) {
    auto* object=objects_.get(entity);
    if(!object || object->kind!=WorldObjectKind::Crate || object->health<=0 ||
       damage<=0 || damage>100000)return false;
    object->health=std::max(0,object->health-damage);
    return true;
}
bool WorldObjectSystem::interact(const Player& player) {
    if(player.health<=0)return false;
    for(auto& entry:objects_.mutableEntries()) {
        auto& o=entry.value;
        if(o.kind==WorldObjectKind::Checkpoint && std::hypot(o.x-player.pos.x,o.y-player.pos.y)<o.radius+18) {
            if(o.activated)return false;
            o.activated=true;lastCheckpoint_=o.stableId;return true;
        }
    }
    return false;
}
bool WorldObjectSystem::load(std::span<const std::byte> bytes,const World& world,std::string& error) {
    if(bytes.size()<8 || bytes.size()>8+kMaxObjects*19 || std::memcmp(bytes.data(),"FCOB",4)!=0) {
        error="Invalid FCOB header/length";return false;
    }
    Reader r{bytes,4};uint16_t version=0,count=0;
    if(!r.u16(version)||!r.u16(count)||version!=1||count>kMaxObjects||bytes.size()!=8+size_t(count)*19) {
        error="Invalid FCOB version/count";return false;
    }
    std::vector<WorldObject> pending;pending.reserve(count);
    std::unordered_set<uint32_t> ids;
    for(size_t i=0;i<count;++i) {
        WorldObject o;uint32_t id;uint8_t kind;uint16_t hp;
        if(!r.u32(id)||!r.u8(kind)||!r.f32(o.x)||!r.f32(o.y)||!r.u16(hp)||!r.f32(o.radius)||
           id==0||!ids.insert(id).second||kind>1||hp==0||hp>10000||
           o.x<0||o.x>world.width||o.y<0||o.y>world.height||o.radius<4||o.radius>128) {
            error="Invalid FCOB object fields";return false;
        }
        o.stableId=id;o.kind=static_cast<WorldObjectKind>(kind);o.health=o.maxHealth=hp;
        pending.push_back(o);
    }
    if(r.pos!=bytes.size()) {error="Trailing bytes in FCOB";return false;}
    // Validation is fully complete before replacing live entities.
    clear();
    for(const auto& item:pending)add(item);
    error.clear();return true;
}
}
