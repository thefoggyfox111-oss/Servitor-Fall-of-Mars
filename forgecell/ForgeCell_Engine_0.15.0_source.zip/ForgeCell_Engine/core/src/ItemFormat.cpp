#include "forge/Equipment.hpp"
#include <cstring>
#include <utility>
namespace forge {
namespace {
struct Reader {
 std::span<const std::byte> b;size_t at=0;
 bool u16(uint16_t& v) {if(b.size()-at<2)return false;v=0;for(unsigned j=0;j<2;++j)v|=uint16_t(std::to_integer<uint8_t>(b[at++]))<<(8*j);return true;}
 bool u32(uint32_t& v) {if(b.size()-at<4)return false;v=0;for(unsigned j=0;j<4;++j)v|=uint32_t(std::to_integer<uint8_t>(b[at++]))<<(8*j);return true;}
 bool str(std::string& v,size_t max) {uint16_t n;if(!u16(n)||!n||n>max||n>b.size()-at)return false;v.assign(reinterpret_cast<const char*>(b.data()+at),n);at+=n;return true;}
};
}
bool loadItemBinary(std::span<const std::byte> data, Equipment& equipment,std::string& error) {
 if(data.size()<8||data.size()>65536||std::memcmp(data.data(),"FCIT",4)!=0) {error="Invalid FCIT header/size";return false;}
 Reader r{data,4};uint16_t version,count;
 if(!r.u16(version)||!r.u16(count)||(version!=1 && version!=2)||count==0||count>128) {error="Invalid FCIT version/count";return false;}
 std::vector<ItemDefinition> items;items.reserve(count);
 for(unsigned i=0;i<count;++i) {
  ItemDefinition d;uint16_t k=0;uint32_t hp=0,dmg=0,armor=0,heal=0;
  if(!r.str(d.id,63)||!r.str(d.name,95)||!r.u16(k)||k>2||!r.u32(hp)||!r.u32(dmg)||!r.u32(armor)||!r.u32(heal)) {
   error="Invalid FCIT entry";return false;
  }
  if(hp>10000||dmg>10000||armor>10000||heal>10000) {error="Invalid FCIT modifiers";return false;}
  d.kind=static_cast<ItemKind>(k);d.healthBonus=static_cast<int>(hp);
  d.damageBonus=static_cast<int>(dmg);d.damageReduction=static_cast<int>(armor);d.healAmount=static_cast<int>(heal);
  if(version==2) {
   uint16_t rarity=0,level=0,speed=0;
   if(!r.u16(rarity)||!r.u16(level)||!r.u16(speed)||rarity>4||level<1||level>100||speed>100) {
    error="Invalid FCIT v2 metadata";return false;
   }
   d.rarity=static_cast<uint8_t>(rarity);d.level=level;d.speedBonusPct=speed;
  }
  items.push_back(std::move(d));
 }
 if(r.at!=data.size()||!equipment.setItems(std::move(items))) {error="FCIT duplicate, collision or trailing bytes";return false;}
 error.clear();return true;
}
}
