#include "forge/SaveSystem.hpp"
#include "forge/Simulation.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <unordered_map>
#include <unordered_set>
#include <utility>
namespace forge {
namespace {
constexpr size_t kMaxFile=256*1024;
class Writer {
public:
 std::vector<std::byte> data;
 void u8(uint8_t n) {data.push_back(static_cast<std::byte>(n));}
 void u16(uint16_t n) {for(int i=0;i<2;++i)u8(static_cast<uint8_t>(n>>(8*i)));}
 void u32(uint32_t n) {for(int i=0;i<4;++i)u8(static_cast<uint8_t>(n>>(8*i)));}
 void f32(float f) {uint32_t n=0;std::memcpy(&n,&f,4);u32(n);}
 void str(const std::string& s) {u16(static_cast<uint16_t>(s.size()));for(unsigned char c:s)u8(c);}
};
class Reader {
public:
 std::span<const std::byte> b;size_t off=0;
 bool u8(uint8_t& v) {if(off>=b.size())return false;v=std::to_integer<uint8_t>(b[off++]);return true;}
 bool u16(uint16_t& v) {v=0;for(int i=0;i<2;++i){uint8_t n;if(!u8(n))return false;v|=uint16_t(n)<<(8*i);}return true;}
 bool u32(uint32_t& v) {v=0;for(int i=0;i<4;++i){uint8_t n;if(!u8(n))return false;v|=uint32_t(n)<<(8*i);}return true;}
 bool f32(float& f) {uint32_t bits;if(!u32(bits))return false;std::memcpy(&f,&bits,4);return std::isfinite(f);}
 bool str(std::string& s) {uint16_t n;if(!u16(n)||n>63||n>b.size()-off)return false;
   s.assign(reinterpret_cast<const char*>(b.data()+off),n);off+=n;return true;}
};
uint32_t crc32(std::span<const std::byte> b) {
 uint32_t crc=0xFFFFFFFFu;
 for(std::byte c:b) {crc^=std::to_integer<uint8_t>(c);
   for(int j=0;j<8;++j)crc=(crc>>1)^(0xEDB88320u&static_cast<uint32_t>(-static_cast<int>(crc&1)));}
 return ~crc;
}

}
std::vector<std::byte> SaveCodec::encode(const Simulation& s) {
 Writer body;
 body.str("demo");
 body.f32(s.player.pos.x);body.f32(s.player.pos.y);
 body.u32(static_cast<uint32_t>(s.player.health));
 body.u8(s.player.facingRight?1:0);
 body.u32(static_cast<uint32_t>(s.combat.ammo_));
 body.u32(static_cast<uint32_t>(s.combat.magazineRemaining_));
 for(const auto& id:s.combat.equipment.equipped)body.str(id);
 for(const auto& id:s.combat.equipment.accessories)body.str(id);
 for(const auto& id:s.combat.equipment.backpack)body.str(id);
 body.u16(static_cast<uint16_t>(s.combat.enemies.size()));
 for(const auto& e:s.combat.enemies) {
  body.u32(e.id);body.f32(e.x);body.f32(e.y);
  body.u32(static_cast<uint32_t>(e.health));
  body.u16(static_cast<uint16_t>(e.bossPhase));
  body.u32(static_cast<uint32_t>(e.attacksFinished));
  body.u8(e.lootSpawned?1:0);
 }
 body.u16(static_cast<uint16_t>(s.combat.transients.pickups().size()));
 for(const auto& entry:s.combat.transients.pickups()) {
  const auto& p=entry.value;
  body.u32(p.id);body.str(p.weaponId);body.f32(p.x);body.f32(p.y);body.u8(p.collected?1:0);
 }
 // FCSV v2: stable level-object IDs, not transient ECS entity indices.
 body.u16(static_cast<uint16_t>(s.objects.size()));
 for(const auto& entry:s.objects.entries()) {
  const auto& o=entry.value;
  body.u32(o.stableId);body.u16(static_cast<uint16_t>(o.health));body.u8(o.activated?1:0);
 }
 // FCSV v3 appends instance-specific affixes; legacy slot strings remain unchanged.
 body.u16(static_cast<uint16_t>(s.combat.equipment.instances().size()));
 for(const auto& instance:s.combat.equipment.instances()) {
  body.u32(instance.uid);body.str(instance.definitionId);
  body.u16(instance.affixes.health);body.u16(instance.affixes.damage);
  body.u16(instance.affixes.defense);body.u16(instance.affixes.speedPct);
  body.u16(instance.affixes.healing);
 }
 Writer file;
 for(const char c:std::string("FCSV"))file.u8(static_cast<uint8_t>(c));
 file.u16(3);file.u16(0);file.u32(static_cast<uint32_t>(body.data.size()));
 file.u32(crc32(body.data));
 file.data.insert(file.data.end(),body.data.begin(),body.data.end());
 return file.data;
}
bool SaveCodec::decode(std::span<const std::byte> file, Simulation& s,std::string& error) {
 if(file.size()<16||file.size()>kMaxFile||std::memcmp(file.data(),"FCSV",4)!=0){error="Invalid FCSV header/size";return false;}
 Reader header{file,4};uint16_t version,flags;uint32_t size,checksum;
 if(!header.u16(version)||!header.u16(flags)||!header.u32(size)||!header.u32(checksum)||
    (version!=1 && version!=2 && version!=3)||flags!=0||size!=file.size()-16||crc32(file.subspan(16))!=checksum) {
  error="FCSV version, length or CRC mismatch";return false;
 }
 Reader r{file.subspan(16)};
 Simulation candidate=s;
 std::string level;
 uint32_t health=0,ammo=0,magazine=0;
 uint8_t facing=0;
 if(!r.str(level)||level!="demo"||!r.f32(candidate.player.pos.x)||!r.f32(candidate.player.pos.y)||
    !r.u32(health)||!r.u8(facing)||!r.u32(ammo)||!r.u32(magazine)||facing>1||
    candidate.player.pos.x<18||candidate.player.pos.x>candidate.world.width-18||
    candidate.player.pos.y<32||candidate.player.pos.y>candidate.world.height+20||
    health>100000||ammo>100000||magazine>1000||magazine>ammo) {
  error="Invalid player checkpoint";return false;
 }
 const Rect playerBounds{candidate.player.pos.x-9,candidate.player.pos.y-36,18,36};
 for(const auto& b:candidate.world.solids)if(overlaps(playerBounds,b)) {
  error="Saved player overlaps solid";return false;
 }
 for(auto& id:candidate.combat.equipment.equipped)if(!r.str(id)){
  error="Invalid equipped weapon";return false;
 }
 for(auto& id:candidate.combat.equipment.accessories)if(!r.str(id)){
  error="Invalid accessory";return false;
 }
 for(auto& id:candidate.combat.equipment.backpack)if(!r.str(id)){
  error="Invalid backpack";return false;
 }
 const auto& eq=candidate.combat.equipment;
 uint16_t enemyCount=0;
 if(!r.u16(enemyCount)||enemyCount!=candidate.combat.enemies.size()||enemyCount>128) {
  error="Enemy catalog does not match save";return false;
 }
 std::unordered_map<uint32_t,Combatant*> enemies;
 for(auto& e:candidate.combat.enemies) {
  if(!enemies.emplace(e.id,&e).second){error="Duplicate enemy IDs in world";return false;}
 }
 std::unordered_set<uint32_t> seen;
 for(unsigned i=0;i<enemyCount;++i) {
  uint32_t id,hp,attacks;uint16_t phase;uint8_t looted;float x,y;
  if(!r.u32(id)||!r.f32(x)||!r.f32(y)||!r.u32(hp)||!r.u16(phase)||!r.u32(attacks)||!r.u8(looted)||
     !enemies.contains(id)||!seen.insert(id).second||
     hp>static_cast<uint32_t>(enemies[id]->maxHealth)||phase<1||phase>2||attacks>1000000||looted>1||
     x<15||x>candidate.world.width-15||y<34||y>candidate.world.height+20){
    error="Invalid enemy checkpoint/catalog";return false;
  }
  auto& e=*enemies[id];e.x=x;e.y=y;e.health=static_cast<int>(hp);e.alive=hp>0;
  e.bossPhase=static_cast<int>(phase);e.attacksFinished=static_cast<int>(attacks);
  e.lootSpawned=looted!=0;
 }
 uint16_t pickupCount=0;
 if(!r.u16(pickupCount)||pickupCount>1024){error="Too many pickup records";return false;}
 std::vector<Pickup> pickups;pickups.reserve(pickupCount);
 std::unordered_set<uint32_t> pickupIds;
 for(unsigned i=0;i<pickupCount;++i) {
  Pickup p;uint8_t collected=0;
  if(!r.u32(p.id)||!r.str(p.weaponId)||!r.f32(p.x)||!r.f32(p.y)||!r.u8(collected)||
     p.id==0||p.id>=0xFFFFFFFEu||!pickupIds.insert(p.id).second||collected>1||
     p.x<0||p.x>candidate.world.width||p.y<0||p.y>candidate.world.height+20) {
   error="Invalid pickup in save";return false;
  }
  p.collected=collected!=0;pickups.push_back(std::move(p));
 }
 if(version>=2) {
  uint16_t count=0;
  if(!r.u16(count)||count!=candidate.objects.size()) {
   error="Scene objects differ from FCSV v2";return false;
  }
  std::unordered_map<uint32_t,WorldObject*> byId;
  for(auto& entry:candidate.objects.objects_.mutableEntries()) {
   if(!byId.emplace(entry.value.stableId,&entry.value).second) {
    error="Duplicate stable scene object";return false;
   }
  }
  std::unordered_set<uint32_t> seenObjects;
  uint32_t lastCheckpoint=0;
  for(size_t i=0;i<count;++i) {
   uint32_t id=0;uint16_t hp=0;uint8_t active=0;
   if(!r.u32(id)||!r.u16(hp)||!r.u8(active)||active>1||!byId.contains(id)||
      !seenObjects.insert(id).second||hp>byId[id]->maxHealth ||
      (byId[id]->kind==WorldObjectKind::Checkpoint && hp==0)) {
    error="Invalid FCSV v2 scene object";return false;
   }
   auto* object=byId[id];object->health=hp;object->activated=active!=0;
   if(object->activated && object->kind==WorldObjectKind::Checkpoint)lastCheckpoint=id;
  }
  candidate.objects.lastCheckpoint_=lastCheckpoint;
 }
 if(version==3) {
  uint16_t instanceCount=0;
  if(!r.u16(instanceCount) || instanceCount>Equipment::kMaxInstances) {
   error="FCSV v3 invalid instance count";return false;
  }
  std::vector<ItemInstance> records;records.reserve(instanceCount);
  for(size_t i=0;i<instanceCount;++i) {
   ItemInstance item;
   if(!r.u32(item.uid)||!r.str(item.definitionId)||
      !r.u16(item.affixes.health)||!r.u16(item.affixes.damage)||
      !r.u16(item.affixes.defense)||!r.u16(item.affixes.speedPct)||
      !r.u16(item.affixes.healing)) {
    error="Truncated item instance in FCSV v3";return false;
   }
   records.push_back(std::move(item));
  }
  if(!candidate.combat.equipment.restoreInstances(std::move(records))) {
   error="Invalid item instance catalog";return false;
  }
 } else {
  // Never retain instances from a newer in-memory game when loading old saves.
  candidate.combat.equipment.restoreInstances({});
 }
 if(!eq.validReferences()) {
  error="Unresolved or incorrectly equipped save items";return false;
 }
 // Every physical instance can belong to exactly one container or pickup.
 std::unordered_set<std::string> instanceOwnership;
 auto uniqueToken=[&](const std::string& token)->bool {
  return token.empty() || token[0]!='~' ||
     (eq.instance(token) && instanceOwnership.insert(token).second);
 };
 for(const auto& token:eq.equipped)if(!uniqueToken(token)) {
  error="Duplicate equipped instance";return false;
 }
 for(const auto& token:eq.accessories)if(!uniqueToken(token)) {
  error="Duplicate accessory instance";return false;
 }
 for(const auto& token:eq.backpack)if(!uniqueToken(token)) {
  error="Duplicate inventory instance";return false;
 }
 for(const auto& item:pickups) {
  // Collected records are tombstones kept for backward-compatible saves.
  // Ownership moved into the inventory, so they must not claim it twice.
  if(item.collected)continue;
  if((!eq.find(item.weaponId) && !eq.findItem(item.weaponId)) || !uniqueToken(item.weaponId)) {
   error="Unknown or duplicated pickup item";return false;
  }
 }
 if(magazine>static_cast<uint32_t>(eq.slot(1)->magazine)) {
  error="Saved magazine exceeds equipped capacity";return false;
 }
 const int maxHealth=100+eq.bonusHealth();
 if(health>static_cast<uint32_t>(maxHealth)) {
  error="Saved health exceeds equipment maximum";return false;
 }
 if(r.off!=r.b.size()) {error="Trailing save bytes";return false;}
 candidate.player.health=static_cast<int>(health);candidate.player.maxHealth=maxHealth;
 candidate.player.facingRight=facing!=0;
 candidate.player.vel={};candidate.player.prevPos=candidate.player.pos;
 candidate.player.grounded=false;candidate.player.rolling=false;
 candidate.player.damageIframes=0;candidate.player.invulnerable=false;
 candidate.player.rollTimer=0;candidate.player.jumpBufferTimer=0;candidate.player.coyoteTimer=0;
 candidate.player.attackTimer=0;candidate.player.shootTimer=0;
 candidate.player.animator.change(Animation::Idle);
 candidate.combat.ammo_=static_cast<int>(ammo);
 candidate.combat.magazineRemaining_=static_cast<int>(magazine);
 if(!candidate.combat.transients.replacePickups(pickups)) {
  error="Unable to restore ECS pickups";return false;
 }
 candidate.combat.pickupsCollected=static_cast<int>(std::count_if(
   candidate.combat.transients.pickups().begin(),candidate.combat.transients.pickups().end(),
   [](const TransientEntities::PickupEntry& entry){return entry.value.collected;}));
 candidate.combat.restoreCheckpointTimers();
 const auto* weapon=eq.slot(0);
 candidate.combat.melee={weapon->startup,weapon->active,weapon->recovery,weapon->reach,
     weapon->hitHeight,eq.weaponDamage(0),weapon->knockback};
 candidate.inventoryOpen=false;candidate.inventorySelected=0;candidate.inventorySelectionArmed=false;
 candidate.effects.clear(); // never restore transient VFX from checkpoints
 candidate.camera.center.x=std::clamp(candidate.player.pos.x+(candidate.player.facingRight?55.f:-55.f),
     candidate.camera.viewWidth*.5f,
     std::max(candidate.camera.viewWidth*.5f,candidate.world.width-candidate.camera.viewWidth*.5f));
 candidate.camera.center.y=std::clamp(candidate.player.pos.y-70.f,
     candidate.camera.viewHeight*.5f,
     std::max(candidate.camera.viewHeight*.5f,candidate.world.height-candidate.camera.viewHeight*.5f));
 candidate.camera.previous=candidate.camera.center;
 s=std::move(candidate);error.clear();return true;
}
bool saveCheckpoint(const std::string& path,const Simulation& s,std::string& error) {
 if(path.empty()||path.size()>2048){error="Invalid save path";return false;}
 const auto payload=SaveCodec::encode(s);
 if(payload.size()>kMaxFile){error="Checkpoint too large";return false;}
 const std::string temp=path+".tmp";
 const int fd=open(temp.c_str(),O_WRONLY|O_CREAT|O_TRUNC|O_CLOEXEC,0600);
 if(fd<0){error="Unable to open temporary save";return false;}
 bool ok=true;
 size_t offset=0;
 while(offset<payload.size()) {
  const auto n=write(fd,payload.data()+offset,payload.size()-offset);
  if(n<0 && errno==EINTR)continue;
  if(n<=0){ok=false;break;}
  offset+=static_cast<size_t>(n);
 }
 if(ok && fsync(fd)!=0)ok=false;
 if(close(fd)!=0)ok=false;
 if(ok && rename(temp.c_str(),path.c_str())==0) {
   // Persist the directory rename when the underlying filesystem supports it.
   const auto slash=path.find_last_of('/');
   if(slash!=std::string::npos) {
      const auto directory=path.substr(0,slash);
      const int dirfd=open(directory.c_str(),O_RDONLY|O_DIRECTORY|O_CLOEXEC);
      if(dirfd>=0){(void)fsync(dirfd);(void)close(dirfd);}
   }
   error.clear();return true;
 }
 unlink(temp.c_str());error="Checkpoint write/sync/rename failed";return false;
}
bool loadCheckpoint(const std::string& path,Simulation& s,std::string& error) {
 if(path.empty()||path.size()>2048){error="Invalid save path";return false;}
 const int fd=open(path.c_str(),O_RDONLY|O_CLOEXEC);
 if(fd<0){error="Checkpoint not found";return false;}
 std::vector<std::byte> blob;
 std::array<std::byte,4096> buffer;
 bool ok=true;
 while(true) {
  const auto n=read(fd,buffer.data(),buffer.size());
  if(n<0 && errno==EINTR)continue;
  if(n<0){ok=false;break;}
  if(n==0)break;
  if(blob.size()+static_cast<size_t>(n)>kMaxFile){ok=false;break;}
  blob.insert(blob.end(),buffer.begin(),buffer.begin()+n);
 }
 close(fd);
 if(!ok){error="Checkpoint read failure/oversize";return false;}
 return SaveCodec::decode(blob,s,error);
}
}
