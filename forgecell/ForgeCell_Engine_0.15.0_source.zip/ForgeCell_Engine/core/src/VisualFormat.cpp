#include "forge/VisualFormat.hpp"
#include <cstring>
namespace forge {
bool decodeVisualBinary(std::span<const std::byte> b,VisualCatalog& out,std::string& error){
    if(b.size()<12||b.size()>12+VisualCatalog::kMaxArchetypes*18||
       std::memcmp(b.data(),"FCVA",4)!=0){error="FCVA header/size invalid";return false;}
    size_t at=4;
    auto u16=[&](uint16_t& x)->bool{
        if(at+2>b.size())return false;
        x=uint16_t(std::to_integer<uint8_t>(b[at]))|
          (uint16_t(std::to_integer<uint8_t>(b[at+1]))<<8);
        at+=2;return true;
    };
    uint16_t version=0,count=0,w=0,h=0;
    if(!u16(version)||!u16(count)||!u16(w)||!u16(h)||version!=1||
       count==0||count>VisualCatalog::kMaxArchetypes||w<32||h<32||w>8192||h>8192){
        error="FCVA invalid version/count/atlas dimensions";return false;
    }
    VisualCatalog candidate;candidate.atlasWidth=w;candidate.atlasHeight=h;
    for(unsigned i=0;i<count;++i){
        uint16_t slot=0,px=0,py=0,fw=0,fh=0,frames=0,animations=0;
        uint16_t footX=0,footY=0;
        if(!u16(slot)||!u16(px)||!u16(py)||!u16(fw)||!u16(fh)||
           !u16(frames)||!u16(animations)||!u16(footX)||!u16(footY)||
           slot>=VisualCatalog::kMaxArchetypes||candidate.styles[slot].valid||
           fw<1||fh<1||fw>512||fh>512||frames<1||frames>4096||
           animations<1||animations>32||
           uint64_t(px)+uint64_t(fw)*frames>w||
           uint64_t(py)+uint64_t(fh)*animations>h||
           static_cast<int16_t>(footX)<-512||static_cast<int16_t>(footX)>512||
           static_cast<int16_t>(footY)<-512||static_cast<int16_t>(footY)>512){
            error="FCVA invalid or duplicate sprite bounds/slot";return false;
        }
        candidate.styles[slot]={px,py,fw,fh,frames,animations,
            static_cast<int16_t>(footX),static_cast<int16_t>(footY),true};
    }
    if(at!=b.size()||!candidate.get(0)){error="FCVA trailing bytes or missing hero";return false;}
    out=std::move(candidate);error.clear();return true;
}
}
