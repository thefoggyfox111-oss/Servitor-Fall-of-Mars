#include "forge/TouchControls.hpp"
#include <cmath>
namespace forge {
Vec2 TouchControls::buttonCenter(Control c, float w, float h) {
    switch (c) {
        case Control::Move: return {90, h - 60};
        case Control::Jump: return {w - 73, h - 68};
        case Control::Roll: return {w - 152, h - 42};
        case Control::Attack: return {w - 126, h - 120};
        case Control::Shoot: return {w - 51, h - 175};
        case Control::SwapMelee: return {w - 170, 45};
        case Control::SwapRanged: return {w - 91, 45};
        case Control::Inventory: return {w*0.5f, 28};
        case Control::Interact: return {w - 237, h - 118};
        case Control::UseConsumable: return {w - 233, h - 205};
        case Control::Drop: return {w*0.5f+150, 270};
        case Control::Sort: return {w*0.5f-150, 270};
        default: return {};
    }
}
void TouchControls::resize(float w, float h) {width_ = w; height_ = h;}
int TouchControls::backpackAt(float x,float y) const {
    const float left=width_*0.5f-114.f,top=79.f;
    if(x<left || x>=left+228.f || y<top || y>=top+152.f)return -1;
    return static_cast<int>((y-top)/38.f)*6+static_cast<int>((x-left)/38.f);
}
int TouchControls::equipmentAt(float x,float y) const {
    const float left=width_*0.5f+135.f, top=79.f;
    if(x<left||x>=left+26.f||y<top||y>=top+6*27.f)return -1;
    return static_cast<int>((y-top)/27.f);
}
Control TouchControls::hit(float x, float y) const {
    const auto inventory=buttonCenter(Control::Inventory,width_,height_);
    if(std::abs(x-inventory.x)<30 && std::abs(y-inventory.y)<26)return Control::Inventory;
    if(inventoryOpen_) {
        const auto drop=buttonCenter(Control::Drop,width_,height_);
        if(std::abs(x-drop.x)<27 && std::abs(y-drop.y)<27)return Control::Drop;
        const auto sort=buttonCenter(Control::Sort,width_,height_);
        if(std::abs(x-sort.x)<25 && std::abs(y-sort.y)<25)return Control::Sort;
        if(backpackAt(x,y)>=0)return Control::InventoryCell;
        if(equipmentAt(x,y)>=0)return Control::EquipmentSlot;
        return Control::None;
    }
    if (x < width_ * 0.39f && y > height_ * 0.46f) return Control::Move;
    for (Control c : {Control::Jump, Control::Roll, Control::Attack, Control::Shoot, Control::SwapMelee, Control::SwapRanged, Control::Interact, Control::UseConsumable}) {
        const auto p = buttonCenter(c, width_, height_);
        const float dx = x - p.x, dy = y - p.y;
        if (dx * dx + dy * dy < 42.0f * 42.0f) return c;
    }
    return Control::None;
}
void TouchControls::pointerDown(int32_t id, float x, float y) {
    for (auto& p : pointers_) if (!p.active) {
        p = {id, {x, y}, {x,y}, hit(x, y), true};
        if (p.control == Control::Jump) jumpPending_ = true;
        if (p.control == Control::Roll) rollPending_ = true;
        if (p.control == Control::Attack) attackPending_ = true;
        if (p.control == Control::Shoot) shootPending_ = true;
        if (p.control == Control::SwapMelee) swapMeleePending_ = true;
        if (p.control == Control::SwapRanged) swapRangedPending_ = true;
        if (p.control == Control::Inventory) inventoryPending_ = true;
        if (p.control == Control::Interact) interactPending_ = true;
        if (p.control == Control::UseConsumable) consumablePending_ = true;
        if (p.control == Control::Drop) dropPending_ = true;
        if (p.control == Control::Sort) sortPending_ = true;
        // Delay inventory clicks until pointer-up so a drag does not equip first.
        // The same pointer owns the drag; other fingers cannot interfere.

        return;
    }
}
void TouchControls::pointerMove(int32_t id, float x, float y) {
    for (auto& p : pointers_) if (p.active && p.id == id) {p.at = {x, y}; return;}
}
void TouchControls::pointerUp(int32_t id, float x,float y) {
    for (auto& p : pointers_) if (p.active && p.id == id) {
        if(inventoryOpen_) {
            const int sourceCell=backpackAt(p.origin.x,p.origin.y);
            const int downCell=p.control==Control::InventoryCell?sourceCell:-1;
            const int downSlot=p.control==Control::EquipmentSlot?equipmentAt(p.origin.x,p.origin.y):-1;
            const int targetCell=backpackAt(x,y), targetSlot=equipmentAt(x,y);
            if(downCell>=0) {
                if(targetCell==downCell) selectedCellPending_=downCell;
                else if(targetCell>=0) {moveFromPending_=downCell;moveToPending_=targetCell;}
                else if(targetSlot>=0) {moveFromPending_=downCell;equipSlotPending_=targetSlot;}
            } else if(downSlot>=0 && targetCell>=0) {
                unequipSlotPending_=downSlot;unequipToPending_=targetCell;
            }
        }
        p.active=false;return;
    }
}
void TouchControls::pointerUp(int32_t id) {
    for(const auto& p:pointers_)if(p.active&&p.id==id) {
        pointerUp(id,p.at.x,p.at.y);return;
    }
}
std::optional<InventoryDrag> TouchControls::inventoryDrag() const {
    if(!inventoryOpen_)return std::nullopt;
    for(const auto& p:pointers_) {
        if(!p.active || (p.control!=Control::InventoryCell && p.control!=Control::EquipmentSlot))continue;
        const float dx=p.at.x-p.origin.x,dy=p.at.y-p.origin.y;
        if(dx*dx+dy*dy<36.0f)continue;
        InventoryDrag drag;
        if(p.control==Control::InventoryCell)drag.fromCell=backpackAt(p.origin.x,p.origin.y);
        else drag.fromSlot=equipmentAt(p.origin.x,p.origin.y);
        drag.toCell=backpackAt(p.at.x,p.at.y);
        drag.toSlot=equipmentAt(p.at.x,p.at.y);
        drag.position=p.at;
        return drag;
    }
    return std::nullopt;
}
void TouchControls::clear() {
    for (auto& p : pointers_) p.active = false;
    jumpPending_ = rollPending_ = attackPending_ = shootPending_ = swapMeleePending_ = swapRangedPending_ = false;
    inventoryPending_=interactPending_=consumablePending_=dropPending_=sortPending_=false;selectedCellPending_=-1;
    moveFromPending_=moveToPending_=equipSlotPending_=unequipSlotPending_=unequipToPending_=-1;
}
Input TouchControls::sample() {
    Input result;
    result.jumpPressed = jumpPending_;
    result.rollPressed = rollPending_;
    result.attackPressed = attackPending_;
    result.shootPressed = shootPending_;
    result.swapMeleePressed = swapMeleePending_;
    result.swapRangedPressed = swapRangedPending_;
    result.inventoryPressed=inventoryPending_;
    result.interactPressed=interactPending_;
    result.useConsumablePressed=consumablePending_;
    result.dropSelectedPressed=dropPending_;
    result.sortInventoryPressed=sortPending_;
    result.inventoryIndex=selectedCellPending_;
    result.inventoryMoveFrom=moveFromPending_;result.inventoryMoveTo=moveToPending_;
    result.inventoryEquipSlot=equipSlotPending_;
    result.inventoryUnequipSlot=unequipSlotPending_;result.inventoryUnequipTo=unequipToPending_;
    jumpPending_ = rollPending_ = attackPending_ = shootPending_ = swapMeleePending_ = swapRangedPending_ = false;
    inventoryPending_=interactPending_=consumablePending_=dropPending_=sortPending_=false;selectedCellPending_=-1;
    moveFromPending_=moveToPending_=equipSlotPending_=unequipSlotPending_=unequipToPending_=-1;
    const Vec2 stick = buttonCenter(Control::Move, width_, height_);
    for (const auto& p : pointers_) {
        if (!p.active) continue;
        if (p.control == Control::Move) result.move = std::clamp((p.at.x - stick.x) / 47.0f, -1.0f, 1.0f);
        if (p.control == Control::Jump) result.jumpHeld = true;
    }
    return result;
}
}
