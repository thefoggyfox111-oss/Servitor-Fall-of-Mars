#include "forge/Combat.hpp"
#include "forge/Simulation.hpp"
#include "forge/Navigation.hpp"
#include "forge/EnemyFormat.hpp"
#include "forge/AnimationFormat.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <utility>

namespace forge {
namespace {
float segmentBox(float x0,float y0,float x1,float y1,Rect b,float radius) {
    b.x-=radius;b.y-=radius;b.w+=2*radius;b.h+=2*radius;
    float low=0,high=1;
    for(int axis=0;axis<2;++axis) {
        const float pos=axis?y0:x0,delta=axis?y1-y0:x1-x0;
        const float min=axis?b.y:b.x,max=min+(axis?b.h:b.w);
        if(std::abs(delta)<1e-8f) {
            if(pos<min || pos>max)return std::numeric_limits<float>::infinity();
        } else {
            float t1=(min-pos)/delta,t2=(max-pos)/delta;
            if(t1>t2)std::swap(t1,t2);
            low=std::max(low,t1);high=std::min(high,t2);
            if(low>high)return std::numeric_limits<float>::infinity();
        }
    }
    return low;
}
Rect enemyBox(const Combatant& e) {return {e.x-10,e.y-34,20,34};}
float attackRange(const Combatant& e) {if(e.attackRangeOverride>0 && !(e.role==EnemyRole::Boss && e.bossPhase==2 && e.attacksFinished%2==1))return e.attackRangeOverride;return e.role==EnemyRole::Gunner?230.0f:e.role==EnemyRole::Boss?(e.bossPhase==2 && e.attacksFinished%2==1?165.0f:52.0f):e.role==EnemyRole::Heavy?42.0f:31.0f;}
float attackStartup(const Combatant& e) {if(e.attackStartupOverride>0 && !(e.role==EnemyRole::Boss && e.bossPhase==2))return e.attackStartupOverride;return e.role==EnemyRole::Boss?(e.bossPhase==2?.29f:.55f):e.role==EnemyRole::Heavy?.50f:e.role==EnemyRole::Gunner?.36f:.28f;}
float attackActive(const Combatant& e) {if(e.attackActiveOverride>0)return e.attackActiveOverride;return e.role==EnemyRole::Boss?.22f:e.role==EnemyRole::Heavy?.18f:.12f;}
float attackRecovery(const Combatant& e) {if(e.attackRecoveryOverride>0 && !(e.role==EnemyRole::Boss && e.bossPhase==2))return e.attackRecoveryOverride;return e.role==EnemyRole::Boss?(e.bossPhase==2?.35f:.65f):e.role==EnemyRole::Heavy?.70f:e.role==EnemyRole::Gunner?.67f:.48f;}
}
void CombatSystem::setEnemyState(Combatant& e,EnemyState state) {
    if(e.state==state)return;
    e.state=state;e.stateTime=0;e.attackApplied=false;
}
void CombatSystem::setAmmo(int count) {
    ammo_=std::clamp(count,0,100000);
    const auto* d=equipment.slot(1);
    magazineRemaining_=std::min(ammo_,d?d->magazine:12);
    reloadTimer_=0;
}
void CombatSystem::reload() {
    const auto* w=equipment.slot(1);
    if(!w || ammo_<=magazineRemaining_ || reloadTimer_>0)return;
    reloadTimer_=w->reloadSeconds;
}
bool CombatSystem::equipFromBackpack(size_t bagIndex,size_t slotIndex) {
    if(attacking() && slotIndex==0)return false;
    if(!equipment.equipFromBackpack(bagIndex,slotIndex))return false;
    if(slotIndex==0) {
        const auto* w=equipment.slot(0);
        melee={w->startup,w->active,w->recovery,w->reach,w->hitHeight,equipment.weaponDamage(0),w->knockback};
    } else {
        const auto* w=equipment.slot(1);
        magazineRemaining_=std::min(ammo_,w->magazine);
        reloadTimer_=0;shootCooldown_=0;
    }
    return true;
}
bool CombatSystem::cycleWeapon(size_t slotIndex) {
    if(slotIndex>1)return false;
    for(size_t i=0;i<equipment.backpack.size();++i) {
        const auto* weapon=equipment.find(equipment.backpack[i]);
        if(weapon && weapon->kind==(slotIndex==0?WeaponKind::Melee:WeaponKind::Ranged))
            return equipFromBackpack(i,slotIndex);
    }
    return false;
}
bool CombatSystem::loadEquipment(std::span<const std::byte> bytes,std::string& error) {
    Equipment candidate=equipment;
    if(!loadWeaponBinary(bytes,candidate,error))return false;
    equipment=std::move(candidate);
    const auto* w=equipment.slot(0);
    melee={w->startup,w->active,w->recovery,w->reach,w->hitHeight,equipment.weaponDamage(0),w->knockback};
    magazineRemaining_=std::min(ammo_,equipment.slot(1)->magazine);
    reloadTimer_=shootCooldown_=0;
    return true;
}
bool CombatSystem::loadEnemies(std::span<const std::byte> b,const World& world,std::string& error) {
    std::vector<Combatant> candidates;
    if(!decodeEnemyBinary(b,candidates,error))return false;
    for(const auto& e:candidates) {
        if(e.x<20 || e.x>world.width-20 || e.y<34 || e.y>world.height+30) {
            error="Enemy spawn outside playable world";return false;
        }
        const Rect candidateBox{e.x-10,e.y-34,20,34};
        for(const auto& solid:world.solids)
            if(overlaps(candidateBox,solid)) {error="Enemy spawn overlaps solid";return false;}
        if(!e.lootId.empty() && !equipment.find(e.lootId) && !equipment.findItem(e.lootId)) {
            error="Enemy loot references unknown item";return false;
        }
    }
    for(auto& enemy:candidates) enemy.animator=enemyAnimationProfiles_[static_cast<size_t>(enemy.role)];
    if(!enemies.replace(candidates)){error="Enemy ECS allocation/validation failed";return false;}
    transients.clear();pickupsCollected=0;
    error.clear();return true;
}
bool CombatSystem::loadEnemyAnimation(EnemyRole role, std::span<const std::byte> bytes, std::string& error) {
    const auto index=static_cast<size_t>(role);
    if(index>=enemyAnimationProfiles_.size()) {error="Invalid enemy role";return false;}
    Animator candidate=enemyAnimationProfiles_[index];
    if(!loadAnimationBinary(bytes,candidate,error))return false;
    enemyAnimationProfiles_[index]=candidate;
    for(auto& e:enemies) if(e.role==role) e.animator=candidate;
    return true;
}
void CombatSystem::restoreCheckpointTimers() {
    transients.clearProjectiles();struck_.clear();
    navigationQueries=0;
    meleeElapsed_=-1;reloadTimer_=0;shootCooldown_=0;
    playerDamageEvents=enemyAttackEvents=damageEvents=reloadEvents=0;
    for(auto& e:enemies) {
        e.state=e.alive?EnemyState::Idle:EnemyState::Dead;
        e.stateTime=0;e.stunTime=0;e.attackCooldown=0;e.aggroMemory=0;
        e.attackApplied=false;e.vx=e.vy=0;e.airborne=false;
        e.previousX=e.x;e.previousY=e.y;
        e.animator.change(e.alive?Animation::Idle:Animation::Fall);
    }
}
bool CombatSystem::loadItems(std::span<const std::byte> bytes,std::string& error) {
    Equipment candidate=equipment;
    if(!loadItemBinary(bytes,candidate,error))return false;
    for(const auto& item:candidate.itemDefinitions) {
        bool existing=false;
        for(const auto& id:candidate.backpack)if(id==item.id)existing=true;
        for(const auto& id:candidate.accessories)if(id==item.id)existing=true;
        if(!existing)candidate.addToBackpack(item.id); // demo startup items
    }
    equipment=std::move(candidate);return true;
}
bool CombatSystem::useConsumable(Player& player) {
    if(player.health<=0 || player.health>=player.maxHealth)return false;
    const int heal=equipment.useConsumable();
    if(heal<=0)return false;
    player.health=std::min(player.maxHealth,player.health+heal);
    return true;
}
void CombatSystem::resetDemo() {
    enemies.clear();transients.clear();struck_.clear();feedback.clear();pickupsCollected=0;
    enemies.reserve(128);
    feedback.reserve(64);struck_.reserve(16);
    auto spawn=[&](uint32_t id,float x,EnemyRole role,int hp) {
        Combatant e;
        e.id=id;e.x=e.previousX=e.spawnX=x;e.y=e.previousY=e.spawnY=294;e.role=role;
        e.health=e.maxHealth=hp;
        e.facingRight=false;
        e.animator=enemyAnimationProfiles_[static_cast<size_t>(role)];
        enemies.push_back(std::move(e));
    };
    spawn(1,335,EnemyRole::Grunt,80);
    spawn(2,760,EnemyRole::Heavy,170);
    spawn(3,1260,EnemyRole::Gunner,70);
    spawn(4,1680,EnemyRole::Grunt,95);
    spawn(5,1830,EnemyRole::Boss,350);
    ammo_=60;shotsFired_=damageEvents=playerDamageEvents=enemyAttackEvents=reloadEvents=0;
    shootCooldown_=reloadTimer_=0;meleeElapsed_=-1;nextProjectileId_=1;navigationQueries=0;
    equipment=Equipment{};
    melee={};activeMelee_=melee;
    magazineRemaining_=equipment.slot(1)->magazine;
}
bool CombatSystem::meleeActive() const {
    return meleeElapsed_>=activeMelee_.startup && meleeElapsed_<activeMelee_.startup+activeMelee_.active;
}
void CombatSystem::meleeHits(Player& player) {
    if(!meleeActive())return;
    const Rect hit={swingRight_?player.pos.x:player.pos.x-activeMelee_.reach,
                    player.pos.y-31,activeMelee_.reach,activeMelee_.height};
    for(auto& e:enemies) {
        if(!e.alive || std::find(struck_.begin(),struck_.end(),e.id)!=struck_.end())continue;
        if(!overlaps(hit,enemyBox(e)))continue;
        struck_.push_back(e.id);
        e.health=std::max(0,e.health-(activeMelee_.damage+equipment.bonusDamage()));
        e.alive=e.health>0;e.hitFlash=.16f;
        e.vx=swingRight_?activeMelee_.knockback:-activeMelee_.knockback;
        if(!e.alive)onEnemyKilled(e);
        else if(e.role!=EnemyRole::Dummy) {
            e.stunTime=e.role==EnemyRole::Heavy?.07f:.22f;
            setEnemyState(e,EnemyState::Stunned);
        }
        feedback.push_back({e.x,e.y-23,CombatCueType::EnemyHit});
        ++damageEvents;
    }
}
void CombatSystem::damagePlayer(Player& player,int damage,float push) {
    if(player.health<=0 || player.invulnerable || player.damageIframes>0)return;
    player.health=std::max(0,player.health-std::max(1,damage-equipment.damageReduction()));
    player.damageIframes=.55f;
    player.invulnerable=true;
    player.vel.x=push;
    feedback.push_back({player.pos.x,player.pos.y-24,CombatCueType::PlayerHit});
    ++playerDamageEvents;
}
void CombatSystem::onEnemyKilled(Combatant& e) {
    setEnemyState(e,EnemyState::Dead);
    feedback.push_back({e.x,e.y-18,CombatCueType::EnemyKilled});
    if(e.lootSpawned)return;
    e.lootSpawned=true;
    const std::string id=!e.lootId.empty()?e.lootId:
        (e.role==EnemyRole::Boss?"rifle":e.role==EnemyRole::Heavy?"heavy_axe":"");
    if(id.empty() || (!equipment.find(id) && !equipment.findItem(id)))return;
    const auto rolled=lootTable.roll(e.id,static_cast<uint8_t>(e.role));
    if(!rolled)return; // Chance is based on stable enemy ID, not simulation tick.
    // World drops own unique item copies so no pre-existing backpack slot is needed.
    const std::string token=equipment.createWorldInstance(id,*rolled);
    if(token.empty())return; // Prevent missing drops from exhausting the instance pool.
    if(!transients.addPickup({e.id,token,e.x,e.y-12,false}).generation)
        equipment.rollbackWorldInstance(token);
}
bool CombatSystem::collectNearby(const Player& player,float radius) {
    if(!std::isfinite(radius) || radius<=0)return false;
    for(auto& entry:transients.mutablePickups()) {
        auto& pickup=entry.value;
        if(pickup.collected || std::abs(player.pos.x-pickup.x)>radius ||
           std::abs(player.pos.y-pickup.y)>radius+16)continue;
        if(!equipment.addToBackpack(pickup.weaponId))continue;
        pickup.collected=true;++pickupsCollected;
        return true;
    }
    return false;
}
bool CombatSystem::dropFromBackpack(size_t index,const Player& player) {
    if(index>=equipment.backpack.size() || equipment.backpack[index].empty())return false;
    uint32_t nextLootId=100000;
    for(const auto& entry:transients.pickups()) {
        const auto& p=entry.value;
        if(p.id>=UINT32_MAX-1)return false;
        nextLootId=std::max(nextLootId,p.id+1);
    }
    if(!transients.addPickup({nextLootId,equipment.backpack[index],player.pos.x,player.pos.y-12,false}).generation)
        return false;
    equipment.backpack[index].clear();
    return true;
}
void CombatSystem::advanceAirborne(Combatant& e,float dt,const World& world) {
    if(!e.airborne)return;
    const float oldY=e.y;
    e.vy=std::min(490.0f,e.vy+860.0f*dt);
    const float direction=e.navTargetX>e.x+2?1.f:e.navTargetX<e.x-2?-1.f:0.f;
    const bool waitForHeight=e.navTargetY<oldY-2.f && e.vy<0;
    const float newX=e.x+(waitForHeight?0.f:direction*220.f*dt);
    const Rect nextBox{newX-10,e.y-34,20,34};
    bool sideHit=newX<16 || newX>world.width-16;
    for(const auto& solid:world.solids) {
        // Ignore floor collision in horizontal sweep; resolve platform tops below.
        if(overlaps(nextBox,solid))sideHit=true;
    }
    if(!sideHit)e.x=newX;
    e.y+=e.vy*dt;
    bool hitCeiling=false;
    if(e.vy<0) {
        // When several ceilings are crossed in the same fixed step, hit the
        // closest underside, independently of the author's solid ordering.
        // One-way surfaces never block upward movement.
        float firstBottom=-std::numeric_limits<float>::infinity();
        for(const Rect& r:world.solids) {
            const float bottom=r.y+r.h;
            if(oldY-34>=bottom-0.01f && e.y-34<bottom &&
               e.x+9>r.x && e.x-9<r.x+r.w)
                firstBottom=std::max(firstBottom,bottom);
        }
        if(std::isfinite(firstBottom)) {
            e.y=firstBottom+34.f;
            e.vy=0;
            hitCeiling=true;
        }
    }
    if(e.vy>=0 && !hitCeiling) {
        // Resolve the first surface crossed, regardless of authoring layer order.
        // This also prevents high-speed falls from tunneling past thin platforms.
        float firstTop=std::numeric_limits<float>::infinity();
        const auto findLanding=[&](const std::vector<Rect>& surfaces) {
            for(const Rect& r:surfaces) {
                if(oldY<=r.y+0.01f && e.y>=r.y &&
                   e.x+9>r.x && e.x-9<r.x+r.w)
                    firstTop=std::min(firstTop,r.y);
            }
        };
        findLanding(world.solids);
        findLanding(world.oneWay);
        if(std::isfinite(firstTop)) {
            e.y=firstTop;e.vy=0;e.airborne=false;
        }
    }
    if(e.y>world.height+70) {
        // Out-of-bounds recovery must use the actual spawn platform, not a
        // hard-coded demo-floor height. Reset interpolation to avoid a 1-frame
        // teleport streak and invalidate waypoints from the failed jump.
        e.x=e.previousX=e.spawnX;
        e.y=e.previousY=e.spawnY;
        e.vx=e.vy=0;
        e.airborne=false;
        e.navPlanTimer=0;
        e.navPlanValid=false;
        setEnemyState(e,EnemyState::Return);
    }
}
bool CombatSystem::advanceEnemy(Combatant& e,float dx,const World& world) {
    if(std::abs(dx)<1e-5f)return true;
    const float next=e.x+dx;
    const Rect proposed={next-10,e.y-34,20,34};
    if(next<16 || next>world.width-16)return false;
    for(const Rect& b:world.solids)if(overlaps(proposed,b))return false;
    // Sample the ground at the leading foot; patrol/chase will not walk off cliffs.
    const float ahead=next+(dx>0?8.0f:-8.0f);
    bool supported=false;
    const auto test=[&](const std::vector<Rect>& blocks) {
        for(const auto& b:blocks) {
            if(ahead>=b.x && ahead<=b.x+b.w && std::abs(e.y-b.y)<=1.5f)return true;
        }
        return false;
    };
    supported=test(world.solids)||test(world.oneWay);
    if(!supported)return false;
    e.x=next;return true;
}
void CombatSystem::updateEnemies(float dt, Player& player,const World& world) {
    for(auto& e:enemies) {
        e.previousX=e.x;e.previousY=e.y;
        e.navPlanTimer=std::max(0.f,e.navPlanTimer-dt);
        e.hitFlash=std::max(0.0f,e.hitFlash-dt);
        e.attackCooldown=std::max(0.0f,e.attackCooldown-dt);
        e.aggroMemory=std::max(0.0f,e.aggroMemory-dt);
        e.visualTime+=dt;
        if(e.role==EnemyRole::Boss && e.alive && e.health*2<=e.maxHealth)e.bossPhase=2;
        if(e.airborne) {
            advanceAirborne(e,dt,world);
            if(e.airborne)continue;
            e.navPlanTimer=0; // surface may have changed upon landing
        }
        if(!e.alive) {setEnemyState(e,EnemyState::Dead);continue;}
        if(e.role==EnemyRole::Dummy) {
            advanceEnemy(e,e.vx*dt,world);
            e.vx*=std::exp(-12.0f*dt);
            continue;
        }
        // Far, unalerted enemies are dormant. Animation continues in animateEnemies().
        if(e.aggroMemory<=0 && !e.airborne &&
           (e.state==EnemyState::Idle || e.state==EnemyState::Patrol || e.state==EnemyState::Return) &&
           std::abs(e.x-player.pos.x)>700.0f) {
            e.stateTime+=dt;
            continue;
        }
        if(e.state==EnemyState::Stunned) {
            e.stunTime=std::max(0.0f,e.stunTime-dt);
            advanceEnemy(e,e.vx*dt,world);
            e.vx*=std::exp(-12.0f*dt);
            if(e.stunTime<=0)setEnemyState(e,EnemyState::Chase);
            continue;
        }
        if(player.health<=0) {setEnemyState(e,EnemyState::Return);}
        const float delta=player.pos.x-e.x;
        const float distance=std::abs(delta);
        const bool sameHeight=std::abs(player.pos.y-e.y)<44.0f;
        if(player.health>0 && std::abs(player.pos.y-e.y)<125.f && distance<(e.detectionRange>0?e.detectionRange:(165.0f+(e.role==EnemyRole::Gunner?145.0f:e.role==EnemyRole::Boss?120.0f:0.0f))))
            e.aggroMemory=2.5f;
        e.stateTime+=dt;
        if(e.state==EnemyState::Windup) {
            if(e.stateTime>=attackStartup(e))setEnemyState(e,EnemyState::Active);
            continue;
        }
        if(e.state==EnemyState::Active) {
            if(!e.attackApplied) {
                e.attackApplied=true;++enemyAttackEvents;
                if(e.role==EnemyRole::Gunner || (e.role==EnemyRole::Boss &&
                        e.bossPhase==2 && e.attacksFinished%2==1)) {
                    const float dir=e.facingRight?1.0f:-1.0f;
                    const int count=e.role==EnemyRole::Boss?3:1;
                    for(int k=0;k<count;++k) {
                        const EntityId spawned=transients.addProjectile({nextProjectileId_,
                            e.x+dir*16,e.y-21,e.x+dir*16,e.y-21,
                            dir*(e.role==EnemyRole::Boss?410.f:345.f),
                            (k-count/2)*45.f,2.2f,2.0f,e.attackDamageOverride>0?e.attackDamageOverride:(e.role==EnemyRole::Boss?13:10),true});
                        if(spawned.generation)++nextProjectileId_;
                    }
                } else {
                    const Rect weapon={e.facingRight?e.x:e.x-attackRange(e),e.y-32,
                                       attackRange(e),30};
                    if(overlaps(weapon,player.bounds()))
                        damagePlayer(player,e.attackDamageOverride>0?e.attackDamageOverride:(e.role==EnemyRole::Boss?24:e.role==EnemyRole::Heavy?20:9),e.facingRight?130:-130);
                }
            }
            if(e.stateTime>=attackActive(e)) {++e.attacksFinished;setEnemyState(e,EnemyState::Recovery);}
            continue;
        }
        if(e.state==EnemyState::Recovery) {
            if(e.stateTime>=attackRecovery(e)) {
                e.attackCooldown=e.role==EnemyRole::Boss?.40f:e.role==EnemyRole::Heavy?.48f:.24f;
                setEnemyState(e,EnemyState::Chase);
            }
            continue;
        }
        if(e.aggroMemory>0 && player.health>0) {
            if(e.navPlanTimer<=0 ||
               std::abs(player.pos.x-e.navPreviousGoalX)>30 ||
               std::abs(player.pos.y-e.navPreviousGoalY)>20) {
                const NavigationHop planned=planPlatformHop(world,{e.x,e.y},player.pos);
                ++navigationQueries;
                e.navPlanTimer=.20f;
                e.navPreviousGoalX=player.pos.x;e.navPreviousGoalY=player.pos.y;
                e.navPlanValid=planned.valid;e.navPlanTransition=planned.transition;
                e.cachedTakeoffX=planned.takeoffX;
                e.cachedLandingX=planned.landingX;
                e.cachedLandingY=planned.landingY;
            }
            const NavigationHop hop{e.navPlanValid,e.navPlanTransition,
                e.cachedTakeoffX,e.cachedLandingX,e.cachedLandingY};
            if(hop.valid && hop.transition) {
                e.facingRight=hop.takeoffX>=e.x;
                setEnemyState(e,EnemyState::Chase);
                const float speed=e.chaseSpeed>0?e.chaseSpeed:(e.role==EnemyRole::Heavy?48.f:70.f);
                const float dx=hop.takeoffX-e.x;
                if(std::abs(dx)>1.0f)advanceEnemy(e,std::clamp(dx,-speed*dt,speed*dt),world);
                else {e.airborne=true;e.vy=-355.f;e.navTargetX=hop.landingX;e.navTargetY=hop.landingY;}
                continue;
            }
            if(!sameHeight)continue;
            const bool inRange=distance<=attackRange(e);
            if(inRange && e.attackCooldown<=0) {
                e.facingRight=delta>=0;
                e.vx=0;
                setEnemyState(e,EnemyState::Windup);
                continue;
            }
            setEnemyState(e,EnemyState::Chase);
            if(!inRange) {
                const float speed=e.chaseSpeed>0?e.chaseSpeed:(e.role==EnemyRole::Boss?43.f:e.role==EnemyRole::Heavy?34.0f:e.role==EnemyRole::Gunner?45.0f:65.0f);
                const float direction=delta>=0?1.0f:-1.0f;
                e.facingRight=direction>0;
                advanceEnemy(e,direction*speed*dt,world);
            }
        } else {
            if(std::abs(e.x-e.spawnX)>4.0f || std::abs(e.y-e.spawnY)>2.f) {
                setEnemyState(e,EnemyState::Return);
                if(e.navPlanTimer<=0 ||
                   std::abs(e.navPreviousGoalX-e.spawnX)>1.f ||
                   std::abs(e.navPreviousGoalY-e.spawnY)>1.f) {
                    const auto planned=planPlatformHop(world,{e.x,e.y},{e.spawnX,e.spawnY});
                    ++navigationQueries;
                    e.navPlanTimer=.2f;
                    e.navPreviousGoalX=e.spawnX;e.navPreviousGoalY=e.spawnY;
                    e.navPlanValid=planned.valid;e.navPlanTransition=planned.transition;
                    e.cachedTakeoffX=planned.takeoffX;
                    e.cachedLandingX=planned.landingX;e.cachedLandingY=planned.landingY;
                }
                if(e.navPlanValid && e.navPlanTransition) {
                    const float dx=e.cachedTakeoffX-e.x;
                    e.facingRight=dx>=0;
                    if(std::abs(dx)>1.f) {
                        const float speed=e.patrolSpeed>0?e.patrolSpeed:38.f;
                        if(!advanceEnemy(e,std::clamp(dx,-speed*dt,speed*dt),world))
                            e.navPlanTimer=0.f;
                    } else {
                        e.airborne=true;e.vy=-355.f;
                        e.navTargetX=e.cachedLandingX;e.navTargetY=e.cachedLandingY;
                    }
                } else if(std::abs(e.y-e.spawnY)<2.f) {
                    const float dx=e.spawnX-e.x;
                    e.facingRight=dx>=0;
                    const float speed=e.patrolSpeed>0?e.patrolSpeed:38.f;
                    advanceEnemy(e,std::clamp(dx,-speed*dt,speed*dt),world);
                }
            } else {
                e.navPlanTimer=0; // invalidate return plan for next aggro
                setEnemyState(e,EnemyState::Patrol);
                if(std::abs(e.x-e.spawnX)>35)e.patrolDirection*=-1;
                if(!advanceEnemy(e,e.patrolDirection*(e.patrolSpeed>0?e.patrolSpeed:17.0f)*dt,world))e.patrolDirection*=-1;
            }
        }
        if(std::abs(e.vx)>1) {
            advanceEnemy(e,e.vx*dt,world);
            e.vx*=std::exp(-12.0f*dt);
        }
    }
}
void CombatSystem::animateEnemies(float dt) {
    for(auto& e:enemies) {
        const bool attacking=e.state==EnemyState::Windup || e.state==EnemyState::Active;
        const Animation clip=!e.alive?Animation::Fall:
            e.airborne?Animation::Jump:
            e.state==EnemyState::Stunned?Animation::Landing:
            attacking?(e.role==EnemyRole::Gunner?Animation::Shoot:Animation::Attack):
            (e.state==EnemyState::Chase || e.state==EnemyState::Patrol ||
             e.state==EnemyState::Return)?Animation::Run:Animation::Idle;
        e.animator.change(clip);
        e.animator.tick(dt);
    }
}
void CombatSystem::moveProjectiles(float dt,const World& world,Player& player,WorldObjectSystem* destructibles) {
    for(auto& entry:transients.mutableProjectiles()) {
        auto& p=entry.value;
        if(p.life<=0)continue;
        p.prevX=p.x;p.prevY=p.y;
        const float endX=p.x+p.vx*dt,endY=p.y+p.vy*dt;
        float nearest=std::numeric_limits<float>::infinity();
        Combatant* target=nullptr;bool hitPlayer=false;
        EntityId hitObject{};
        for(const auto& b:world.solids)
            nearest=std::min(nearest,segmentBox(p.x,p.y,endX,endY,b,p.radius));
        if(p.hostile) {
            const float t=segmentBox(p.x,p.y,endX,endY,player.bounds(),p.radius);
            if(player.health>0 && t<nearest){nearest=t;hitPlayer=true;}
        } else for(auto& e:enemies) {
            if(!e.alive)continue;
            const float t=segmentBox(p.x,p.y,endX,endY,enemyBox(e),p.radius);
            if(t<nearest){nearest=t;target=&e;}
        }
        if(destructibles && !p.hostile) {
            for(const auto& entry:destructibles->entries()) {
                const auto& o=entry.value;
                if(o.kind!=WorldObjectKind::Crate || o.health<=0)continue;
                const Rect box{o.x-o.radius*.5f,o.y-o.radius,o.radius,o.radius};
                const float t=segmentBox(p.x,p.y,endX,endY,box,p.radius);
                if(t<nearest) {nearest=t;hitObject=entry.entity;target=nullptr;hitPlayer=false;}
            }
        }
        if(nearest<=1.0f) {
            p.x+=(endX-p.x)*nearest;p.y+=(endY-p.y)*nearest;p.life=0;
            if(hitPlayer)damagePlayer(player,p.damage,p.vx>0?90:-90);
            if(hitObject.generation && destructibles &&
               destructibles->applyProjectile(hitObject,p.damage))
                feedback.push_back({p.x,p.y,CombatCueType::EnemyHit});
            if(target) {
                target->health=std::max(0,target->health-p.damage);
                target->alive=target->health>0;
                target->hitFlash=.16f;target->vx=p.vx>0?55.0f:-55.0f;
                if(!target->alive)onEnemyKilled(*target);
                else if(target->role!=EnemyRole::Dummy) {
                    target->stunTime=target->role==EnemyRole::Heavy?.07f:.18f;
                    setEnemyState(*target,EnemyState::Stunned);
                }
                feedback.push_back({target->x,target->y-23,CombatCueType::EnemyHit});
                ++damageEvents;
            }
        } else {
            p.x=endX;p.y=endY;p.life=std::max(0.0f,p.life-dt);
        }
    }
    transients.removeExpiredProjectiles();
}
void CombatSystem::tick(float dt,Player& player,const World& world,bool meleePressed,bool shootPressed,
                        WorldObjectSystem* destructibles) {
    if(dt<=0)return;
    feedback.clear();
    shootCooldown_=std::max(0.0f,shootCooldown_-dt);
    if(reloadTimer_>0) {
        reloadTimer_=std::max(0.0f,reloadTimer_-dt);
        if(reloadTimer_<=0) {
            const auto* w=equipment.slot(1);
            magazineRemaining_=std::min(ammo_,w?w->magazine:12);
            ++reloadEvents;
        }
    }
    updateEnemies(dt,player,world);
    animateEnemies(dt);
    if(meleePressed && meleeElapsed_<0 && !player.rolling && player.health>0) {
        meleeElapsed_=0;++attackSerial_;activeMelee_=melee;
        swingRight_=player.facingRight;struck_.clear();
    }
    if(meleeElapsed_>=0) {
        meleeElapsed_+=dt;
        meleeHits(player);
        if(meleeElapsed_>=activeMelee_.startup+activeMelee_.active+activeMelee_.recovery)
            meleeElapsed_=-1;
    }
    if(shootPressed && shootCooldown_<=0 && reloadTimer_<=0 &&
       !player.rolling && player.health>0) {
        const auto* w=equipment.slot(1);
        if(ammo_>0 && magazineRemaining_<=0)reload();
        else if(w && magazineRemaining_>0 && ammo_>0) {
            const float dir=player.facingRight?1.0f:-1.0f;
            const auto spawned=transients.addProjectile({nextProjectileId_,player.pos.x+dir*17,player.pos.y-21,
                player.pos.x+dir*17,player.pos.y-21,dir*w->projectileSpeed,0,
                1.4f,2.0f,equipment.weaponDamage(1)+equipment.bonusDamage(),false});
            if(spawned.generation) {
                ++nextProjectileId_;
                feedback.push_back({player.pos.x+dir*17,player.pos.y-21,CombatCueType::Muzzle});
                --ammo_;--magazineRemaining_;++shotsFired_;
                shootCooldown_=w->cooldown;
            }
        }
    }
    moveProjectiles(dt,world,player,destructibles);
}
}
