#include "forge/Animation.hpp"
#include <algorithm>
#include <cmath>
#include <utility>

namespace forge {
Animator::Animator() {
    // 16 unique authored frames per demo track. Gameplay timings remain independent.
    for(size_t i=0;i<clips_.size();++i) {
        auto& clip=clips_[i];
        const Animation track=static_cast<Animation>(i);
        clip.loop = !(track==Animation::Landing || track==Animation::Roll ||
                      track==Animation::Attack || track==Animation::Shoot);
        const float fps=track==Animation::Shoot?64.0f:
                        track==Animation::Roll||track==Animation::Attack?40.0f:
                        track==Animation::Jump||track==Animation::Landing?35.0f:
                        track==Animation::Run?22.0f:16.0f;
        clip.frames.resize(16);
        for(auto& frame:clip.frames)frame.seconds=1.0f/fps;
    }
}
bool Animator::setClip(Animation target,SpriteClip clip) {
    const auto index=static_cast<size_t>(target);
    if(index>=clips_.size() || clip.frames.empty() || clip.frames.size()>4096)return false;
    for(const auto& f:clip.frames)
        if(!std::isfinite(f.seconds) || f.seconds<0.001f || f.seconds>10.0f)return false;
    clips_[index]=std::move(clip);
    if(animation==target) {
        frame=0; time=0; frameElapsed_=0;
        pendingEvents_=clips_[index].frames.front().events;
    }
    return true;
}
void Animator::change(Animation next) {
    const auto index=static_cast<size_t>(next);
    if(index>=clips_.size() || next==animation)return;
    animation=next;time=0;frame=0;frameElapsed_=0;
    pendingEvents_=clips_[index].frames.front().events;
}
void Animator::tick(float dt) {
    if(!std::isfinite(dt)||dt<=0||!std::isfinite(speed)||speed<=0)return;
    const auto& clip=clips_[static_cast<size_t>(animation)];
    if(clip.frames.empty())return;
    const float delta=std::min(dt*speed,5.0f);
    time+=delta;
    frameElapsed_+=delta;
    // Large hitches are bounded while allowing authored per-frame timings.
    for(int steps=0;steps<5000;++steps) {
        const float length=clip.frames[static_cast<size_t>(frame)].seconds;
        if(frameElapsed_+1e-6f<length)break;
        if(!clip.loop && frame+1>=static_cast<int>(clip.frames.size())) {
            frameElapsed_=length;break;
        }
        frameElapsed_-=length;
        frame=(frame+1)%static_cast<int>(clip.frames.size());
        pendingEvents_|=clip.frames[static_cast<size_t>(frame)].events;
    }
}
const SpriteFrame* Animator::currentFrame() const {
    const auto& clip=clips_[static_cast<size_t>(animation)];
    return frame>=0 && static_cast<size_t>(frame)<clip.frames.size()?
           &clip.frames[static_cast<size_t>(frame)]:nullptr;
}
uint32_t Animator::takeEvents() {const uint32_t result=pendingEvents_;pendingEvents_=0;return result;}
}
