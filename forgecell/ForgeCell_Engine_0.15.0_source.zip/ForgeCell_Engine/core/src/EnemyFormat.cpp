#include "forge/EnemyFormat.hpp"
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <utility>
namespace forge {
namespace {
struct Reader {
 std::span<const std::byte> b;size_t at=0;
 bool u16(uint16_t& value) {if(b.size()-at<2)return false;value=0;for(int i=0;i<2;++i)value|=uint16_t(std::to_integer<uint8_t>(b[at++]))<<(8*i);return true;}
 bool u32(uint32_t& value) {if(b.size()-at<4)return false;value=0;for(int i=0;i<4;++i)value|=uint32_t(std::to_integer<uint8_t>(b[at++]))<<(8*i);return true;}
 bool f32(float& value) {uint32_t v;if(!u32(v))return false;std::memcpy(&value,&v,4);return std::isfinite(value);}
 bool str(std::string& s) {uint16_t n;if(!u16(n) || n>63 || n>b.size()-at)return false;s.assign(reinterpret_cast<const char*>(b.data()+at),n);at+=n;return true;}
};
}
bool decodeEnemyBinary(std::span<const std::byte> b,std::vector<Combatant>& out,std::string& error) {
 if(b.size()<8 || b.size()>65536 || std::memcmp(b.data(),"FCEY",4)!=0){error="Invalid FCEY header/size";return false;}
 Reader r{b,4};uint16_t version,count;
 if(!r.u16(version)||!r.u16(count)||(version!=1 && version!=2)||count==0||count>128){error="Unsupported FCEY version/count";return false;}
 std::vector<Combatant> parsed;parsed.reserve(count);
 std::unordered_set<uint32_t> ids;
 for(unsigned i=0;i<count;++i) {
  Combatant c;uint16_t role=0;uint32_t hp=0,damage=0;
  if(!r.u32(c.id)||!r.u16(role)||!r.u32(hp)||
     !r.f32(c.x)||!r.f32(c.y)||!r.f32(c.chaseSpeed)||!r.f32(c.patrolSpeed)||
     !r.f32(c.detectionRange)||!r.f32(c.attackRangeOverride)||
     !r.f32(c.attackStartupOverride)||!r.f32(c.attackActiveOverride)||
     !r.f32(c.attackRecoveryOverride)||!r.u32(damage)||!r.str(c.lootId)) {
   error="Truncated or non-finite FCEY entry";return false;
  }
  if(c.id==0||!ids.insert(c.id).second||role>4||hp<1||hp>100000||
     damage<1||damage>10000||std::abs(c.x)>100000||std::abs(c.y)>100000||
     c.chaseSpeed<=0||c.chaseSpeed>1000||c.patrolSpeed<0||c.patrolSpeed>1000||
     c.detectionRange<=0||c.detectionRange>5000||c.attackRangeOverride<=0||c.attackRangeOverride>2000||
     c.attackStartupOverride<=0||c.attackStartupOverride>30||c.attackActiveOverride<=0||
     c.attackActiveOverride>30||c.attackRecoveryOverride<=0||c.attackRecoveryOverride>30) {
   error="Invalid FCEY enemy parameters";return false;
  }
  if(version==2){
   uint16_t style=0;
   if(!r.u16(style)||style>=32){error="Invalid FCEY v2 visual slot";return false;}
   c.visualIndex=static_cast<uint8_t>(style);
  }
  c.role=static_cast<EnemyRole>(role);
  c.maxHealth=c.health=static_cast<int>(hp);
  c.attackDamageOverride=static_cast<int>(damage);
  c.previousX=c.spawnX=c.x;c.previousY=c.spawnY=c.y;
  parsed.push_back(std::move(c));
 }
 if(r.at!=b.size()){error="Trailing FCEY bytes";return false;}
 out=std::move(parsed);error.clear();return true;
}
}
