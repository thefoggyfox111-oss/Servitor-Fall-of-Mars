#include "forge/Combat.hpp"
#include <algorithm>
#include <cmath>

namespace forge {
TransientEntities::TransientEntities(const TransientEntities& other) : TransientEntities() {
    for(const auto& item:other.projectiles()) addProjectile(item.value);
    for(const auto& item:other.pickups()) addPickup(item.value);
}
TransientEntities& TransientEntities::operator=(const TransientEntities& other) {
    if(this==&other)return *this;
    clear();
    for(const auto& item:other.projectiles())addProjectile(item.value);
    for(const auto& item:other.pickups())addPickup(item.value);
    return *this;
}
TransientEntities::TransientEntities(TransientEntities&& other) noexcept :
    TransientEntities(static_cast<const TransientEntities&>(other)) {}
TransientEntities& TransientEntities::operator=(TransientEntities&& other) noexcept {
    return operator=(static_cast<const TransientEntities&>(other));
}
EntityId TransientEntities::addProjectile(Projectile projectile) {
    if(projectiles_.size()>=kMaxProjectiles || projectile.id==0 ||
       !std::isfinite(projectile.x)||!std::isfinite(projectile.y)||
       !std::isfinite(projectile.vx)||!std::isfinite(projectile.vy)||
       !std::isfinite(projectile.life)||projectile.life<=0 ||
       !std::isfinite(projectile.radius)||projectile.radius<=0||projectile.radius>32 ||
       projectile.damage<=0||projectile.damage>100000)return {};
    const EntityId id=entities_.create();
    if(!projectiles_.set(id,std::move(projectile))) {entities_.destroy(id);return {};}
    return id;
}
EntityId TransientEntities::addPickup(Pickup pickup) {
    if(pickups_.size()>=kMaxPickups || pickup.id==0 || pickup.weaponId.empty() ||
       !std::isfinite(pickup.x)||!std::isfinite(pickup.y))return {};
    for(const auto& entry:pickups_.entries())if(entry.value.id==pickup.id)return {};
    const EntityId id=entities_.create();
    if(!pickups_.set(id,std::move(pickup))) {entities_.destroy(id);return {};}
    return id;
}
bool TransientEntities::removeProjectile(EntityId id) {
    if(!entities_.alive(id)||!projectiles_.remove(id))return false;
    return entities_.destroy(id);
}
bool TransientEntities::removePickup(EntityId id) {
    if(!entities_.alive(id)||!pickups_.remove(id))return false;
    return entities_.destroy(id);
}
void TransientEntities::clearProjectiles() {
    // Destroy ECS handles before removing packed component storage.
    for(const auto& entry:projectiles_.entries())entities_.destroy(entry.entity);
    projectiles_.clear();
}
void TransientEntities::clearPickups() {
    for(const auto& entry:pickups_.entries())entities_.destroy(entry.entity);
    pickups_.clear();
}
void TransientEntities::clear() {
    projectiles_.clear();pickups_.clear();entities_.clear();
}
void TransientEntities::removeExpiredProjectiles() {
    // Swap-delete may move the last element into this slot; walk backwards.
    for(size_t n=projectiles_.size();n>0;--n) {
        const auto& entry=projectiles_.entries()[n-1];
        if(entry.value.life<=0)removeProjectile(entry.entity);
    }
}
bool TransientEntities::replacePickups(std::span<const Pickup> items) {
    if(items.size()>kMaxPickups)return false;
    TransientEntities pending;
    for(const auto& item:items)if(!pending.addPickup(item).generation)return false;
    // Preserve live projectiles. Saves clear those separately.
    clearPickups();
    for(const auto& entry:pending.pickups()) {
        if(!addPickup(entry.value).generation)return false;
    }
    return true;
}
}
