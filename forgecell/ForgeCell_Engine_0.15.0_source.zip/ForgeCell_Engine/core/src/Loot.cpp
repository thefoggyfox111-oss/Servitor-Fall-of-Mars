#include "forge/Loot.hpp"
#include <algorithm>
#include <array>
#include <cstring>
#include <bit>
namespace forge {
namespace {
uint64_t next(uint64_t& state) {
    state += 0x9E3779B97F4A7C15ULL;
    uint64_t z=state;
    z=(z^(z>>30))*0xBF58476D1CE4E5B9ULL;
    z=(z^(z>>27))*0x94D049BB133111EBULL;
    return z^(z>>31);
}
uint16_t u16(std::span<const std::byte> b,size_t pos) {
    return uint16_t(std::to_integer<uint8_t>(b[pos])) |
        (uint16_t(std::to_integer<uint8_t>(b[pos+1]))<<8);
}
uint64_t u64(std::span<const std::byte> b,size_t pos) {
    uint64_t result=0;
    for(int i=0;i<8;++i)result |= uint64_t(std::to_integer<uint8_t>(b[pos+i]))<<(i*8);
    return result;
}
bool valid(const LootRule& rule) {
    return rule.chance<=100 && rule.rolls<=3 && rule.statMask<=0x1f &&
        rule.minimum<=rule.maximum && rule.maximum<=100 &&
        (rule.rolls==0 || (rule.statMask!=0 &&
            std::popcount(static_cast<unsigned>(rule.statMask))>=rule.rolls));
}
}
LootTable::LootTable() {
    // Preserve guaranteed drops for Heavy/Boss from the earlier demo.
    rules[0]={100,0,0,0,0};
    rules[1]={90,1,0x07,1,6};
    rules[2]={100,2,0x0f,3,14};
    rules[3]={85,1,0x0e,2,8};
    rules[4]={100,3,0x1f,8,25};
}
bool LootTable::load(std::span<const std::byte> b,std::string& error) {
    if(b.size()!=56 || std::memcmp(b.data(),"FCLT",4)!=0 ||
       u16(b,4)!=1 || u16(b,6)!=5) {
        error="FCLT signature, version or size invalid";return false;
    }
    LootTable candidate;
    candidate.seed=u64(b,8);
    std::array<bool,5> seen {};
    for(size_t i=0;i<5;++i) {
        const size_t at=16+i*8;
        const uint8_t role=std::to_integer<uint8_t>(b[at]);
        const LootRule rule{std::to_integer<uint8_t>(b[at+1]),
            std::to_integer<uint8_t>(b[at+2]),std::to_integer<uint8_t>(b[at+3]),
            u16(b,at+4),u16(b,at+6)};
        if(role>=5 || seen[role] || !valid(rule)) {
            error="Invalid or duplicated FCLT role/range";return false;
        }
        seen[role]=true;candidate.rules[role]=rule;
    }
    if(std::find(seen.begin(),seen.end(),false)!=seen.end()) {
        error="FCLT missing role";return false;
    }
    *this=candidate;error.clear();return true;
}
std::optional<ItemAffixes> LootTable::roll(uint32_t id,uint8_t role) const {
    if(id==0 || role>=rules.size())return std::nullopt;
    const LootRule& rule=rules[role];
    if(!valid(rule))return std::nullopt;
    uint64_t state=seed^(uint64_t(id)*0xD6E8FEB86659FD93ULL)^
        (uint64_t(role)*0xA0761D6478BD642FULL);
    if(next(state)%100>=rule.chance)return std::nullopt;
    std::array<uint8_t,5> slots {};
    size_t count=0;
    for(uint8_t stat=0;stat<5;++stat)if(rule.statMask&(1u<<stat))slots[count++]=stat;
    ItemAffixes result{};
    for(size_t i=0;i<rule.rolls;++i) {
        const size_t chosen=i+size_t(next(state)%(count-i));
        std::swap(slots[i],slots[chosen]);
        const uint16_t bonus=uint16_t(rule.minimum+
            (next(state)%(uint64_t(rule.maximum-rule.minimum)+1)));
        switch(slots[i]) {
            case 0:result.health=bonus;break;
            case 1:result.damage=bonus;break;
            case 2:result.defense=bonus;break;
            case 3:result.speedPct=bonus;break;
            case 4:result.healing=bonus;break;
        }
    }
    return result;
}
}
