#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>

namespace forge {
struct VisualDefinition {
    uint16_t x=0,y=0,frameWidth=0,frameHeight=0,frames=0,animations=0;
    int16_t footX=0,footY=0;
    bool valid=false;
};
struct VisualCatalog {
    static constexpr size_t kMaxArchetypes=32;
    uint16_t atlasWidth=0,atlasHeight=0;
    std::array<VisualDefinition,kMaxArchetypes> styles{};
    const VisualDefinition* get(unsigned slot) const {
        return slot<styles.size()&&styles[slot].valid?&styles[slot]:nullptr;
    }
};
// FCVA v1: validated metadata for sprites in a shared pixel atlas.
bool decodeVisualBinary(std::span<const std::byte> bytes,VisualCatalog& out,std::string& error);
}
