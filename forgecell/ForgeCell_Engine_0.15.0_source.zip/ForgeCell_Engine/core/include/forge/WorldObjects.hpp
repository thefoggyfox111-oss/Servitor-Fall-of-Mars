#pragma once
#include "forge/EntityRegistry.hpp"
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

namespace forge {
struct Player;
struct World;
struct AttackDefinition;
enum class WorldObjectKind : uint8_t { Crate=0, Checkpoint=1 };
struct WorldObject {
    uint32_t stableId=0;
    WorldObjectKind kind=WorldObjectKind::Crate;
    float x=0,y=0;
    int health=1,maxHealth=1;
    float radius=20;
    uint64_t lastStrike=0;
    bool activated=false;
};
// Gameplay objects use live, generation-checked ECS IDs; no renderer ownership.
class WorldObjectSystem {
public:
    static constexpr size_t kMaxObjects=128;
    using Entry=ComponentPool<WorldObject>::Entry;
    WorldObjectSystem() : objects_(&entities_) {}
    // Rebuild the pool against the destination registry, never copy the old pointer.
    WorldObjectSystem(const WorldObjectSystem& other);
    WorldObjectSystem& operator=(const WorldObjectSystem& other);
    WorldObjectSystem(WorldObjectSystem&& other) noexcept;
    WorldObjectSystem& operator=(WorldObjectSystem&& other) noexcept;
    EntityId add(WorldObject object);
    const WorldObject* get(EntityId id) const {return objects_.get(id);}
    bool remove(EntityId id);
    void clear();
    size_t size() const {return objects_.size();}
    const std::vector<Entry>& entries() const {return objects_.entries();}
    // Attack serial enforces one hit per swing regardless of duration/render FPS.
    int applyMelee(const Player& player,const AttackDefinition& attack,uint64_t serial);
    bool applyProjectile(EntityId entity,int damage);
    bool interact(const Player& player);
    uint32_t lastCheckpoint() const {return lastCheckpoint_;}
    bool load(std::span<const std::byte> data,const World& world,std::string& error);
private:
    friend class SaveCodec;
    EntityRegistry entities_;
    ComponentPool<WorldObject> objects_;
    uint32_t lastCheckpoint_=0;
};
}
