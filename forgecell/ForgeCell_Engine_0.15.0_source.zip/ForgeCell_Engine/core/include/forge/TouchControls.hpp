#pragma once
#include "forge/Simulation.hpp"
#include <array>
#include <optional>

namespace forge {
enum class Control : uint8_t { Move, Jump, Roll, Attack, Shoot, SwapMelee, SwapRanged, Interact, UseConsumable, Inventory, Drop, Sort, InventoryCell, EquipmentSlot, None };
struct TouchPoint {
    int32_t id = -1;
    Vec2 at {};
    Vec2 origin {};
    Control control = Control::None;
    bool active = false;
};
struct InventoryDrag {
    int fromCell=-1, fromSlot=-1;
    int toCell=-1, toSlot=-1;
    Vec2 position {};
};
class TouchControls {
public:
    void resize(float virtualWidth, float virtualHeight);
    void pointerDown(int32_t id, float x, float y);
    void pointerMove(int32_t id, float x, float y);
    void pointerUp(int32_t id, float x, float y);
    void pointerUp(int32_t id); // compatibility for callers lacking release coordinates
    void clear();
    void setInventoryOpen(bool open) {inventoryOpen_=open;}
    Input sample(); // edges consumed only once, even with multiple simulation ticks
    std::optional<InventoryDrag> inventoryDrag() const; // read-only pointer preview
    float viewWidth() const {return width_;}
    static Vec2 buttonCenter(Control control, float width, float height);
private:
    float width_ = 640, height_ = 360;
    std::array<TouchPoint, 16> pointers_ {};
    bool inventoryOpen_ = false;
    int selectedCellPending_ = -1;
    int moveFromPending_=-1, moveToPending_=-1, equipSlotPending_=-1;
    int unequipSlotPending_=-1, unequipToPending_=-1;
    int backpackAt(float x,float y) const;
    int equipmentAt(float x,float y) const;
    bool inventoryPending_ = false, interactPending_ = false, consumablePending_ = false, dropPending_ = false, sortPending_ = false;
    bool jumpPending_ = false, rollPending_ = false, attackPending_ = false, shootPending_ = false, swapMeleePending_ = false, swapRangedPending_ = false;
    Control hit(float x, float y) const;
};
}
