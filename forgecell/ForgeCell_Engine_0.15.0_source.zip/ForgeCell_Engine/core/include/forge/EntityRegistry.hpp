#pragma once
#include <cstddef>
#include <cstdint>
#include <limits>
#include <utility>
#include <vector>

namespace forge {
struct EntityId {
    uint32_t index = UINT32_MAX;
    uint32_t generation = 0;
    friend bool operator==(EntityId, EntityId) = default;
};
class EntityRegistry {
public:
    EntityId create() {
        if (!free_.empty()) {
            const uint32_t index = free_.back(); free_.pop_back();
            active_[index] = true;
            ++live_;
            return {index, generations_[index]};
        }
        if (generations_.size() >= UINT32_MAX) return {};
        const uint32_t index = static_cast<uint32_t>(generations_.size());
        generations_.push_back(1);
        active_.push_back(true);
        ++live_;
        return {index, 1};
    }
    [[nodiscard]] bool alive(EntityId entity) const {
        return entity.index < generations_.size() && active_[entity.index] &&
               generations_[entity.index] == entity.generation;
    }
    bool destroy(EntityId entity) {
        if (!alive(entity)) return false;
        active_[entity.index] = false;
        // Zero is reserved for invalid IDs, including after generation overflow.
        ++generations_[entity.index];
        if (generations_[entity.index] == 0) ++generations_[entity.index];
        free_.push_back(entity.index);
        --live_;
        return true;
    }
    void clear() {
        free_.clear();
        for(uint32_t index=0;index<generations_.size();++index) {
            if(active_[index]) {
                ++generations_[index];
                if(generations_[index]==0)++generations_[index];
            }
            active_[index]=false;
            free_.push_back(index);
        }
        live_=0;
    }
    void reserve(size_t count) {
        generations_.reserve(count);active_.reserve(count);free_.reserve(count);
    }
    [[nodiscard]] size_t size() const { return live_; }
    [[nodiscard]] size_t capacity() const { return generations_.size(); }
private:
    std::vector<uint32_t> generations_;
    std::vector<uint8_t> active_;
    std::vector<uint32_t> free_;
    size_t live_ = 0;
};

// Packed component storage. Swap-delete keeps iteration cache-friendly and O(1).
// If a registry is attached, destroyed entities cannot be accessed via stale IDs.
template<class T> class ComponentPool {
public:
    struct Entry { EntityId entity; T value; };
    explicit ComponentPool(const EntityRegistry* registry = nullptr) : registry_(registry) {}
    bool set(EntityId entity, T value) {
        if (entity.index == UINT32_MAX || entity.generation == 0 ||
            (registry_ && !registry_->alive(entity))) return false;
        ensureSparse(entity.index);
        const size_t slot = sparse_[entity.index];
        if (slot != invalid && dense_[slot].entity == entity) {
            dense_[slot].value = std::move(value);
            return true;
        }
        if (slot != invalid) eraseAt(slot);
        sparse_[entity.index] = dense_.size();
        dense_.push_back({entity, std::move(value)});
        return true;
    }
    T* get(EntityId entity) {
        if (registry_ && !registry_->alive(entity)) return nullptr;
        if (entity.index >= sparse_.size()) return nullptr;
        const size_t slot = sparse_[entity.index];
        return slot != invalid && dense_[slot].entity == entity ? &dense_[slot].value : nullptr;
    }
    const T* get(EntityId entity) const {
        return const_cast<ComponentPool*>(this)->get(entity);
    }
    bool remove(EntityId entity) {
        if (entity.index >= sparse_.size()) return false;
        const size_t slot = sparse_[entity.index];
        if (slot == invalid || !(dense_[slot].entity == entity)) return false;
        eraseAt(slot);
        return true;
    }
    [[nodiscard]] const std::vector<Entry>& entries() const { return dense_; }
    std::vector<Entry>& mutableEntries() { return dense_; }
    void reserve(size_t count) {dense_.reserve(count);sparse_.reserve(count);}
    [[nodiscard]] size_t size() const { return dense_.size(); }
    void clear() {dense_.clear();sparse_.clear();}
private:
    static constexpr size_t invalid = std::numeric_limits<size_t>::max();
    void ensureSparse(uint32_t index) {
        if (index >= sparse_.size()) sparse_.resize(static_cast<size_t>(index)+1,invalid);
    }
    void eraseAt(size_t index) {
        const size_t last = dense_.size()-1;
        const uint32_t oldIndex = dense_[index].entity.index;
        if (index != last) {
            dense_[index] = std::move(dense_[last]);
            sparse_[dense_[index].entity.index] = index;
        }
        dense_.pop_back();
        sparse_[oldIndex] = invalid;
    }
    const EntityRegistry* registry_ = nullptr;
    std::vector<Entry> dense_;
    std::vector<size_t> sparse_;
};
}
