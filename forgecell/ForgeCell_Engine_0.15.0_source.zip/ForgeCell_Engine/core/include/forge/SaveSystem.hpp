#pragma once
#include <cstddef>
#include <span>
#include <string>
#include <vector>
namespace forge {
class Simulation;
class SaveCodec {
public:
 // FCSV v3 (reads v1/v2), little-endian, length+CRC32. Includes ECS world-object state.
 // Active attacks/projectiles/velocity are intentionally discarded when loading.
 static std::vector<std::byte> encode(const Simulation& simulation);
 // Atomic with respect to simulation: failed parses leave the state unchanged.
 static bool decode(std::span<const std::byte> file,Simulation& simulation,std::string& error);
};
// Platform-independent POSIX file APIs; path must be in app-private storage.
bool saveCheckpoint(const std::string& path,const Simulation& simulation,std::string& error);
bool loadCheckpoint(const std::string& path,Simulation& simulation,std::string& error);
}
