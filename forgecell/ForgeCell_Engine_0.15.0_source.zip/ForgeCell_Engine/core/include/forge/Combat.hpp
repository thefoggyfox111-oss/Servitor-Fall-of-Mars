#pragma once
#include <cstdint>
#include <span>
#include "forge/Equipment.hpp"
#include "forge/Loot.hpp"
#include "forge/Animation.hpp"
#include "forge/EntityRegistry.hpp"
#include "forge/EnemyActors.hpp"
#include <array>
#include <vector>

namespace forge {
struct Vec2;
struct Rect;
struct Player;
struct World;
class WorldObjectSystem;

// Authoring data, deliberately independent of sprite frame indices.
struct AttackDefinition {
    float startup = 0.10f;
    float active = 0.12f;
    float recovery = 0.18f;
    float reach = 36.0f;
    float height = 27.0f;
    int damage = 30;
    float knockback = 90.0f;
};
enum class CombatCueType : uint8_t { EnemyHit, PlayerHit, EnemyKilled, Muzzle };
struct CombatCue {float x=0,y=0; CombatCueType type=CombatCueType::EnemyHit;};
enum class EnemyRole : uint8_t { Dummy, Grunt, Heavy, Gunner, Boss };
enum class EnemyState : uint8_t { Idle, Patrol, Chase, Windup, Active, Recovery, Stunned, Return, Dead };
struct Combatant {
    uint32_t id = 0;
    float x = 0, y = 294; // foot position in world space
    float previousX = 0, previousY = 294;
    float vx = 0;
    int health = 100;
    int maxHealth = 100;
    bool alive = true;
    float hitFlash = 0;
    float contactCooldown = 0;
    EnemyRole role = EnemyRole::Dummy;
    EnemyState state = EnemyState::Idle;
    float spawnX = 0;
    float spawnY = 294; // home surface for cross-platform returns
    float stateTime = 0;
    float attackCooldown = 0;
    float stunTime = 0;
    float aggroMemory = 0;
    float visualTime = 0;
    float patrolDirection = 1;
    float vy = 0;
    float navTargetX = 0, navTargetY = 294;
    bool airborne = false;
    // 0.2-second navigation cache. Never stored in a checkpoint.
    float navPlanTimer = 0;
    float navPreviousGoalX = 0, navPreviousGoalY = 0;
    bool navPlanValid = false, navPlanTransition = false;
    float cachedTakeoffX = 0, cachedLandingX = 0, cachedLandingY = 0;
    int bossPhase = 1;
    int attacksFinished = 0;
    bool lootSpawned = false;
    bool facingRight = false;
    bool attackApplied = false;
    Animator animator {}; // Per-actor playback. Never advanced by renderer.
    // External FCEY spawn/profile overrides; zero means use legacy role defaults.
    float chaseSpeed = 0;
    float patrolSpeed = 0;
    float detectionRange = 0;
    float attackRangeOverride = 0;
    float attackStartupOverride = 0;
    float attackActiveOverride = 0;
    float attackRecoveryOverride = 0;
    int attackDamageOverride = 0;
    std::string lootId;
    uint8_t visualIndex = 255; // 255 = role-based fallback, otherwise FCVA slot

};
struct Pickup {
    uint32_t id = 0;
    std::string weaponId;
    float x = 0, y = 0;
    bool collected = false;
};
struct Projectile {
    uint32_t id = 0;
    float x = 0, y = 0, prevX = 0, prevY = 0;
    float vx = 0, vy = 0;
    float life = 1.5f;
    float radius = 2.0f;
    int damage = 16;
    bool hostile = false;
};
// Generation-safe ECS ownership for short-lived combat entities.
// Rendering/save serializers access packed components through read-only entries.
class TransientEntities {
public:
    static constexpr size_t kMaxProjectiles=256;
    static constexpr size_t kMaxPickups=1024;
    using ProjectileEntry=ComponentPool<Projectile>::Entry;
    using PickupEntry=ComponentPool<Pickup>::Entry;
    TransientEntities() : projectiles_(&entities_), pickups_(&entities_) {}
    TransientEntities(const TransientEntities& other);
    TransientEntities& operator=(const TransientEntities& other);
    TransientEntities(TransientEntities&& other) noexcept;
    TransientEntities& operator=(TransientEntities&& other) noexcept;
    EntityId addProjectile(Projectile item);
    EntityId addPickup(Pickup item);
    bool removeProjectile(EntityId id);
    bool removePickup(EntityId id);
    const Projectile* projectile(EntityId id) const {return projectiles_.get(id);}
    const Pickup* pickup(EntityId id) const {return pickups_.get(id);}
    const std::vector<ProjectileEntry>& projectiles() const {return projectiles_.entries();}
    const std::vector<PickupEntry>& pickups() const {return pickups_.entries();}
    std::vector<ProjectileEntry>& mutableProjectiles() {return projectiles_.mutableEntries();}
    std::vector<PickupEntry>& mutablePickups() {return pickups_.mutableEntries();}
    void removeExpiredProjectiles();
    void clearProjectiles();
    void clearPickups();
    void clear();
    bool replacePickups(std::span<const Pickup> items);
private:
    EntityRegistry entities_;
    ComponentPool<Projectile> projectiles_;
    ComponentPool<Pickup> pickups_;
};
class CombatSystem {
public:
    AttackDefinition melee {};
    Equipment equipment {};
    LootTable lootTable {};
    bool loadLoot(std::span<const std::byte> data,std::string& error) {return lootTable.load(data,error);}
    // Changes take effect when the next attack starts, not mid-swing.
    bool equipFromBackpack(size_t bagIndex,size_t slotIndex);
    bool cycleWeapon(size_t slotIndex);
    int playerDamageEvents = 0;
    int enemyAttackEvents = 0;
    int reloadEvents = 0;
    uint32_t navigationQueries = 0; // diagnostic counter for path replans
    bool reloading() const {return reloadTimer_>0;}
    int magazineRemaining() const {return magazineRemaining_;}
    EnemyActors enemies;
    TransientEntities transients;
    int pickupsCollected = 0;
    std::vector<CombatCue> feedback; // cleared every combat tick; consumed by VFX
    bool collectNearby(const Player& player,float radius=35.f);
    bool dropFromBackpack(size_t index,const Player& player);
    int damageEvents = 0; // telemetry/test hook, not a graphical effect
    void resetDemo();
    // Reloading enemy configuration replaces only enemy instances, atomically.
    bool loadEnemies(std::span<const std::byte> bytes, const World& world, std::string& error);
    bool loadEnemyAnimation(EnemyRole role, std::span<const std::byte> bytes, std::string& error);
    // Fixed-format checkpoint restores persistent state; active attack timers reset.
    void restoreCheckpointTimers();
    bool loadEquipment(std::span<const std::byte> bytes,std::string& error);
    bool loadItems(std::span<const std::byte> bytes,std::string& error);
    void tick(float dt, Player& player, const World& world, bool meleePressed, bool shootPressed,
              WorldObjectSystem* destructibles = nullptr);
    bool attacking() const {return meleeElapsed_ >= 0;}
    bool meleeActive() const;
    uint64_t attackSerial() const {return attackSerial_;}
    float meleeTime() const {return meleeElapsed_;}
    int ammo() const {return ammo_;}
    int shotsFired() const {return shotsFired_;}
    void setAmmo(int count);
    void reload();
    bool useConsumable(Player& player);
private:
    friend class SaveCodec;
    uint64_t attackSerial_ = 0;
    float meleeElapsed_ = -1;
    float shootCooldown_ = 0;
    float reloadTimer_ = 0;
    int magazineRemaining_ = 12;
    AttackDefinition activeMelee_ {};
    float activeMeleeTotal_ = 0;
    bool swingRight_ = true;
    uint32_t nextProjectileId_ = 1;
    std::vector<uint32_t> struck_;
    int ammo_ = 60;
    int shotsFired_ = 0;
    std::array<Animator, 5> enemyAnimationProfiles_ {};
    void animateEnemies(float dt);
    void meleeHits(Player& player);
    void moveProjectiles(float dt, const World& world, Player& player,
                         WorldObjectSystem* destructibles);
    void updateEnemies(float dt, Player& player, const World& world);
    void damagePlayer(Player& player,int damage,float push);
    bool advanceEnemy(Combatant& enemy,float dx,const World& world);
    void setEnemyState(Combatant& enemy,EnemyState state);
    void onEnemyKilled(Combatant& enemy);
    void advanceAirborne(Combatant& enemy,float dt,const World& world);
};
}
