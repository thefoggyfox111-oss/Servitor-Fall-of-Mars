#pragma once
#include "forge/EntityRegistry.hpp"
#include <cstdint>

namespace forge {
enum class EffectKind : uint8_t { Hit, PlayerHit, Death, Shot };
struct Effect {
    float x=0, y=0;
    float age=0, duration=0;
    EffectKind kind=EffectKind::Hit;
};
// First runtime ECS user: ephemeral, gameplay-independent feedback particles.
// Entity generations prevent a stale handle from manipulating a recycled effect.
class EffectSystem {
public:
    static constexpr size_t kMaxEffects=256;
    EntityId emit(float x,float y,EffectKind kind);
    void tick(float dt);
    bool remove(EntityId id);
    [[nodiscard]] size_t size() const {return effects_.size();}
    [[nodiscard]] const Effect* get(EntityId id) const {return entities_.alive(id)?effects_.get(id):nullptr;}
    [[nodiscard]] const std::vector<ComponentPool<Effect>::Entry>& entries() const {return effects_.entries();}
    void clear();
private:
    EntityRegistry entities_;
    ComponentPool<Effect> effects_;
    std::vector<EntityId> expired_;
};
}
