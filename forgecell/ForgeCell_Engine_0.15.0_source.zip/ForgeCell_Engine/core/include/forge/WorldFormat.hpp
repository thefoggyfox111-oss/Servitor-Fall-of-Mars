#pragma once
#include "forge/Simulation.hpp"
#include <cstddef>
#include <span>
#include <string>

namespace forge {
// Validated, endian-defined runtime geometry format produced by tools/import_ldtk.py.
// Never load untrusted level data without size/count validation.
bool loadWorldBinary(std::span<const std::byte> input, World& output, std::string& error);
}
