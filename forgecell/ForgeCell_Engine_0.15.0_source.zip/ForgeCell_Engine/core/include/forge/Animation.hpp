#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace forge {
enum class Animation : uint8_t { Idle, Run, Jump, Fall, Landing, Roll, Attack, Shoot, Count };
enum class AnchorId : uint8_t { LeftHand, RightHand, Weapon, Muzzle, Body, Feet, Effect, Count };
struct Anchor {float x=0,y=0;};
// Frame events are edge-triggered on entry and independent of rendering frequency.
struct SpriteFrame {
    float seconds = 1.0f/16.0f;
    std::array<Anchor,static_cast<size_t>(AnchorId::Count)> anchors {};
    uint32_t events = 0;
};
struct SpriteClip {
    std::vector<SpriteFrame> frames;
    bool loop = true;
};
struct Animator {
    Animation animation = Animation::Idle;
    float time = 0;
    int frame = 0;
    float speed = 1.0f;
    Animator();
    void change(Animation next);
    void tick(float dt);
    bool setClip(Animation target,SpriteClip clip);
    const SpriteFrame* currentFrame() const;
    uint32_t takeEvents();
private:
    std::array<SpriteClip,static_cast<size_t>(Animation::Count)> clips_;
    float frameElapsed_ = 0;
    uint32_t pendingEvents_ = 0;
};
}
