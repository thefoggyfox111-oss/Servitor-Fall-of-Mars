#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

namespace forge {
// All instances refer to definitions by stable ID, not memory addresses.
enum class WeaponKind : uint8_t { Melee = 0, Ranged = 1 };
struct WeaponDefinition {
    std::string id;
    std::string name;
    WeaponKind kind = WeaponKind::Melee;
    int damage = 16;
    float startup = .10f;
    float active = .12f;
    float recovery = .18f;
    float reach = 36;
    float hitHeight = 27;
    float knockback = 90;
    float cooldown = .21f;
    float projectileSpeed = 650;
    int magazine = 12;
    float reloadSeconds = 1.2f;
};
enum class ItemKind : uint8_t { Armor = 0, Passive = 1, Consumable = 2 };
struct ItemDefinition {
    std::string id;
    std::string name;
    ItemKind kind = ItemKind::Passive;
    int healthBonus = 0;
    int damageBonus = 0;
    int damageReduction = 0;
    int healAmount = 0;
    // FCIT v2 metadata. Instance IDs remain stable across save versions.
    uint16_t level = 1;
    uint8_t rarity = 0; // 0 common ... 4 legendary
    uint16_t speedBonusPct = 0; // Applies to movement, capped at +100% total
};
// Affixes are instance-specific bonuses on top of the catalog definition.
// All values are bounded to prevent malformed saves from overflowing stats.
struct ItemAffixes {
    uint16_t health = 0;
    uint16_t damage = 0;
    uint16_t defense = 0;
    uint16_t speedPct = 0;
    uint16_t healing = 0;
    bool operator==(const ItemAffixes&) const = default;
};
struct ItemInstance {
    uint32_t uid = 0;           // Stable across inventory operations and saves
    std::string definitionId;  // Stable authoring/catalog ID
    ItemAffixes affixes {};
};
struct EquipmentComparison {
    bool compatible = false;
    int healthDelta = 0;
    int damageDelta = 0;
    int defenseDelta = 0;
    int speedDeltaPct = 0;
    int healingDelta = 0;
    int levelDelta = 0;
    uint8_t rarity = 0;
};
class Equipment {
public:
    static constexpr size_t kBackpackSize = 24;
    std::vector<WeaponDefinition> definitions;
    std::vector<ItemDefinition> itemDefinitions;
    static constexpr size_t kMaxInstances = 64;
    // armor / passive A / passive B / consumable
    std::array<std::string,4> accessories {};
    std::array<std::string, kBackpackSize> backpack {};
    std::array<std::string,2> equipped {};
    Equipment();
    const WeaponDefinition* find(const std::string& id) const;
    const WeaponDefinition* slot(size_t index) const;
    const ItemDefinition* findItem(const std::string& id) const;
    bool setItems(std::vector<ItemDefinition> items);
    bool equipAccessoryFromBackpack(size_t backpackIndex,size_t accessorySlot);
    int bonusHealth() const;
    int bonusDamage() const;
    int damageReduction() const;
    int speedBonusPercent() const;
    // Read-only stat comparison; slot 0/1=weapon, 2=armor, 3/4=passive, 5=consumable.
    EquipmentComparison compareBackpackToSlot(size_t backpackIndex,size_t slotIndex) const;
    int useConsumable(); // returns heal amount, consumes equipped item
    bool addToBackpack(const std::string& id);
    // Token "~<uid>" identifies a physical copy, not the catalog template.
    bool addInstanceToBackpack(const std::string& definitionId,ItemAffixes affixes,
                              uint32_t* createdUid = nullptr);
    const ItemInstance* instance(const std::string& token) const;
    const std::vector<ItemInstance>& instances() const {return instances_;}
    bool restoreInstances(std::vector<ItemInstance> records);
    bool validReferences() const;
    int weaponDamage(size_t slotIndex) const;
    int consumableHealing() const;
    ItemAffixes bonuses(const std::string& token) const;
    void sortBackpack(); // stable, groups by category/rarity, keeps instance IDs unchanged
    bool swapBackpack(size_t from, size_t to); // transactional, including empty destination
    bool transferEquipmentToBackpack(size_t slot, size_t bag); // slots 0..1 weapons, 2..5 accessories

    // Slot 0 = melee key, slot 1 = ranged key in this prototype.
    // Equip swaps the old item back into the backpack, never silently losing it.
    bool equipFromBackpack(size_t backpackIndex, size_t slotIndex);
    // Used for asset preloading / tests. Replaces only validated loadouts.
    bool setDefinitions(std::vector<WeaponDefinition> defs);
private:
    friend class CombatSystem;
    // Creates a world-owned instance without inserting it into backpack.
    // CombatSystem immediately binds it to an ECS pickup or rolls back on failure.
    std::string createWorldInstance(const std::string& base, ItemAffixes attrs);
    void rollbackWorldInstance(const std::string& token);
    std::vector<ItemInstance> instances_;
    uint32_t nextInstanceUid_ = 1;
    const std::string& definitionId(const std::string& token) const;
};
// FCWP v1: versioned/size-bounded binary format produced from JSON, load atomically.
bool loadWeaponBinary(std::span<const std::byte> binary, Equipment& equipment, std::string& error);
// FCIT v1/v2 packed item catalog; invalid loads do not mutate equipment.
bool loadItemBinary(std::span<const std::byte> binary, Equipment& equipment, std::string& error);
}
