#pragma once
#include "forge/Animation.hpp"
#include <cstddef>
#include <span>
#include <string>

namespace forge {
// Little-endian FCAN v1. Validates entire file before replacing any clips.
bool loadAnimationBinary(std::span<const std::byte> input, Animator& animator, std::string& error);
}
