#pragma once
#include "forge/EntityRegistry.hpp"
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <iterator>
#include <span>
#include <vector>

namespace forge {
struct Combatant;
// Dense ECS storage for enemies. Runtime handles use generations; stable actor
// IDs are exclusively for content authoring and checkpoint serialization.
class EnemyActors {
public:
    static constexpr size_t kMaxEnemies=128;
    using Entry=ComponentPool<Combatant>::Entry;
    EnemyActors();
    ~EnemyActors();
    EnemyActors(const EnemyActors&);
    EnemyActors& operator=(const EnemyActors&);
    EnemyActors(EnemyActors&&);
    EnemyActors& operator=(EnemyActors&&);
    EnemyActors& operator=(std::initializer_list<Combatant>);
    EnemyActors& operator=(std::vector<Combatant>);
    bool replace(std::span<const Combatant> actors);
    EntityId add(Combatant actor);
    void push_back(Combatant actor);
    bool erase(EntityId handle);
    Combatant* get(EntityId handle);
    const Combatant* get(EntityId handle) const;
    EntityId handle(uint32_t stableId) const;
    Combatant* find(uint32_t stableId);
    const Combatant* find(uint32_t stableId) const;
    void clear();
    void reserve(size_t size);
    size_t size() const;
    bool empty() const;
    Combatant& operator[](size_t index);
    const Combatant& operator[](size_t index) const;
    Combatant& front();
    const Combatant& front() const;

    // The projection iterator keeps existing gameplay/renderer range-for calls
    // independent of ECS pool storage. It is invalidated by structural changes.
    template<bool IsConst> class ActorIterator {
        using Vec=std::conditional_t<IsConst,const std::vector<Entry>,std::vector<Entry>>;
        Vec* entries_=nullptr;
        size_t at_=0;
    public:
        using iterator_category=std::forward_iterator_tag;
        using value_type=Combatant;
        using difference_type=std::ptrdiff_t;
        using reference=std::conditional_t<IsConst,const Combatant&,Combatant&>;
        using pointer=std::conditional_t<IsConst,const Combatant*,Combatant*>;
        ActorIterator()=default;
        ActorIterator(Vec& entries,size_t at):entries_(&entries),at_(at){}
        reference operator*() const {return (*entries_)[at_].value;}
        pointer operator->() const {return &(**this);}
        ActorIterator& operator++(){++at_;return *this;}
        ActorIterator operator++(int){auto old=*this;++*this;return old;}
        friend bool operator==(const ActorIterator&,const ActorIterator&)=default;
    };
    using iterator=ActorIterator<false>;
    using const_iterator=ActorIterator<true>;
    iterator begin();
    iterator end();
    const_iterator begin() const;
    const_iterator end() const;
private:
    EntityRegistry registry_;
    ComponentPool<Combatant> actors_;
};
}
