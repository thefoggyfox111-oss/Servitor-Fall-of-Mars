#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>
#include "forge/Combat.hpp"
#include "forge/Animation.hpp"
#include "forge/Effects.hpp"
#include "forge/WorldObjects.hpp"

namespace forge {
constexpr float kFixedDt = 1.0f / 60.0f;
struct Vec2 { float x = 0, y = 0; };
struct Rect { float x = 0, y = 0, w = 0, h = 0; };
bool overlaps(Rect a, Rect b);
struct Input {
    float move = 0; // -1 ... 1
    bool jumpHeld = false;
    bool jumpPressed = false;
    bool rollPressed = false;
    bool attackPressed = false;
    bool shootPressed = false;
    bool swapMeleePressed = false;
    bool swapRangedPressed = false;
    bool inventoryPressed = false;
    bool interactPressed = false;
    bool useConsumablePressed = false;
    int inventoryIndex = -1; // selected backpack cell when inventory is open
    bool dropSelectedPressed = false;
    bool sortInventoryPressed = false;
    int inventoryMoveFrom = -1; // drag from backpack index
    int inventoryMoveTo = -1;   // drag to backpack index
    int inventoryEquipSlot = -1; // 0 melee, 1 ranged, 2 armor, 3/4 passives, 5 consumable
    int inventoryUnequipSlot = -1;
    int inventoryUnequipTo = -1;
};
struct PlayerConfig {
    float maxSpeed = 150;
    float groundAcceleration = 1400;
    float airAcceleration = 850;
    float deceleration = 1700;
    float gravity = 860;
    float maxFallSpeed = 460;
    float jumpSpeed = 290;
    float coyoteSeconds = 0.100f;
    float jumpBufferSeconds = 0.120f;
    float rollSeconds = 0.400f;
    float rollSpeed = 205;
    float rollInvulnerabilityFrom = 0.07f;
    float rollInvulnerabilityTo = 0.28f;
};
struct Player {
    int health = 100;
    int maxHealth = 100;
    Vec2 pos {72, 276}; // coordinates of feet, +Y downward
    Vec2 prevPos {72, 276};
    Vec2 vel {};
    bool grounded = false;
    bool facingRight = true;
    bool invulnerable = false;
    float damageIframes = 0;
    bool rolling = false;
    float rollTimer = 0;
    float coyoteTimer = 0;
    float jumpBufferTimer = 0;
    float landingTimer = 0;
    float attackTimer = 0;
    float shootTimer = 0;
    Animator animator {};
    Rect bounds() const {return {pos.x - 9, pos.y - 36, 18, 36};}
};
struct Camera {
    Vec2 center {320, 180};
    Vec2 previous {320, 180};
    float viewWidth = 640;
    float viewHeight = 360;
    Vec2 interpolated(float alpha) const;
};
struct World {
    float width = 1980;
    float height = 360;
    std::vector<Rect> solids;
    std::vector<Rect> oneWay;
    World();
};
class FixedStepper {
public:
    float advance(double seconds); // returns 0..1 interpolation factor
    template<class Fn> float advance(double seconds, Fn&& update) {
        accumulator_ += std::clamp(seconds, 0.0, 0.25);
        int steps = 0;
        while (accumulator_ + 1e-10 >= (1.0 / 60.0) && steps < 8) {
            update(kFixedDt);
            accumulator_ -= (1.0 / 60.0);
            ++steps;
        }
        if (steps == 8 && accumulator_ >= (1.0 / 60.0)) {
            // prevent spiral of death: simulation does not speed up after a stall
            accumulator_ = 0;
        }
        return static_cast<float>(std::max(0.0, accumulator_) / (1.0 / 60.0));
    }
    void reset() {accumulator_ = 0;}
private:
    double accumulator_ = 0;
};

class Simulation {
public:
    Simulation();
    World world;
    Player player;
    Camera camera;
    PlayerConfig config;
    CombatSystem combat;
    EffectSystem effects;
    WorldObjectSystem objects;
    bool inventoryOpen = false;
    size_t inventorySelected = 0;
    bool inventorySelectionArmed = false; // first tap previews; second tap equips
    void tick(float dt, const Input& input);
    void reset();
private:
    static float approach(float value, float target, float step);
    void moveWithCollisions(float dt);
};
}
