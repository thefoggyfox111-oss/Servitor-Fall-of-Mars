#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include "forge/Equipment.hpp"
namespace forge {
// FCLT v1: fixed-size, versioned loot roll settings, independent from FPS.
struct LootRule {
    uint8_t chance = 100;       // 0..100
    uint8_t rolls = 0;          // number of distinct stats to roll, 0..3
    uint8_t statMask = 0x1f;    // HP, damage, defense, speed, healing
    uint16_t minimum = 0;
    uint16_t maximum = 0;
};
class LootTable {
public:
    uint64_t seed = 0x6F6D6E6973736961ULL;
    std::array<LootRule,5> rules {}; // Dummy, Grunt, Heavy, Gunner, Boss
    LootTable();
    // Atomically installs 5 rules from FCLT v1 on success.
    bool load(std::span<const std::byte> bytes, std::string& error);
    // Results depend only on seed + stable enemy ID + role, never call order or FPS.
    std::optional<ItemAffixes> roll(uint32_t stableEnemyId,uint8_t role) const;
};
}
