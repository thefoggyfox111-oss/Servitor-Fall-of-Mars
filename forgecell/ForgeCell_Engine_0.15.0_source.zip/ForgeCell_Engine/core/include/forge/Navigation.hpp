#pragma once
#include "forge/Simulation.hpp"
namespace forge {
// An inexpensive, deterministic waypoint plan over static platform top surfaces.
// Does not replace local collision detection or guarantee a path around complex walls.
struct NavigationHop {
    bool valid = false;
    bool transition = false;
    float takeoffX = 0;
    float landingX = 0;
    float landingY = 0;
};
NavigationHop planPlatformHop(const World& world, Vec2 from, Vec2 destination);
}
